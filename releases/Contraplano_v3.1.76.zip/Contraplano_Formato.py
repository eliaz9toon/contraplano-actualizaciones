"""Pegado con formato: convierte el HTML del portapapeles (Word, Docs, paginas web) a texto con marcas simples.

Marcas: una linea que empieza con "## " es un subtitulo (encabezado) y **texto** es negrita.
El texto sin marcas (strip_markup) es el contenido real de la noticia; las marcas solo indican el formato.
"""
import os
import re
from html.parser import HTMLParser

_BLOCK_TAGS = {"p", "div", "li", "ul", "ol", "table", "tr", "td", "th", "blockquote", "section", "article", "header", "footer",
               "h1", "h2", "h3", "h4", "h5", "h6", "br", "hr", "pre"}
_HEADINGS = {"h1", "h2", "h3", "h4", "h5", "h6"}
_SKIP = {"script", "style", "head", "title", "svg", "noscript"}
_WEIGHT = re.compile(r"font-weight\s*:\s*([a-z0-9]+)", re.IGNORECASE)


def _style_bold(style):
    """True/False si el estilo fija el peso de la fuente; None si no dice nada."""
    found = _WEIGHT.search(style or "")
    if not found:
        return None
    value = found.group(1).lower()
    if value in ("bold", "bolder"):
        return True
    if value in ("normal", "lighter"):
        return False
    return value.isdigit() and int(value) >= 600


class _Converter(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.blocks = []
        self._segments = []      # (texto, negrita)
        self._stack = []         # (etiqueta, negrita efectiva)
        self._heading = False
        self._item = False
        self._skip = 0

    def _bold(self):
        return self._stack[-1][1] if self._stack else False

    def _flush(self):
        segments, heading, item = self._segments, self._heading, self._item
        self._segments, self._heading, self._item = [], False, False
        # Une segmentos contiguos con el mismo formato y normaliza espacios.
        merged = []
        for text, bold in segments:
            text = text.replace("\xa0", " ").replace(" ", " ").replace("​", "")
            text = re.sub(r"\s+", " ", text)
            if merged and merged[-1][1] == bold:
                merged[-1][0] += text
            else:
                merged.append([text, bold])
        plain = "".join(text for text, _ in merged).strip()
        if not plain:
            return
        letters = [(len(text.strip()), bold) for text, bold in merged]
        total = sum(n for n, _ in letters)
        bold_total = sum(n for n, bold in letters if bold)
        all_bold = total > 0 and bold_total == total
        short = len(plain) <= 100 and len(plain.split()) <= 14 and not re.search(r"[.!?…:;,]$", plain)
        if heading or (all_bold and short and not item):
            self.blocks.append("## " + plain)
            return
        if all_bold:
            self.blocks.append(("• " if item else "") + "**" + plain + "**")
            return
        parts = []
        for text, bold in merged:
            if bold and text.strip():
                lead = text[: len(text) - len(text.lstrip())]
                trail = text[len(text.rstrip()):]
                parts.append(lead + "**" + text.strip() + "**" + trail)
            else:
                parts.append(text)
        line = "".join(parts)
        line = re.sub(r"\s+", " ", line).strip()
        self.blocks.append(("• " if item else "") + line)

    def handle_starttag(self, tag, attrs):
        if tag in _SKIP:
            self._skip += 1
            return
        if self._skip:
            return
        attrs = dict(attrs)
        if tag in _BLOCK_TAGS:
            self._flush()
            if tag in _HEADINGS:
                self._heading = True
            if tag == "li":
                self._item = True
        if tag in ("br", "hr", "img", "meta", "link", "input"):
            return
        own = _style_bold(attrs.get("style"))
        if tag in ("b", "strong"):
            own = True if own is None else own
        elif tag in _HEADINGS:
            own = False                  # el encabezado ya se marca con ##; no hace falta ** dentro
        inherited = self._bold()
        self._stack.append((tag, inherited if own is None else own))

    def handle_endtag(self, tag):
        if tag in _SKIP:
            self._skip = max(0, self._skip - 1)
            return
        if self._skip:
            return
        for index in range(len(self._stack) - 1, -1, -1):
            if self._stack[index][0] == tag:
                del self._stack[index:]
                break
        if tag in _BLOCK_TAGS:
            self._flush()

    def handle_data(self, data):
        if self._skip or not data:
            return
        self._segments.append((data, self._bold()))

    def close(self):
        super().close()
        self._flush()


def html_to_markup(fragment):
    """HTML -> texto con marcas, con una linea en blanco entre bloques."""
    converter = _Converter()
    converter.feed(fragment or "")
    converter.close()
    return "\n\n".join(converter.blocks).strip()


_MARK_HEADING = re.compile(r"^[ \t]*##[ \t]+", re.MULTILINE)


def strip_markup(text):
    """Quita las marcas (## y **) y devuelve el texto real de la noticia."""
    text = _MARK_HEADING.sub("", text or "")
    return text.replace("**", "")


def has_markup(text):
    return bool(_MARK_HEADING.search(text or "")) or "**" in (text or "")


def _decode(data):
    """UTF-8 (lo normal en CF_HTML); si no es valido, Windows-1252 (algunas apps antiguas)."""
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", "replace")


def clipboard_html():
    """Fragmento HTML del portapapeles de Windows (formato "HTML Format"), o None."""
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        user32, kernel32 = ctypes.WinDLL("user32"), ctypes.WinDLL("kernel32")
        user32.RegisterClipboardFormatW.argtypes = [wintypes.LPCWSTR]
        user32.RegisterClipboardFormatW.restype = wintypes.UINT
        user32.OpenClipboard.argtypes = [wintypes.HWND]
        user32.OpenClipboard.restype = wintypes.BOOL
        user32.IsClipboardFormatAvailable.argtypes = [wintypes.UINT]
        user32.IsClipboardFormatAvailable.restype = wintypes.BOOL
        user32.GetClipboardData.argtypes = [wintypes.UINT]
        user32.GetClipboardData.restype = ctypes.c_void_p
        user32.CloseClipboard.restype = wintypes.BOOL
        kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalLock.restype = ctypes.c_void_p
        kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalSize.argtypes = [ctypes.c_void_p]
        kernel32.GlobalSize.restype = ctypes.c_size_t
        fmt = user32.RegisterClipboardFormatW("HTML Format")
        if not user32.OpenClipboard(None):
            return None
        try:
            if not user32.IsClipboardFormatAvailable(fmt):
                return None
            handle = user32.GetClipboardData(fmt)
            if not handle:
                return None
            pointer = kernel32.GlobalLock(handle)
            if not pointer:
                return None
            try:
                raw = ctypes.string_at(pointer, min(kernel32.GlobalSize(handle), 8 * 1024 * 1024))
            finally:
                kernel32.GlobalUnlock(handle)
        finally:
            user32.CloseClipboard()
        full = _decode(raw.split(bytes(1))[0])
        # Los marcadores de fragmento son mas fiables que los desplazamientos (algunas apps los cuentan en caracteres, no en bytes).
        marked = re.search(r"<!--StartFragment-->(.*?)<!--EndFragment-->", full, re.DOTALL)
        if marked:
            return marked.group(1)
        header = raw[:600].decode("ascii", "ignore")
        start = re.search(r"StartFragment:(\d+)", header)
        end = re.search(r"EndFragment:(\d+)", header)
        if start and end and int(start.group(1)) < int(end.group(1)) <= len(raw):
            fragment = _decode(raw[int(start.group(1)):int(end.group(1))])
            return re.sub(r"<[^>]*$", "", fragment)      # descarta una etiqueta cortada al final
        return full
    except Exception:
        return None


def rich_paste_text(plain_text=None):
    """Texto con marcas para pegar, o None si el portapapeles no trae HTML util (se pega como texto normal).

    plain_text es el texto simple del portapapeles: se usa para comprobar que el HTML corresponde a lo mismo."""
    fragment = clipboard_html()
    if not fragment:
        return None
    markup = html_to_markup(fragment)
    if not markup:
        return None
    if plain_text is not None:
        a = len(strip_markup(markup).split())
        b = len(str(plain_text).split())
        if b and abs(a - b) > max(3, int(b * 0.1)):
            return None
    return markup
