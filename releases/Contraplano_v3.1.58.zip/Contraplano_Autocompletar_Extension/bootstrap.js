(() => {
  const version = "3.1.58";
  const url = new URL(location.href);
  const existing = url.hash.match(/(?:^#|&)codexExisting=([A-Za-z0-9_-]+)/);
  const humanizer = url.hash.match(/(?:^#|&)codexPayload=([A-Za-z0-9_-]+)/);
  const manual = url.hash.match(/(?:^#|&)codexManual=([A-Za-z0-9_-]+)/);
  const match = existing || humanizer || manual;
  if (!match) return;
  try {
    const encoded = match[1].replace(/-/g, "+").replace(/_/g, "/");
    const bytes = Uint8Array.from(atob(encoded + "=".repeat((4 - encoded.length % 4) % 4)), (char) => char.charCodeAt(0));
    const data = JSON.parse(new TextDecoder().decode(bytes));
    if (existing) {
      const target = new URL(data.targetPostUrl);
      if (target.searchParams.get("post") !== url.searchParams.get("post")) return;
      Object.assign(data, { resumeExisting: true, editExisting: true, editorStarted: false });
      sessionStorage.setItem(`contraplano-existing-${url.searchParams.get("post")}`, JSON.stringify(data));
      localStorage.setItem("contraplano-autofill-pending", JSON.stringify(data));
    } else if (manual && url.pathname.endsWith("/wp-admin/post-new.php")) {
      sessionStorage.setItem("contraplano-manual-launch", JSON.stringify(data));
    } else if (humanizer) {
      sessionStorage.setItem("contraplano-humanizer-launch", JSON.stringify(data));
    } else return;
    if (data.logPort && data.logToken) {
      chrome.runtime.sendMessage({ type: "CONTRAPLANO_REGISTER_CONSOLE", port: data.logPort, token: data.logToken, version }).then((result) => {
        sessionStorage.setItem("contraplano-launch-connection", JSON.stringify({ registered: Boolean(result?.registered), error: result?.error || "", at: Date.now() }));
      }).catch((error) => {
        sessionStorage.setItem("contraplano-launch-connection", JSON.stringify({ registered: false, error: error.message, at: Date.now() }));
      });
    } else {
      sessionStorage.setItem("contraplano-launch-connection", JSON.stringify({ registered: false, error: "El preparador no incluyó datos de conexión. Revisa su versión y ruta en CMD.", at: Date.now() }));
    }
  } catch (error) {
    sessionStorage.setItem("contraplano-launch-connection", JSON.stringify({ registered: false, error: `No pude leer el enlace del preparador: ${error.message}`, at: Date.now() }));
  }
})();
