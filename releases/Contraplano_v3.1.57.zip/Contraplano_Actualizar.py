"""Actualización al abrir; el canal lo administra el responsable del equipo."""
import hashlib
import json
import os
import re
from pathlib import Path
import tempfile
import urllib.parse
import urllib.request
import zipfile
import time

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "Contraplano_Configuracion.json"
VERSION_FILE = "Contraplano_version.json"
OFFICIAL_UPDATE_SOURCE = "https://contraplano-actualizaciones-ec0311.quietbeech24.chatgpt.site/version.json"
EXTENSION_FILES = [f"Contraplano_Autocompletar_Extension/{name}" for name in ("manifest.json", "bootstrap.js", "content.js", "background.js")]
PACKAGE_FILES = ["Contraplano_Preparar_Noticia.py", "Contraplano_Selector_Archivo.py", "Contraplano_Actualizar.py", "Contraplano_Configurar.py", "Contraplano_Diagnostico.py", "Abrir_Preparador_Contraplano.bat", "LEEME_Preparador_Contraplano.txt", VERSION_FILE, *EXTENSION_FILES]


def onedrive_root():
    return Path(os.environ.get("OneDrive", str(Path.home() / "OneDrive")))


def load_config():
    try:
        result = json.loads(CONFIG.read_text(encoding="utf-8-sig"))
        return result if isinstance(result, dict) else {}
    except (OSError, ValueError):
        return {}


def save_config(settings):
    temporary = CONFIG.with_suffix(".tmp")
    temporary.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(CONFIG)


def default_source():
    return OFFICIAL_UPDATE_SOURCE


def legacy_source():
    return str(onedrive_root() / "Contraplano_Actualizaciones" / "version.json")


def effective_update_source(settings):
    source = str(settings.get("updateSource") or "").strip()
    if not source:
        return default_source()
    if urllib.parse.urlparse(source).scheme == "https":
        return source
    try:
        if Path(source).expanduser().resolve() == Path(legacy_source()).resolve():
            return default_source()
    except (OSError, ValueError):
        pass
    return source


def read_update_status():
    try:
        value = json.loads((BASE / "Contraplano_Actualizacion_Estado.json").read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def record_update_status(state, message, installed=None, available=None):
    try:
        target = BASE / "Contraplano_Actualizacion_Estado.json"
        temporary = target.with_suffix(".tmp")
        temporary.write_text(json.dumps({"state": state, "message": message, "installed": installed, "available": available, "checkedAt": time.time()}, ensure_ascii=False), encoding="utf-8")
        temporary.replace(target)
    except OSError:
        pass


def version_tuple(value):
    pieces = str(value).split(".")
    if len(pieces) != 3 or any(not p.isdigit() for p in pieces):
        raise ValueError("La versión debe tener el formato 2.87.0.")
    return tuple(map(int, pieces))


def runtime_lock():
    import msvcrt
    handle = (BASE / ".contraplano-activo.lock").open("a+b")
    if os.fstat(handle.fileno()).st_size == 0:
        handle.write(b"0")
        handle.flush()
    handle.seek(0)
    try:
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        handle.close()
        raise RuntimeError("El preparador ya está abierto. Ciérralo antes de actualizar.")
    return handle


def read_source(source, limit):
    parsed = urllib.parse.urlparse(source)
    if parsed.scheme == "https":
        with urllib.request.urlopen(urllib.request.Request(source, headers={"User-Agent": "Contraplano-Actualizador", "Cache-Control": "no-cache"}), timeout=20) as response:
            if urllib.parse.urlparse(response.url).scheme != "https":
                raise ValueError("La descarga debe conservar HTTPS.")
            if "text/html" in str(response.headers.get("Content-Type", "")).lower():
                raise ValueError("El canal devolvió una página web o un inicio de sesión en vez del archivo de actualización. Revisa que el canal permita la descarga directa.")
            data = response.read(limit + 1)
    elif parsed.scheme in ("http", "ftp", "file"):
        raise ValueError("Usa una dirección HTTPS o la ruta de la carpeta compartida.")
    else:
        with Path(source).open("rb") as stream:
            data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("El archivo supera el tamaño permitido.")
    return data


def resolve_package(source, package):
    if urllib.parse.urlparse(source).scheme == "https":
        return urllib.parse.urljoin(source, package)
    if urllib.parse.urlparse(package).scheme == "https":
        return package
    path = Path(package)
    return str(path if path.is_absolute() else Path(source).parent / path)


def install_package(raw, version, expected_hash):
    if hashlib.sha256(raw).hexdigest() != expected_hash.lower():
        raise ValueError("El paquete no coincide con su SHA-256. Se conserva la versión instalada.")
    with tempfile.TemporaryDirectory(prefix="contraplano-update-", dir=BASE) as temporary:
        stage = Path(temporary)
        archive_path = stage / "release.zip"
        archive_path.write_bytes(raw)
        with zipfile.ZipFile(archive_path) as archive:
            names = archive.namelist()
            required = set(PACKAGE_FILES) - {'Contraplano_Diagnostico.py'}
            # Permit new application modules without tying validation to the
            # exact file list compiled into an older updater. Personal JSON,
            # executables and arbitrary paths are never update targets.
            allowed = lambda name: name in PACKAGE_FILES or bool(re.fullmatch(r'Contraplano_[A-Za-z_]+\.py', name))
            if len(names) > 64 or len(set(names)) != len(names) or not required.issubset(names) or not all(allowed(name) for name in names):
                raise ValueError("El paquete contiene archivos faltantes, duplicados o no permitidos. Actualiza una vez con el instalador oficial si tu versión es antigua.")
            if version_tuple(version) >= (3, 1, 13) and 'Contraplano_Diagnostico.py' not in names:
                raise ValueError('Falta el módulo de diagnóstico requerido por esta versión.')
            if sum(info.file_size for info in archive.infolist()) > 50 * 1024 * 1024:
                raise ValueError("El paquete descomprimido es demasiado grande.")
            release = json.loads(archive.read(VERSION_FILE))
            manifest = json.loads(archive.read(EXTENSION_FILES[0]))
            if release.get("version") != version or manifest.get("version") != version:
                raise ValueError("Las versiones del programa y la extensión no coinciden.")
            for name in names:
                target = stage / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
        backup = {name: (BASE / name).read_bytes() if (BASE / name).exists() else None for name in names}
        changed = []
        try:
            for name in names:
                target = BASE / name
                target.parent.mkdir(parents=True, exist_ok=True)
                (stage / name).replace(target)
                changed.append(name)
        except Exception:
            for name in reversed(changed):
                target = BASE / name
                if backup[name] is None:
                    target.unlink(missing_ok=True)
                else:
                    target.write_bytes(backup[name])
            raise


def main(force=False):
    lock = None
    current = None
    version = None
    try:
        lock = runtime_lock()
        settings = load_config()
        if settings.get("autoUpdate", True) is False and not force:
            record_update_status("disabled", "Actualizaciones automáticas desactivadas por tu elección.")
            return
        source = effective_update_source(settings)
        if source != settings.get("updateSource"):
            settings["updateSource"] = source
            save_config(settings)
        current = json.loads((BASE / VERSION_FILE).read_text(encoding="utf-8-sig"))["version"]
        print(f"[ACTUALIZADOR] Comprobando versiones. Instalada: {current}", flush=True)
        release = json.loads(read_source(source, 65536))
        version = release["version"]
        if version_tuple(version) <= version_tuple(current):
            print("[ACTUALIZADOR] Ya tienes la última versión.", flush=True)
            record_update_status("current", f"Canal conectado. Tienes la versión {current}.", current, version)
            return
        print(f"[ACTUALIZADOR] Descargando e instalando {version}…", flush=True)
        raw = read_source(resolve_package(source, release["package"]), 25 * 1024 * 1024)
        install_package(raw, version, release["sha256"])
        print(f"[ACTUALIZADOR] Versión {version} instalada. Tus preferencias se conservaron.", flush=True)
        record_update_status("updated", f"Actualizado a {version}. Tus preferencias se conservaron.", version, version)
    except Exception as error:
        print(f"[ACTUALIZADOR] No se aplicó una actualización: {error}. Abriendo la versión instalada.", flush=True)
        record_update_status("error", "No pude actualizar: " + str(error), current, version)
    finally:
        if lock:
            lock.close()


if __name__ == "__main__":
    main()
