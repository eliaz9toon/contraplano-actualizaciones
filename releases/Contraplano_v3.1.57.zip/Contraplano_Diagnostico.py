"""Bounded, asynchronous technical reports. Never serializes messages or article data."""
import json
import os
import hashlib
import re
import sys
import threading
import time
import traceback
import urllib.request
import secrets
from pathlib import Path
from Contraplano_Actualizar import BASE, load_config

ENDPOINT = 'https://contraplano-diagnostico-ec0311.quietbeech24.chatgpt.site/report'
ROOT = BASE / 'Diagnostico_local'
_lock = threading.Lock()
_started = False
_recent = {}


def new_id():
    value = secrets.token_hex(16)
    return '-'.join((value[:8], value[8:12], value[12:16], value[16:20], value[20:]))


def enabled():
    return '--self-test' not in sys.argv and load_config().get('sendDiagnostics', True)


STEPS = {'unknown','rank_math','paragraphs','bold','featured_image','image_alt','image','taxonomies','save','publish','report_block','report','humanizer','blocks','title'}


def safe_context(value=None, error=None):
    value = value if isinstance(value, dict) else {}
    native = getattr(error, 'diagnostic_context', None)
    if isinstance(native, dict):
        value = {**value, **native}
    result = {'python': '.'.join(map(str, sys.version_info[:3]))}
    for key, choices in [('step', STEPS), ('surface', {'mrc','editor','admin'}), ('ready', {'loading','interactive','complete'})]:
        if isinstance(value.get(key), str) and value[key] in choices:
            result[key] = value[key]
    for key in ('iframe','rank_button','rank_panel','media_dialog'):
        if type(value.get(key)) is bool:
            result[key] = value[key]
    if type(value.get('elapsed_s')) is int:
        result['elapsed_s'] = max(0, min(86400, value['elapsed_s']))
    if isinstance(value.get('recent'), list):
        result['recent'] = [item for item in value['recent'][-8:] if isinstance(item, str) and item.rsplit(':',1)[0] in STEPS and item.rsplit(':',1)[-1] in ('ok','fail')]
    for key in ('viewport_w','viewport_h','client_w','client_h'):
        if type(value.get(key)) is int:
            result[key] = max(0,min(32768,value[key]))
    for key in ('renderer_count','matching_count'):
        if type(value.get(key)) is int:
            result[key] = max(0,min(128,value[key]))
    if type(value.get('dpr_milli')) is int:
        result['dpr_milli'] = max(500,min(4000,value['dpr_milli']))
    if value.get('native_reason') in ('no_match','ambiguous'):
        result['native_reason'] = value['native_reason']
    if isinstance(value.get('renderer_sizes'),list):
        result['renderer_sizes'] = [[max(0,min(32768,n)) for n in pair] for pair in value['renderer_sizes'][:8] if isinstance(pair,list) and len(pair)==2 and all(type(n) is int for n in pair)]
    cause = getattr(error, '__cause__', None)
    if cause and type(cause).__name__ in ('TimeoutError','URLError','HTTPError','ConnectionRefusedError','ConnectionResetError','OSError','ValueError'):
        result['cause_type'] = type(cause).__name__
    return result


def capture(message='', source='PYTHON', error=None, context=None):
    if isinstance(error, InterruptedError) or not enabled():
        return 'disabled'
    try:
        # The free-form message is classified locally and is NEVER stored/sent.
        text = str(message).lower()
        category = 'unhandled' if error else 'other'
        for words, code in [(['10061','connection refused','ollama no respondió'],'ollama_connection'),
                            (['ollama','descripción mrc','palabra clave pendiente'],'ollama_generation'),
                            (['img seo','selector','imagen'],'mrc_images'),
                            (['mrc','reporte'],'mrc_form'), (['rank math'],'rank_math'),
                            (['guardado','guardar borrador'],'wordpress_save'),
                            (['extensión','conexion de la extension'],'extension_connection'),
                            (['descarga','download'],'download')]:
            if any(word in text for word in words):
                category = code
                break
        sources = {'PREPARADOR','EXTENSIÓN','OLLAMA','SELECTOR WINDOWS','ACTUALIZADOR','ASISTENTE','INICIO','PYTHON'}
        source = source if source in sources else 'PYTHON'
        underlying = getattr(error, 'reason', None)
        error_type = type(underlying if isinstance(underlying, BaseException) else error).__name__ if error else ''
        status = getattr(error, 'code', None)
        if isinstance(status, int) and 100 <= status <= 599:
            error_type += '_' + str(status)
        error_type = re.sub(r'[^A-Za-z0-9_]', '_', error_type)[:60]
        # Fixed codes only: never transmit the free-form message.
        for markers, code in [
            (['no pude confirmar que el título anterior se borró', 'mrc no conservó el título'], 'MRCTitleValidation'),
            (['una cifra no está en el respaldo'], 'MRCNumberValidation'),
            (['falta una referencia válida', 'corregir las referencias'], 'MRCReferenceValidation'),
            (['no pude confirmar el reinicio'], 'OllamaRecoveryUnconfirmed'),
            (['reinicié el servicio'], 'OllamaTimeoutRecovered'),
            (['solicitud activa'], 'OllamaBusy'),
            (['no se recibió conexión', 'no pude conectar con el preparador'], 'BridgeUnavailable'),
            (['sin preparación activa', 'no hay una preparación activa'], 'NoActivePreparation'),
            (['no apareció el botón'], 'MissingButton'),
            (['no conserva el valor'], 'FieldValueNotRetained'),
            (['no apareció la opción'], 'MissingOption'),
            (['no apareció el párrafo', 'no pude leer su remarcado'], 'MissingRankMathHighlight'),
        ]:
            if any(marker in text for marker in markers):
                error_type = code
                break
        if source == 'OLLAMA' and category in ('other', 'unhandled'):
            category = 'ollama_generation'
        if source == 'OLLAMA' and error_type == 'ConnectionRefusedError':
            category = 'ollama_connection'
        frames = []
        if error:
            for frame in traceback.extract_tb(error.__traceback__)[-12:]:
                name = Path(frame.filename).name
                if re.fullmatch(r'Contraplano_[A-Za-z_]+\.py', name):
                    frames.append({'file': name, 'line': frame.lineno, 'function': re.sub(r'[^A-Za-z0-9_<>]', '_', frame.name)[:80]})
        with _lock:
            details = safe_context(context, error)
            key = (category, details.get('step')) if category == 'ollama_generation' else (source, category, error_type, details.get('step'))
            if time.time() - _recent.get(key, 0) < 60:
                return 'duplicate'
            ROOT.mkdir(exist_ok=True)
            device_file = ROOT / 'equipo.txt'
            if not device_file.exists():
                device_file.write_text(new_id(), encoding='ascii')
            version = json.loads((BASE / 'Contraplano_version.json').read_text(encoding='utf-8-sig'))['version']
            report = {'id':new_id(), 'device':device_file.read_text(encoding='ascii').strip(),
                      'version':version, 'category':category, 'source':source, 'error_type':error_type, 'frames':frames, 'context':details}
            files = sorted(ROOT.glob('*.json'), key=lambda p:p.stat().st_mtime)
            for file in files[:-199]:
                file.unlink(missing_ok=True)
            (ROOT / (report['id'] + '.json')).write_text(json.dumps(report), encoding='utf-8')
            _recent[key] = time.time()
            return 'queued'
    except Exception:
        return 'failed'  # Reporting must never interrupt news preparation.


def publication_counting_enabled():
    # This account-local opt-out must never travel in a release or shared config.
    local = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local')))
    return not (local / 'Contraplano' / 'Excluir_publicaciones_locales.flag').is_file()


def capture_publication(post_id):
    if not enabled() or not publication_counting_enabled():
        return False
    value = str(post_id)
    if not re.fullmatch(r'[1-9][0-9]{0,11}', value):
        return False
    try:
        key = hashlib.sha256(('contraplano.cl|' + value).encode('ascii')).hexdigest()
        version = json.loads((BASE / 'Contraplano_version.json').read_text(encoding='utf-8-sig'))['version']
        folder = ROOT / 'Publicadas_pendientes'
        with _lock:
            if not publication_counting_enabled():
                return False
            folder.mkdir(parents=True, exist_ok=True)
            target = folder / (key + '.json')
            if not target.exists():
                target.write_text(json.dumps({'kind':'publication', 'entry_key':key, 'version':version}), encoding='utf-8')
        return True
    except OSError:
        return False


def _sender():
    while True:
        try:
            if enabled() and ROOT.exists():
                paths = list(ROOT.glob('*.json'))[:20]
                if publication_counting_enabled():
                    paths += list((ROOT / 'Publicadas_pendientes').glob('*.json'))[:20]
                for path in paths:
                    if not enabled():
                        break
                    is_publication = path.parent.name == 'Publicadas_pendientes'
                    if is_publication and not publication_counting_enabled():
                        continue
                    endpoint = ENDPOINT.replace('/report', '/publication') if is_publication else ENDPOINT
                    request = urllib.request.Request(endpoint, data=path.read_bytes(), headers={'Content-Type':'application/json', 'User-Agent':'Contraplano-Diagnostico/1.0'}, method='POST')
                    try:
                        with urllib.request.urlopen(request, timeout=8) as response:
                            if response.status == 202 or response.status == 200:
                                path.unlink(missing_ok=True)
                    except Exception:
                        continue
        except Exception:
            pass
        time.sleep(60)


def install():
    global _started
    if _started or '--self-test' in sys.argv:
        return
    _started = True
    old_hook = sys.excepthook
    def exception_hook(kind, error, tb):
        capture(source='PYTHON', error=error)
        old_hook(kind, error, tb)
    sys.excepthook = exception_hook
    old_thread_hook = threading.excepthook
    def thread_hook(args):
        capture(source='PYTHON', error=args.exc_value)
        old_thread_hook(args)
    threading.excepthook = thread_hook
    import tkinter as tk
    original = tk.Tk.report_callback_exception
    def callback_hook(root, kind, error, tb):
        capture(source='PYTHON', error=error)
        original(root, kind, error, tb)
    tk.Tk.report_callback_exception = callback_hook
    threading.Thread(target=_sender, daemon=True, name='Contraplano-diagnostico').start()
