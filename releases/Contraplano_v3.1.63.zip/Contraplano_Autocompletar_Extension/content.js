(() => {
  const EXTENSION_VERSION = "3.1.63";
  const diagnosticState = { step: 'unknown', started: Date.now(), recent: [] };
  function diagnosticStep(label) {
    const rules = [[/Rank Math|puntaje|SEO/i,'rank_math'],[/párrafo/i,'paragraphs'],[/negrita/i,'bold'],[/destacada/i,'featured_image'],[/alternativo/i,'image_alt'],[/imagen|IMG SEO/i,'image'],[/categor|etiqueta/i,'taxonomies'],[/guardar|borrador/i,'save'],[/publicar|publicación/i,'publish'],[/Bloque:|categoría elegida/i,'report_block'],[/MRC|reporte/i,'report'],[/humaniz/i,'humanizer'],[/convert|bloques/i,'blocks'],[/título/i,'title']];
    return rules.find(([pattern]) => pattern.test(String(label)))?.[1] || 'unknown';
  }
  function diagnosticContext() {
    const has = selector => Boolean(document.querySelector(selector));
    return { step: diagnosticState.step, elapsed_s: Math.min(86400, Math.floor((Date.now()-diagnosticState.started)/1000)),
      surface: location.hostname === 'modulo-de-reportes-contraplano.web.app' ? 'mrc' : location.pathname.includes('post') ? 'editor' : 'admin',
      ready: document.readyState, iframe: has('iframe[name="editor-canvas"]'), rank_button: has('.rank-math-toolbar-score'), rank_panel: has('.rank-math-focus-keyword'), media_dialog: has('.media-frame.mode-select'),
      recent: diagnosticState.recent.slice(-8) };
  }
  const params = new URLSearchParams(location.search);
  if (location.hostname === "modulo-de-reportes-contraplano.web.app") {
    startReporterFormWorkflow();
    return;
  }
  if (location.pathname.endsWith("/wp-admin/post-new.php")) {
    startManualPostWorkflow();
    return;
  }
  if (params.get("page") !== "humanizador") {
    if (location.pathname.startsWith("/wp-admin/") && startReportAdminFlow()) return;
    if (location.pathname.endsWith("/wp-admin/post.php") && params.get("action") === "edit") {
      let manualLaunch;
      try { manualLaunch = JSON.parse(sessionStorage.getItem("contraplano-manual-launch") || "null"); } catch {}
      if (manualLaunch?.manual && !manualLaunch.createdPostUrl && (!manualLaunch.manualPostId || String(manualLaunch.manualPostId) === params.get("post"))) {
        manualLaunch.recoverCurrent = true;
        sessionStorage.setItem("contraplano-manual-launch", JSON.stringify(manualLaunch));
        startManualPostWorkflow();
        return;
      }
      launchEditorWorkflow();
      window.addEventListener("hashchange", () => { if (location.hash.includes("codexExisting=")) launchEditorWorkflow(); });
    }
    return;
  }

  const match = location.hash.match(/(?:^#|&)codexPayload=([A-Za-z0-9_-]+)/);
  let capturedLaunch;
  try { capturedLaunch = JSON.parse(sessionStorage.getItem("contraplano-humanizer-launch") || "null"); } catch {}
  if (!match && !capturedLaunch) return;

  const encoded = match ? match[1].replace(/-/g, "+").replace(/_/g, "/") : "";
  let payload;
  try {
    const bytes = Uint8Array.from(
      atob(encoded + "=".repeat((4 - encoded.length % 4) % 4)),
      (char) => char.charCodeAt(0),
    );
    payload = match ? JSON.parse(new TextDecoder().decode(bytes)) : capturedLaunch;
    sessionStorage.removeItem("contraplano-humanizer-launch");
  } catch {
    showNotice("No pude leer los datos enviados desde el preparador.", true);
    return;
  }
  connectConsole(payload);
  try {
    const launchData = { title: payload.title || "", body: payload.body || "", image: payload.image || "", imageToken: payload.imageToken || "", imagePort: payload.imagePort || 0, imageName: payload.imageName || "imagen-noticia", targetPostUrl: payload.targetPostUrl || "", logPort: payload.logPort || 0, logToken: payload.logToken || "", category: payload.category ?? "", reportBlock: payload.reportBlock ?? payload.category ?? "", autoPublish: payload.autoPublish !== false, autoMRC: payload.autoMRC !== false, imagePolicy: payload.imagePolicy === "replace" ? "replace" : "missing", editExisting: false, editorStarted: false, launchAt: Date.now() };
    // Mantener la tarea también en el almacenamiento de esta pestaña. La
    // pestaña de WordPress que abre el humanizador hereda este dato; así no
    // toma por accidente la noticia de otra pestaña desde localStorage.
    sessionStorage.setItem("contraplano-autofill-pending", JSON.stringify(launchData));
    localStorage.setItem("contraplano-autofill-pending", JSON.stringify(launchData));
  } catch {}

  let attempts = 0;
  const timer = setInterval(() => {
    attempts += 1;
    const title = document.getElementById("titulo-original");
    const body = document.getElementById("texto-ia");
    if (title && body) {
      clearInterval(timer);
      chrome.runtime.sendMessage({ type: "CONTRAPLANO_REGISTER_HUMANIZER_TAB" }).catch(() => {});
      setValue(title, payload.title || "");
      setValue(body, payload.body || "");
      history.replaceState(null, "", location.pathname + location.search);
      showNotice("Datos cargados. Iniciando la humanización…");
      clickHumanizeButton();
    } else if (attempts >= 50) {
      clearInterval(timer);
      showNotice("No encontré los campos #titulo-original y #texto-ia en esta página.", true);
    }
  }, 300);

  function setValue(element, value) {
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), "value")?.set;
    if (setter) setter.call(element, value);
    else element.value = value;
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function clickHumanizeButton() {
    let tries = 0;
    const buttonTimer = setInterval(() => {
      tries += 1;
      const label = [...document.querySelectorAll(".btn-text")].find(
        (element) => element.textContent.trim().toLocaleLowerCase("es") === "humanizar artículo",
      );
      const button = label?.closest("button, [role='button'], .btn") || label;
      if (button && !button.disabled && button.getAttribute("aria-disabled") !== "true") {
        clearInterval(buttonTimer);
        watchForHumanizeCompletion();
        button.click();
        showNotice("Se pulsó «Humanizar artículo». Revisa el resultado en la página.");
      } else if (tries >= 50) {
        clearInterval(buttonTimer);
        showNotice("Los campos quedaron cargados, pero no encontré habilitado el botón «Humanizar artículo».", true);
      }
    }, 200);
  }

  function watchForHumanizeCompletion() {
    progressStep("Humanizar artículo", "Esperando el resultado del humanizador…");
    const maxAttempts = 3;
    let attemptNumber = 1;
    let attemptStartedAt = Date.now();
    let loadingSeen = false;
    let handlingResult = false;
    const findHumanizeButton = () => document.getElementById("btn-humanizar") || [...document.querySelectorAll(".btn-text")].find((element) => element.textContent.trim().toLocaleLowerCase("es") === "humanizar artículo")?.closest("button, [role='button'], .btn");
    const findTokenFailure = () => {
      const failureWords = /no hay|sin saldo|insuficien|agotad|l[ií]mite|limit|error|fall[oó]|quota|exced|cr[eé]dit|too many|exhaust/i;
      const alerts = [...document.querySelectorAll('[role="alert"], [aria-live="assertive"], .toast, .alert, .notification, .swal2-popup, [class*="error"], [class*="Error"]')];
      return alerts.find((node) => {
        if (!node.getClientRects().length) return false;
        const text = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim();
        return text.length <= 700 && /tokens?/i.test(text) && failureWords.test(text);
      });
    };
    const check = async () => {
      const tokenFailure = findTokenFailure();
      if (tokenFailure) {
        const details = (tokenFailure.innerText || tokenFailure.textContent || "").replace(/\s+/g, " ").trim().slice(0, 220);
        stop();
        showNotice(`El humanizador mostró un aviso de tokens y detuve el proceso: ${details}. Revisa el aviso y vuelve a intentarlo cuando corresponda.`, true);
        return;
      }
      const humanize = document.getElementById("btn-humanizar");
      const label = humanize?.querySelector(".btn-text")?.textContent?.trim() || "";
      const loading = Boolean(humanize?.disabled && /humanizando/i.test(label));
      if (loading) loadingSeen = true;

      if (!handlingResult && loadingSeen && humanize && !humanize.disabled && !/humanizando/i.test(label)) {
        handlingResult = true;
        const countElement = await waitFor(() => document.getElementById("word-count-num"), 5000, "el contador de palabras del humanizador").catch(() => null);
        const rangeElement = document.getElementById("word-count-range");
        const countMatch = String(countElement?.textContent || "").match(/\d+/);
        const count = countMatch ? Number(countMatch[0]) : NaN;
        const rangeText = rangeElement?.textContent || "";
        const minMatch = rangeText.match(/(?:mínimo|minimo)\s*\(?\s*(\d+)/i);
        const minimum = minMatch ? Number(minMatch[1]) : 600;
        if (countElement && Number.isFinite(count) && count < minimum) {
          if (attemptNumber >= maxAttempts) {
            stop();
            showNotice(`El humanizador entregó ${count} palabras y siguió bajo el mínimo de ${minimum} tras ${maxAttempts} intentos. No autorrellené la entrada; puedes volver a pulsar Humanizar artículo.`, true);
            return;
          }
          showNotice(`El resultado tiene ${count} palabras; el mínimo es ${minimum}. Reintentando «Humanizar artículo» (${attemptNumber + 1}/${maxAttempts})…`);
          const retryButton = await waitFor(() => {
            const button = findHumanizeButton();
            return button && !button.disabled && button.getAttribute("aria-disabled") !== "true" ? button : null;
          }, 15000, "el botón habilitado para reintentar la humanización").catch(() => null);
          if (!retryButton) {
            stop();
            showNotice("El resultado quedó bajo el mínimo, pero no pude reintentar porque el botón «Humanizar artículo» no se habilitó.", true);
            return;
          }
          attemptNumber += 1;
          loadingSeen = false;
          handlingResult = false;
          attemptStartedAt = Date.now();
          progressStep(`Humanizar artículo: intento ${attemptNumber}/${maxAttempts}`, "Esperando el nuevo resultado…");
          retryButton.click();
          return;
        }
        if (!countElement || !Number.isFinite(count)) {
          stop();
          showNotice("No pude leer el contador de palabras del humanizador; no autorrellené para evitar usar un texto incompleto.", true);
          return;
        }
        const autofill = document.getElementById("btn-autofill");
        const visible = autofill && autofill.getClientRects().length > 0;
        if (autofill && visible && !autofill.disabled) {
          stop();
        captureHumanizedOutput();
          autofill.click();
          progressFinish("Humanización terminada. Se completó el autorrelleno; continúa con la creación de la entrada.");
          try { if (JSON.parse(localStorage.getItem("contraplano-autofill-pending") || "null")?.targetPostUrl) showExistingPostAction(); } catch {}
          showNotice("Terminó la humanización y se pulsó «Autorrellenar entrada».");
          return;
        }
      }

      if (Date.now() - attemptStartedAt >= 180000) {
        stop();
        showNotice(`El intento ${attemptNumber} de humanización superó 3 minutos. Revisa el humanizador.`, true);
      }
    };
    const observer = new MutationObserver(check);
    observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
    const poll = setInterval(check, 250);
    function stop() {
      observer.disconnect();
      clearInterval(poll);
    }
    check();
  }

  function showNotice(message, isError = false) {
    consoleEvent(isError ? "ERROR" : "INFO", message);
    if (isError) progressFinish(message, true);
    const notice = document.createElement("div");
    notice.textContent = `Autocompletar Contraplano v${EXTENSION_VERSION} · ${message}`;
    Object.assign(notice.style, {
      position: "fixed", zIndex: "2147483647", top: "16px", right: "16px",
      maxWidth: "min(480px, calc(100vw - 32px))", padding: "14px 18px",
      borderRadius: "8px", color: "#fff", background: isError ? "#9f2525" : "#176b3a",
      boxShadow: "0 4px 16px #0005", font: "600 14px/1.45 system-ui, sans-serif",
    });
    document.documentElement.appendChild(notice);
    setTimeout(() => notice.remove(), 8000);
  }

  function captureHumanizedOutput() {
    try {
      const pending = JSON.parse(localStorage.getItem("contraplano-autofill-pending") || "null");
      const output = document.getElementById("output-content");
      if (!pending || !output) return;
      pending.humanizedTitle = document.getElementById("meta-title")?.textContent.trim() || "";
      pending.focusKeyword = document.getElementById("meta-keyword")?.textContent.trim() || "";
      pending.humanizedHeading = output.querySelector("h1, h2, h3")?.innerText.trim() || "";
      pending.humanizedBody = output.innerText.trim();
      pending.humanizedHtml = output.innerHTML;
      pending.humanizedSlug = document.getElementById("meta-slug")?.textContent.trim() || "";
      pending.humanizedDescription = document.getElementById("meta-desc")?.textContent.trim() || "";
      sessionStorage.setItem("contraplano-autofill-pending", JSON.stringify(pending));
      localStorage.setItem("contraplano-autofill-pending", JSON.stringify(pending));
    } catch {}
  }

  function showExistingPostAction() {
    let pending;
    try { pending = JSON.parse(localStorage.getItem("contraplano-autofill-pending") || "null"); } catch {}
    if (!pending?.targetPostUrl || document.getElementById("contraplano-update-existing-entry")) return;
    const panel = document.createElement("div");
    panel.id = "contraplano-update-existing-entry";
    Object.assign(panel.style, { position: "fixed", zIndex: "2147483646", right: "20px", bottom: "20px", maxWidth: "360px", padding: "16px", borderRadius: "12px", color: "#fff", background: "#202536", boxShadow: "0 6px 24px #0008", font: "14px/1.45 system-ui, sans-serif" });
    const text = document.createElement("div");
    text.textContent = "Modo de prueba: puedes actualizar el borrador existente sin crear otra entrada.";
    const link = document.createElement("a");
    link.id = "contraplano-update-existing-entry-link";
    link.href = pending.targetPostUrl;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = "Actualizar entrada existente";
    Object.assign(link.style, { display: "inline-block", marginTop: "10px", padding: "9px 12px", borderRadius: "8px", color: "#fff", background: "#236b46", textDecoration: "none", fontWeight: "700" });
    link.addEventListener("click", () => {
      try {
        const current = JSON.parse(localStorage.getItem("contraplano-autofill-pending") || "null");
        if (current) { current.editExisting = true; localStorage.setItem("contraplano-autofill-pending", JSON.stringify(current)); }
      } catch {}
    });
    panel.append(text, link);
    document.documentElement.appendChild(panel);
  }

  function launchEditorWorkflow() {
    if (globalThis.__contraplanoEditorRunning) return;
    globalThis.__contraplanoEditorRunning = true;
    startEditorWorkflow().catch((error) => {
      const message = `No pude iniciar o continuar la preparación: ${error?.message || error}. Recarga la extensión y la pestaña si el navegador indica que la conexión se perdió.`;
      progressFinish(message, true);
      offerExistingRestart(message);
    }).finally(() => { globalThis.__contraplanoEditorRunning = false; });
  }

  function offerExistingRestart(message) {
    progressFinish(message, true);
    const panel = document.getElementById("contraplano-live-progress");
    if (!panel || panel.querySelector('[data-part="restart"]')) return;
    const button = document.createElement("button");
    button.dataset.part = "restart";
    button.textContent = "Iniciar preparación de esta entrada";
    Object.assign(button.style, { marginTop: "12px", padding: "9px 12px", color: "white", background: "#186b51", border: "0", borderRadius: "7px", cursor: "pointer" });
    button.onclick = () => {
      const target = new URL(location.href); target.hash = "";
      let previous;
      try { previous = JSON.parse(sessionStorage.getItem(`contraplano-existing-${params.get("post")}`) || localStorage.getItem("contraplano-autofill-pending") || "null"); } catch {}
      if (!previous) {
        try { previous = JSON.parse(sessionStorage.getItem(`contraplano-options-${params.get("post")}`) || "null"); } catch {}
      }
      const pending = { targetPostUrl: target.href, resumeExisting: true, editExisting: true, editorStarted: false, logPort: previous?.logPort || 0, logToken: previous?.logToken || "", category: previous?.category ?? "", reportBlock: previous?.reportBlock ?? previous?.category ?? "", autoPublish: previous?.autoPublish !== false, autoMRC: previous?.autoMRC !== false, manual: previous?.manual === true, publishAnyScore: previous?.publishAnyScore === true, imagePolicy: previous?.imagePolicy === "replace" ? "replace" : "missing" };
      sessionStorage.setItem(`contraplano-existing-${params.get("post")}`, JSON.stringify(pending));
      localStorage.setItem("contraplano-autofill-pending", JSON.stringify(pending));
      button.remove();
      launchEditorWorkflow();
    };
    panel.append(button);
  }

  async function editorMessage(message, timeout = 30000) {
    let timer;
    try {
      return await Promise.race([
        chrome.runtime.sendMessage(message),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`La extensión no recibió respuesta de WordPress en ${Math.ceil(timeout / 1000)} segundos. Revisa que esté cargada la versión actual y recarga esta pestaña.`)), timeout); }),
      ]);
    } finally { clearTimeout(timer); }
  }

  // Entradas creadas con "Escribir mi noticia": se recuerdan para respetar su texto aunque se continuen despues.
  async function rememberManualPost(postId) {
    try {
      const key = "contraplanoManualPosts", id = String(postId || "");
      if (!id) return;
      const stored = (await chrome.storage.local.get(key))[key];
      const list = Array.isArray(stored) ? stored : [];
      if (!list.some((item) => item.id === id)) {
        list.push({ id, at: Date.now() });
        await chrome.storage.local.set({ [key]: list.slice(-300) });
      }
    } catch {}
  }

  async function isRememberedManualPost(postId) {
    try {
      const key = "contraplanoManualPosts";
      const stored = (await chrome.storage.local.get(key))[key];
      return Array.isArray(stored) && stored.some((item) => item.id === String(postId));
    } catch { return false; }
  }

  async function createManualDraft(data) {
    const request = { type: "CONTRAPLANO_CREATE_MANUAL_POST", title: data.title, body: data.body };
    const readyStart = Date.now();
    let started, detail = "";
    while (Date.now() - readyStart < 30000) {
      progressDetail(`Esperando el editor de bloques: ${Math.floor((Date.now() - readyStart) / 1000)}/30 s. ${detail}`);
      const result = await editorMessage({ ...request, phase: data.recoverCurrent ? "recover" : "start" }, Math.min(10000, Math.max(1, 30000 - (Date.now() - readyStart))));
      if (result?.error) throw new Error(result.error);
      if (result?.saved && result.postId) { await rememberManualPost(result.postId); return result; }
      if (result?.started && result.postId) { started = result; break; }
      detail = result?.detail || "WordPress todavía está cargando.";
      await new Promise((resolve) => setTimeout(resolve, 700));
    }
    if (!started) throw new Error(`WordPress no terminó de preparar el editor en 30 segundos. ${detail} Tus textos siguen disponibles; no creé otra entrada.`);
    data.manualPostId = started.postId;
    await rememberManualPost(started.postId);
    sessionStorage.setItem("contraplano-manual-launch", JSON.stringify(data));
    progressStep("Confirmar el guardado del borrador", `Textos colocados en la entrada ${started.postId}. Comprobando el contenido guardado en WordPress; máximo 90 segundos…`);
    consoleEvent("INFO", `Borrador manual ${started.postId}: textos colocados; comprobaré el guardado sin volver a insertarlos.`);
    const saveStart = Date.now();
    while (Date.now() - saveStart < 90000) {
      const result = await editorMessage({ ...request, phase: "status" }, Math.min(12000, Math.max(1, 90000 - (Date.now() - saveStart))));
      if (result?.error) throw new Error(result.error);
      if (result?.saved && result.postId) {
        progressResult(`Borrador ${result.postId} guardado y comprobado: ${result.source || "WordPress"}.`);
        return result;
      }
      detail = result?.detail || "WordPress todavía no confirmó el contenido guardado.";
      progressDetail(`Borrador ${started.postId}: ${Math.floor((Date.now() - saveStart) / 1000)}/90 s. ${detail}`);
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    throw new Error(`No pude confirmar el guardado del borrador ${started.postId} en 90 segundos. ${detail} Tus textos están colocados en el editor. Revisa Guardar como borrador en esta misma entrada; no abras otra para reintentar.`);
  }

  async function startManualPostWorkflow() {
    if (globalThis.__contraplanoManualRunning) return;
    let data;
    try { data = JSON.parse(sessionStorage.getItem("contraplano-manual-launch") || "null"); } catch {}
    if (!data?.manual || !data.title?.trim() || !data.body?.trim()) return;
    if (data.manualPostId && location.pathname.endsWith("/wp-admin/post-new.php")) {
      location.replace(new URL(`/wp-admin/post.php?post=${data.manualPostId}&action=edit`, location.origin).href);
      return;
    }
    globalThis.__contraplanoManualRunning = true;
    history.replaceState(null, "", location.pathname + location.search);
    try {
      progressStep("Crear noticia manual", "Conectando con el preparador; no se usará el humanizador…");
      const connection = await connectConsole(data);
      if (!connection?.registered) throw new Error(connection?.error || "No pude conectar con el preparador.");
      let targetPostUrl = data.createdPostUrl;
      if (!targetPostUrl) {
        progressStep("Guardar tus textos en un borrador", "Esperando el editor de WordPress para crear los párrafos con tu contenido…");
        const created = await createManualDraft(data);
        if (!created?.postId || created.error) throw new Error(created?.error || "WordPress no confirmó el nuevo borrador.");
        targetPostUrl = new URL(`/wp-admin/post.php?post=${created.postId}&action=edit`, location.origin).href;
        data.createdPostUrl = targetPostUrl;
        sessionStorage.setItem("contraplano-manual-launch", JSON.stringify(data));
      }
      const pending = { ...data, targetPostUrl, manualCreated: true, resumeExisting: true, editExisting: true, editorStarted: false };
      localStorage.setItem("contraplano-autofill-pending", JSON.stringify(pending));
      const bytes = new TextEncoder().encode(JSON.stringify(pending));
      let encoded = "";
      for (const byte of bytes) encoded += String.fromCharCode(byte);
      encoded = btoa(encoded).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
      progressResult("Borrador manual creado; continuaré con la imagen y los ajustes elegidos.");
      sessionStorage.removeItem("contraplano-manual-launch");
      try {
        location.replace(targetPostUrl + "#codexExisting=" + encoded);
        // WordPress cambia por si solo la direccion de esta pestaña a post.php?post=ID al guardar un borrador
        // nuevo (sin recargar), y tambien ocurre si la pestaña se recargo sobre la entrada. En ambos casos
        // agregar solo el #hash no recarga la pagina y nadie lo escucha: recargar para que el flujo continue
        // con la direccion y los datos correctos. Si la direccion es otra, el navegador navega por si solo.
        const target = new URL(targetPostUrl);
        if (location.pathname === target.pathname && location.search === target.search) location.reload();
      }
      catch (error) { sessionStorage.setItem("contraplano-manual-launch", JSON.stringify(data)); throw error; }
    } catch (error) {
      progressFinish(`No pude crear la noticia manual: ${error.message}`, true);
      const panel = document.getElementById("contraplano-live-progress");
      if (panel && !panel.querySelector('[data-part="manual-retry"]')) {
        const retry = document.createElement("button");
        retry.dataset.part = "manual-retry";
        retry.textContent = "Recomprobar este borrador";
        Object.assign(retry.style, { marginTop: "12px", padding: "9px 12px", cursor: "pointer" });
        retry.onclick = () => { retry.remove(); startManualPostWorkflow(); };
        panel.append(retry);
      }
    } finally { globalThis.__contraplanoManualRunning = false; }
  }

  async function startEditorWorkflow() {
    const existingKey = `contraplano-existing-${params.get("post")}`;
    const existingMatch = location.hash.match(/(?:^#|&)codexExisting=([A-Za-z0-9_-]+)/);
    if (existingMatch) progressStep("Conectar con la entrada", "Leyendo los datos enviados por el preparador…");
    if (existingMatch) {
      try {
        const encoded = existingMatch[1].replace(/-/g, "+").replace(/_/g, "/");
        const data = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(encoded + "=".repeat((4 - encoded.length % 4) % 4)), (char) => char.charCodeAt(0))));
        connectConsole(data);
        data.resumeExisting = true;
        data.editExisting = true;
        data.editorStarted = false;
        sessionStorage.setItem(existingKey, JSON.stringify(data));
        localStorage.setItem("contraplano-autofill-pending", JSON.stringify(data));
        history.replaceState(null, "", location.pathname + location.search);
      } catch {
        editorNotice("No pude leer los datos de la entrada existente.", true);
        return;
      }
    }
    let pending, pendingSource = "none";
    try {
      const scoped = sessionStorage.getItem(existingKey);
      const tabTask = sessionStorage.getItem("contraplano-autofill-pending");
      const sharedTask = localStorage.getItem("contraplano-autofill-pending");
      const raw = scoped || tabTask || sharedTask;
      pendingSource = scoped ? "post-tab" : tabTask ? "tab" : sharedTask ? "shared" : "none";
      pending = JSON.parse(raw || "null");
    } catch {}
    if (!pending) {
      const last = sessionStorage.getItem("contraplano-last-result");
      if (last) { sessionStorage.removeItem("contraplano-last-result"); progressFinish(last, true); }
      else offerExistingRestart("Esta entrada está abierta, pero no hay una preparación activa. Puedes iniciarla aquí sin pasar por el humanizador.");
      return;
    }
    // Si el navegador no heredó sessionStorage al abrir WordPress, solo
    // aceptamos la tarea compartida durante la ventana breve de lanzamiento.
    // Evita reutilizar una noticia que quedó guardada de una sesión anterior.
    if (!pending.editExisting && !pending.targetPostUrl && pendingSource === "shared") {
      const age = Date.now() - Number(pending.launchAt || 0);
      if (!Number.isFinite(age) || age < 0 || age > 20 * 60 * 1000) {
        editorNotice("La tarea de humanización ya venció o pertenece a otra pestaña. Vuelve al preparador y abre de nuevo esta noticia; no modifiqué la entrada.", true);
        return;
      }
    }
    progressStep("Conectar con el preparador", "Comprobando la conexión local antes de preparar WordPress…");
    const registration = await connectConsole(pending);
    if (!registration?.registered) { offerExistingRestart(registration?.error || "La extensión no pudo confirmar la conexión con el preparador."); return; }
    if (pending.editorStarted) { offerExistingRestart("Hay un proceso anterior marcado como iniciado. Si se interrumpió o recargaste la pestaña, puedes reiniciarlo aquí."); return; }
    const postId = params.get("post");
    if (!postId) return;
    if (!pending.manual && await isRememberedManualPost(postId)) {
      pending.manual = true;
      consoleEvent("INFO", `Entrada ${postId}: la creó este programa con «Escribir mi noticia». Conservo sus párrafos y su título, sin reescritura por IA.`);
    }
    if (pending.publishAnyScore === true) consoleEvent("INFO", `Entrada ${postId}: la extensión recibió la marca «noticia encargada» (texto respetado; se publicará sin exigir 85 puntos).`);
    sessionStorage.setItem(`contraplano-options-${postId}`, JSON.stringify({ category: pending.category ?? "", reportBlock: pending.reportBlock ?? pending.category ?? "", autoPublish: pending.autoPublish !== false, autoMRC: pending.autoMRC !== false, manual: pending.manual === true, publishAnyScore: pending.publishAnyScore === true, imagePolicy: pending.imagePolicy === "replace" ? "replace" : "missing" }));
    progressStep("Abrir entrada", "Esperando que WordPress cargue el editor…");
    if (pending.editExisting) {
      let targetPostId = "";
      try { targetPostId = new URL(pending.targetPostUrl).searchParams.get("post") || ""; } catch {}
      if (!targetPostId || targetPostId !== postId) {
        editorNotice(`No actualicé la entrada: la URL elegida corresponde a ${targetPostId || "un ID inválido"}, pero esta pestaña es ${postId}.`, true);
        return;
      }
      if (pending.resumeExisting) {
        const snapshot = await editorMessage({ type: "CONTRAPLANO_READ_EXISTING_POST", postId }).catch((error) => ({ error: error.message }));
        if (!snapshot || snapshot.error) { offerExistingRestart(snapshot?.error || "No pude leer el borrador existente."); return; }
        pending.title = pending.humanizedTitle = snapshot.title;
        pending.body = pending.humanizedBody = snapshot.body;
        pending.focusKeyword = snapshot.keyword || "";
        pending.currentPostStatus = snapshot.status || "draft";
        pending.savedRankMathScore = snapshot.rankMathScore ?? null;
        localStorage.setItem("contraplano-autofill-pending", JSON.stringify(pending));
        editorNotice(`Borrador ${postId} abierto. Continúo sobre su contenido actual.`);
      } else {
      const title = pending.humanizedTitle || pending.humanizedHeading || pending.title;
      const html = pending.humanizedHtml || "";
      if (!title || !html) {
        editorNotice("No encontré el título o el contenido humanizado para actualizar el borrador.", true);
        return;
      }
      const update = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_UPDATE_EXISTING_POST", postId, title, html }).catch((error) => ({ error: error.message }));
      if (!update || update.error || !update.updated) {
        editorNotice(update?.error || "Gutenberg no confirmó la actualización del borrador.", true);
        return;
      }
      editorNotice(`Borrador ${postId} identificado. Reemplacé su título y contenido con el resultado del humanizador; sigo preparando la entrada…`);
      }
    }

    const startedAt = Date.now();
    const findEditorText = () => {
      const frameDocs = [...document.querySelectorAll("iframe")].map((frame) => {
        try { return frame.contentDocument; } catch { return null; }
      }).filter(Boolean);
      const docs = [document, ...frameDocs];
      const titleCandidates = docs.flatMap((doc) => [...doc.querySelectorAll(".editor-post-title__input, [aria-label*='Añadir título'], [aria-label*='Add title']")]);
      const titleEl = titleCandidates.find((element) => (element.value || element.textContent || "").trim());
      const title = titleEl?.value || titleEl?.textContent || "";
      const body = docs.map((doc) => doc.querySelector(".block-editor-block-list__layout")?.innerText || doc.querySelector(".editor-styles-wrapper")?.innerText || "").find((text) => text.trim().length > 0) || "";
      const allText = docs.map((doc) => doc.body?.innerText || "").join(" ");
      return { title, body, allText };
    };
    const normalize = (value) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("es");
    const stopWords = new Set(["para", "desde", "durante", "sobre", "cuando", "entre", "hacia", "habria", "habian", "quienes", "donde", "esta", "este", "estos", "estas", "tras", "ante", "bajo", "contra", "fueron", "seria", "serian", "mas", "como", "con", "por", "del", "los", "las", "una", "uno", "unos", "unas", "que", "fue", "son", "sus", "dos", "tres", "cada", "todo", "toda", "sobre", "incautacion", "drogas", "droga"]);
    const expectedTitle = pending.humanizedTitle || pending.humanizedHeading || pending.title;
    const focusKeyword = pending.focusKeyword || "";
    const tokens = [...new Set(normalize(expectedTitle).match(/[a-z0-9]+/g)?.filter((word) => word.length >= 4 && !stopWords.has(word)) || [])];
    const requiredMatches = Math.min(3, tokens.length);
    const verifyMatch = () => {
      const current = findEditorText();
      const combined = normalize(current.title + " " + current.body + " " + current.allText);
      const matches = tokens.filter((word) => combined.includes(word)).length;
      const keywordMatched = !focusKeyword || combined.includes(normalize(focusKeyword));
      const exactTitleMatched = expectedTitle && combined.includes(normalize(expectedTitle));
      const bodyLoaded = current.body.trim().length > (pending.manual ? 0 : 60);
      const ok = pending.editExisting
        ? Boolean(bodyLoaded)
        : Boolean(bodyLoaded && keywordMatched && (exactTitleMatched || matches >= requiredMatches));
      return { current, matches, keywordMatched, exactTitleMatched, bodyLoaded, ok };
    };

    while (Date.now() - startedAt < 45000) {
      const result = verifyMatch();
      if (result.ok) {
        pending.editorStarted = true;
        if (pending.resumeExisting) sessionStorage.setItem(existingKey, JSON.stringify(pending));
        sessionStorage.setItem("contraplano-autofill-pending", JSON.stringify(pending));
        localStorage.setItem("contraplano-autofill-pending", JSON.stringify(pending));
        editorNotice(`Pestaña nueva detectada: entrada ${postId}. Su título y contenido coinciden con la noticia. Preparando bloques…`);
        const completed = [];
        const failures = [];
        const attempt = async (label, action, fallback = null) => {
          progressStep(label);
          try {
            const value = await action();
            completed.push(label);
            progressResult(label);
            return value;
          } catch (error) {
            const reason = error?.message || String(error);
            failures.push(`${label}: ${reason}`);
            progressResult(label, reason);
            editorNotice(`Falló «${label}»: ${reason}. Continúo con los demás pasos.`, true);
            return fallback;
          }
        };
        let initialReview = null;
        if (pending.resumeExisting && !pending.manualCreated) {
          progressStep("Comprobar puntaje antes de preparar", "Revisando si la entrada ya está lista para publicar…");
          try { initialReview = await readFinalRankMathScore(pending.currentPostStatus === "publish" ? pending.savedRankMathScore : null); }
          catch (error) { consoleEvent("AVISO", `No pude leer el puntaje inicial: ${error?.message || error}. ${pending.currentPostStatus === "publish" ? "Continuaré hacia MRC sin modificar la entrada publicada." : "Continuaré con los ajustes."}`); }
        }
        const wasPublished = pending.currentPostStatus === "publish";
        const skipPreparation = wasPublished || Boolean(!pending.manualCreated && initialReview && initialReview.score >= 85);
        const findCurrentImage = () => {
          const doc = getEditorDocument();
          const imageBlock = doc.querySelector('[data-type="core/image"]');
          const image = imageBlock?.querySelector("img") || doc.querySelector(".block-editor-block-list__layout img");
          return image?.src ? { imageBlock, imageUrl: image.src } : null;
        };
        let imageResult = pending.resumeExisting ? findCurrentImage() : null;
        let imageAdded = false;
        if (skipPreparation) {
          progressStep("Entrada lista: omitir preparación", wasPublished ? "Entrada ya publicada: continúo directamente a MRC usando su contenido e imagen actuales." : `Rank Math ${initialReview.score}/100. Continúo con el guardado, la publicación y MRC usando la imagen actual.`);
          progressResult(wasPublished ? "preparación omitida: entrada ya publicada" : "preparación omitida: puntaje de 85 o más");
          if (pending.imageToken && (pending.imagePolicy === "replace" || !imageResult)) {
            imageResult = await attempt(pending.imagePolicy === "replace" && imageResult ? "reemplazar imagen de la entrada" : "subir y colocar imagen", () => insertImageAfterFirstHeading(pending));
            imageAdded = Boolean(imageResult?.changed);
          }

        } else {
          await attempt("conversión a bloques", () => convertIfNeeded());
          const changed = pending.manual ? 0 : await attempt("quitar negritas de párrafos", () => removeBoldFromParagraphs(), 0);
          const paragraphResult = await attempt("revisar párrafos largos según Rank Math", () => shortenLongParagraphs(pending), { changed: 0, localFallback: 0 });
          if (pending.manual) progressResult("Texto manual conservado, sin reescritura por IA");
          const shortenedParagraphs = paragraphResult?.changed || 0;
          const currentImage = pending.resumeExisting ? findCurrentImage() : null;
          imageAdded = Boolean(pending.imageToken) && (!currentImage || pending.imagePolicy === "replace");
          imageResult = imageAdded ? await attempt(currentImage ? "reemplazar imagen de la entrada" : "subir y colocar imagen", () => insertImageAfterFirstHeading(pending)) : currentImage;
          imageAdded = Boolean(imageAdded && imageResult && imageResult.changed !== false);
          if (currentImage && !imageAdded) progressResult("reutilizar imagen de WordPress, sin volver a subirla");
          await attempt("añadir bloque Espaciador", () => insertNamedBlock("Espaciador"));
          await attempt("añadir bloque Nombre del autor", () => insertNamedBlock("Nombre del autor"));
          await attempt("añadir bloque Social Links", () => insertNamedBlock("Social Links"));
          const seoFallback = { keyword: pending.focusKeyword || pending.humanizedKeyword || "", title: "", slug: "", description: "" };
          const seo = await attempt("ajustes de Rank Math", () => optimizeRankMathSnippet(pending), seoFallback);
          const imageBlock = imageResult?.imageBlock || null;
          const altSet = imageBlock ? await attempt("texto alternativo", () => setImageAlt(imageBlock, seo.keyword || pending.focusKeyword || pending.title), false) : false;
          const featuredAltSet = imageAdded && imageResult && !imageResult.featuredSet ? await attempt("imagen destacada", () => setFeaturedImage(imageResult.attachmentId, imageResult.imageUrl, pending.imageName, seo.keyword || pending.focusKeyword || pending.title), false) : false;
          const taxonomy = await attempt("categorías y etiquetas", () => setPostTaxonomies(), { categories: "sin confirmar", tags: "sin confirmar", errors: [] });
          for (const error of taxonomy.errors || []) failures.push(error);
        }
        await attempt("categoría elegida", async () => {
          const result = await editorMessage({ type: "CONTRAPLANO_SET_CATEGORY", postId, category: pending.category ?? "" }, 40000);
          if (!result?.confirmed) throw new Error(result?.error || "WordPress no confirmó la categoría seleccionada.");
          progressResult(`Categoría: ${result.category}`);
        });
        const publishedImageSaved = wasPublished && imageAdded ? await attempt("guardar cambio de imagen en entrada publicada", async () => {
          const result = await editorMessage({ type: "CONTRAPLANO_SAVE_IMAGE_CHANGE", postId, attachmentId: imageResult.attachmentId }, 40000);
          if (!result?.saved) throw new Error(result?.error || "No pude confirmar el cambio de imagen en la entrada publicada.");
          return true;
        }, false) : wasPublished;
        const saveConfirmed = wasPublished ? publishedImageSaved : await attempt("guardar borrador", async () => {
          const request = { type: "CONTRAPLANO_SAVE_DRAFT", postId };
          const startedAt = Date.now();
          let phase = "start", lastNotice = -10;
          while (Date.now() - startedAt < 90000) {
            const elapsed = Math.floor((Date.now() - startedAt) / 1000);
            progressDetail(`Confirmando el guardado de la entrada ${postId}: ${elapsed}/90 s. Consultando WordPress sin recrear la noticia…`);
            const result = await editorMessage({ ...request, phase }, Math.min(15000, Math.max(1000, 90000 - (Date.now() - startedAt))));
            if (result?.error) throw new Error(result.error);
            if (result?.saved) {
              consoleEvent("OK", `Entrada ${postId}: guardado confirmado por ${result.source || "WordPress"}.`);
              return true;
            }
            if (elapsed - lastNotice >= 10) { consoleEvent("ESPERA", `Guardar entrada ${postId}: ${result?.detail || "esperando confirmación"} (${elapsed}/90 s)`); lastNotice = elapsed; }
            if (result?.detail) progressDetail(result.detail);
            phase = "status";
            await new Promise((resolve) => setTimeout(resolve, 1200));
          }
          throw new Error(`No pude confirmar los cambios de la entrada ${postId} en WordPress después de 90 segundos. No publiqué sin confirmar el guardado; puedes reintentar sobre esta misma entrada.`);
        }, false);
        let finalReview = initialReview;
        if (!wasPublished || imageAdded) finalReview = await attempt("revisión final de Rank Math", () => readFinalRankMathScore(), null);
        if (wasPublished && !finalReview) consoleEvent("AVISO", "La entrada ya está publicada. Continúo a MRC; el puntaje SEO quedará pendiente si Rank Math no lo muestra.");
        let published = wasPublished;
        const autoPublish = pending.autoPublish !== false;
        const autoMRC = pending.autoMRC !== false;
        const anyScore = pending.publishAnyScore === true;
        if (anyScore && autoPublish && !wasPublished) consoleEvent("INFO", `Noticia encargada: texto respetado; publico sin exigir 85 puntos (Rank Math ${finalReview ? finalReview.score + "/100" : "sin leer"}).`);
        if (autoPublish && !wasPublished && saveConfirmed && (anyScore || (finalReview && finalReview.score >= 85)) && failures.length === 0) {
          published = await attempt(anyScore ? "publicar noticia encargada" : "publicar por puntaje Rank Math ≥85", async () => {
            progressDetail("Publicación en dos pasos: abrir Publicar, confirmar en el panel y esperar el guardado de WordPress.");
            const result = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_PUBLISH_DRAFT" });
            if (!result || result.error || !result.published) throw new Error(result?.error || "No recibí confirmación de publicación.");
            return true;
          }, false);
        }
        if (published && !wasPublished && saveConfirmed) {
          await chrome.runtime.sendMessage({ type: 'CONTRAPLANO_RECORD_PUBLICATION', postId }).catch(() => null);
        }
        let reportOpened = false;
        if (autoMRC && published && saveConfirmed && failures.length === 0) {
          reportOpened = await attempt("abrir MRC Editor y preparar reporte", async () => {
            const publishedLink = await waitFor(() => [...document.querySelectorAll('a[aria-label="Ver la entrada"]')].find((link) => link.href && !link.href.includes("preview=true")), 12000, "el enlace público de la entrada");
            const entryTitleElement = getEditorDocument().querySelector(".editor-post-title__input") || document.querySelector(".editor-post-title__input");
            const reportEditor = getEditorDocument();
            const reportVideo = reportEditor.querySelector('[data-type="core/video"] video[src], .wp-block-video video[src], video[src], [data-type="core/video"] source[src], .wp-block-video source[src], source[src]');
            const reportVideoUrl = (() => {
              const raw = reportVideo?.currentSrc || reportVideo?.src || reportVideo?.getAttribute("src") || "";
              try {
                const url = new URL(raw, location.href);
                return url.protocol === "https:" && ["contraplano.cl", "www.contraplano.cl"].includes(url.hostname)
                  && url.pathname.startsWith("/wp-content/uploads/") && /\.(mp4|webm|mov|m4v)$/i.test(url.pathname) ? url.href : "";
              } catch { return ""; }
            })();
            const featuredMedia = await editorMessage({ type: "CONTRAPLANO_GET_FEATURED_MEDIA", postId });
            const reportImageUrl = imageResult?.imageUrl || reportEditor.querySelector('[data-type="core/image"] img, .wp-block-image img')?.src || featuredMedia?.imageUrl || "";
            const reportPayload = {
              postId, category: pending.category ?? "", reportBlock: pending.reportBlock ?? pending.category ?? "", logPort: pending.logPort || 0, logToken: pending.logToken || "",
              title: String(entryTitleElement?.value || entryTitleElement?.textContent || pending.humanizedTitle || pending.title || "").trim(),
              postUrl: publishedLink.href,
              imageUrl: reportImageUrl,
              videoUrl: reportImageUrl ? "" : reportVideoUrl,
              imageToken: imageAdded ? pending.imageToken || "" : "", imagePort: pending.imagePort || 0,
              imageName: pending.imageName || "imagen-noticia.jpg",
              articleBody: getEditorDocument().querySelector(".block-editor-block-list__layout")?.innerText || pending.humanizedBody || pending.body || "",
              rankMathScore: finalReview?.score ?? null, description: "",
            };
            const stored = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_STORE_REPORT_PAYLOAD", payload: reportPayload });
            if (!stored?.saved) throw new Error(stored?.error || "No pude preparar los datos del reporte.");
            const opened = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_OPEN_REPORTS_TAB" });
            if (!opened?.opened) throw new Error(opened?.error || "No pude abrir la pestaña de MRC Editor.");
            return true;
          }, false);
        }
        const rankSummary = finalReview ? `Rank Math ${finalReview.score}/100` : "puntaje sin confirmar";
        const outcome = published
          ? `Entrada ${postId} publicada. ${rankSummary}. ${!autoMRC ? "MRC automático desactivado por tu elección." : reportOpened ? "MRC Editor abierto; el formulario del reporte continuará en su pestaña." : "No se completó la apertura de MRC."}${failures.length ? ` Incidencias: ${failures.join("; ")}` : ""}`
          : `Entrada ${postId}: ${rankSummary}. ${saveConfirmed ? "Borrador guardado." : "Guardado sin confirmar."} ${!autoPublish ? "Publicación automática desactivada por tu elección." : `No se publicó: ${failures.length ? failures.join("; ") : finalReview ? `el puntaje es ${finalReview.score} y se requieren 85 puntos` : "no se pudo confirmar el puntaje"}.`}${autoMRC ? " MRC requiere que la entrada esté publicada." : " MRC automático desactivado."}${!autoPublish && failures.length ? ` Incidencias: ${failures.join("; ")}` : ""}`;
        sessionStorage.removeItem(existingKey);
        sessionStorage.removeItem("contraplano-autofill-pending");
        localStorage.removeItem("contraplano-autofill-pending");
        editorNotice(outcome, failures.length > 0);
        progressFinish(outcome, failures.length > 0 || (autoPublish && !published));
        if (failures.length || (autoPublish && !published)) sessionStorage.setItem("contraplano-last-result", outcome);
        if (pending.editExisting && !pending.resumeExisting && saveConfirmed) await chrome.runtime.sendMessage({ type: "CONTRAPLANO_CLOSE_HUMANIZER_TAB" }).catch(() => null);
        if (saveConfirmed) {
          await new Promise((resolve) => setTimeout(resolve, 3200));
          window.location.reload();
        }
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    const finalCheck = verifyMatch();
    editorNotice(`Me detuve sin modificar la entrada ${postId}: no pude confirmar que corresponda con «${expectedTitle}»${focusKeyword ? ` y la frase «${focusKeyword}»` : ""} (coincidieron ${finalCheck.matches} palabras del titular).`, true);
  }

  function connectConsole(data) {
    try {
      const message = data?.logPort && data?.logToken
        ? { type: "CONTRAPLANO_REGISTER_CONSOLE", port: data.logPort, token: data.logToken, version: EXTENSION_VERSION }
        : { type: "CONTRAPLANO_CHECK_CONSOLE" };
      return chrome.runtime.sendMessage(message).then((result) => result || { registered: false, error: "La extensión no respondió al registro local. Recarga la extensión completa y la pestaña." }).catch((error) => ({ registered: false, error: error.message }));
    } catch (error) { return Promise.resolve({ registered: false, error: error.message }); }
  }

  function consoleEvent(level, message) {
    try {
      return chrome.runtime.sendMessage({ type: "CONTRAPLANO_CONSOLE_EVENT", level, message: String(message || "").slice(0, 2400), diagnostic: diagnosticContext() }).catch(() => ({ logged: false }));
    } catch { return Promise.resolve({ logged: false }); }
  }

  function progressStep(label, detail = "") {
    diagnosticState.step = diagnosticStep(label);
    diagnosticState.started = Date.now();
    consoleEvent("PASO", `${label}${detail ? ` — ${detail}` : ""}`);
    if (!document.getElementById("contraplano-progress-styles")) {
      const style = document.createElement("style");
      style.id = "contraplano-progress-styles";
      style.textContent = `
        @keyframes cpEnter { from { opacity:0; transform:translateY(14px); } to { opacity:1; transform:translateY(0); } }
        @keyframes cpSpin { to { transform:rotate(360deg); } }
        @keyframes cpActivity { from { transform:translateX(-110%); } to { transform:translateX(270%); } }
        @keyframes cpExit { to { opacity:0; transform:translateY(10px); } }
        #contraplano-live-progress { animation:cpEnter .24s ease-out; overflow:hidden; }
        #contraplano-live-progress > strong::before { content:""; display:inline-block; width:12px; height:12px; margin-right:9px; vertical-align:-2px; border:2px solid #ffffff40; border-top-color:#7de3ba; border-radius:50%; animation:cpSpin .9s linear infinite; }
        #contraplano-live-progress::after { content:""; position:absolute; left:0; bottom:0; width:40%; height:3px; background:linear-gradient(90deg,transparent,#7de3ba,transparent); animation:cpActivity 1.8s ease-in-out infinite; }
        #contraplano-live-progress [data-part="step"] { margin-top:12px; font-weight:700; font-size:16px; line-height:1.3; }
        #contraplano-live-progress [data-part="action"] { margin-top:12px; padding:10px 12px; border-radius:8px; background:#ffffff12; border-left:3px solid #7de3ba; font-weight:600; }
        #contraplano-live-progress [data-part="details"] { margin-top:12px; border-top:1px solid #ffffff25; padding-top:10px; }
        #contraplano-live-progress summary { cursor:pointer; color:#cfdae4; font-size:12px; }
        #contraplano-live-progress [data-part="full"], #contraplano-live-progress [data-part="log"] { max-height:140px; overflow:auto; overflow-wrap:anywhere; font-size:12px; color:#b3c5d5; }
        #contraplano-live-progress [data-part="full"] { margin-top:8px; }
        #contraplano-live-progress [data-part="detail"] { margin-top:5px; color:#e0e9f2; }
        #contraplano-live-progress [data-part="time"], #contraplano-live-progress [data-part="log"] { margin-top:8px; color:#b3c5d5; font-size:12px; }
        #contraplano-live-progress[data-state="success"] > strong::before { content:"✓"; border:0; animation:none; color:#7de3ba; }
        #contraplano-live-progress[data-state="error"] > strong::before { content:"!"; border:0; animation:none; color:#ffd287; font-weight:bold; }
        #contraplano-live-progress[data-state="success"]::after, #contraplano-live-progress[data-state="error"]::after { width:100%; animation:none; background:#7de3ba; }
        #contraplano-live-progress[data-state="error"]::after { background:#ffd287; }
        @media (prefers-reduced-motion:reduce) { #contraplano-live-progress, #contraplano-live-progress::after, #contraplano-live-progress > strong::before { animation:none !important; } }
      `;
      document.documentElement.appendChild(style);
    }
    let panel = document.getElementById("contraplano-live-progress");
    if (!panel) {
      panel = document.createElement("div");
      panel.id = "contraplano-live-progress";
      Object.assign(panel.style, { position: "fixed", bottom: "18px", left: "18px", zIndex: "2147483647", width: "360px", maxWidth: "calc(100vw - 36px)", padding: "16px", borderRadius: "12px", background: "#202d3a", color: "white", boxShadow: "0 6px 24px #0006", font: "13px/1.5 system-ui,sans-serif" });
      const heading = document.createElement("strong"); heading.textContent = `Contraplano v${EXTENSION_VERSION}`;
      const close = document.createElement("button"); close.textContent = "×"; close.setAttribute("aria-label", "Cerrar progreso");
      Object.assign(close.style, { float: "right", color: "white", background: "transparent", border: "0", cursor: "pointer", fontSize: "20px" });
      close.onclick = () => { clearInterval(panel._progress.timer); panel.remove(); };
      panel.append(close, heading);
      for (const key of ["step", "detail", "action", "time"]) { const node = document.createElement("div"); node.dataset.part = key; panel.append(node); }
      const details = document.createElement("details"); details.dataset.part = "details";
      const summary = document.createElement("summary"); summary.textContent = "Ver detalles del proceso";
      const full = document.createElement("div"); full.dataset.part = "full";
      const log = document.createElement("div"); log.dataset.part = "log";
      details.append(summary, full, log); panel.append(details);
      panel._progress = { started: Date.now(), stepStarted: Date.now(), logs: [] };
      document.documentElement.appendChild(panel);
    }
    const state = panel._progress;
    for (const oldRetry of panel.querySelectorAll('[data-retry="report"]')) oldRetry.remove();
    panel.dataset.state = "running";
    panel.style.animation = "";
    clearInterval(state.timer); clearTimeout(state.dismiss);
    state.stepStarted = Date.now(); state.label = label; state.done = false; state.lastHeartbeat = 0;
    panel.querySelector('[data-part="step"]').textContent = `En curso: ${label}`;
    if (!globalThis.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches) panel.querySelector('[data-part="step"]').animate?.([{ opacity: 0.35, transform: "translateY(3px)" }, { opacity: 1, transform: "translateY(0)" }], { duration: 180, easing: "ease-out" });
    renderProgressMessage(panel, detail);
    const tick = () => {
      const elapsed = Math.floor((Date.now()-state.stepStarted)/1000);
      panel.querySelector('[data-part="time"]').textContent = `Paso: ${elapsed} s · Total: ${Math.floor((Date.now()-state.started)/1000)} s`;
      if (elapsed - state.lastHeartbeat >= 15) {
        state.lastHeartbeat = elapsed;
        consoleEvent("ESPERA", `${state.label}: ${elapsed} segundos. ${panel.querySelector('[data-part="detail"]').textContent}`);
      }
    };
    tick(); state.timer = setInterval(tick, 1000);
  }

  function renderProgressMessage(panel, message, copy = null) {
    const text = String(message || "");
    const short = text.length <= 210 ? text : (text.match(/^.{1,210}?[.!?](?:\s|$)/)?.[0]?.trim() || "El proceso tiene información adicional. Abre los detalles para verla.");
    panel.querySelector('[data-part="detail"]').textContent = copy?.reason || short;
    const action = panel.querySelector('[data-part="action"]');
    action.textContent = copy?.action || "";
    action.hidden = !copy?.action;
    panel.querySelector('[data-part="full"]').textContent = text;
  }

  function progressDetail(message) {
    const panel = document.getElementById("contraplano-live-progress");
    if (panel && !panel._progress.done) {
      renderProgressMessage(panel, message);
      if (panel._progress.lastLoggedDetail !== message) { consoleEvent("INFO", message); panel._progress.lastLoggedDetail = message; }
    }
  }

  function progressResult(label, error = "") {
    diagnosticState.recent.push(diagnosticStep(label) + (error ? ':fail' : ':ok'));
    diagnosticState.recent = diagnosticState.recent.slice(-8);
    consoleEvent(error ? "ERROR" : "OK", `${label}${error ? `: ${error}` : ""}`);
    const panel = document.getElementById("contraplano-live-progress");
    if (!panel) return;
    panel._progress.logs.push(`${error ? "⚠" : "✓"} ${label}${error ? `: ${error}` : ""}`);
    const log = panel.querySelector('[data-part="log"]');
    const line = document.createElement("div");
    line.textContent = `${error ? "⚠" : "✓"} ${label}`;
    log.append(line);
  }

  function progressFinish(message, isError = false) {
    consoleEvent(isError ? "AVISO" : "FIN", message);
    if (!document.getElementById("contraplano-live-progress")) progressStep("Resultado");
    const panel = document.getElementById("contraplano-live-progress");
    clearInterval(panel._progress.timer); clearTimeout(panel._progress.dismiss); panel._progress.done = true;
    panel.dataset.state = isError ? "error" : "success";
    const copy = isError ? errorNoticeCopy(message, location.hostname === "modulo-de-reportes-contraplano.web.app") : null;
    panel.querySelector('[data-part="step"]').textContent = copy?.title || "Proceso terminado";
    renderProgressMessage(panel, message, copy);
    if (!isError) panel._progress.dismiss = setTimeout(() => {
      panel.style.animation = "cpExit .18s ease-in forwards";
      panel._progress.dismiss = setTimeout(() => panel.remove(), 180);
    }, 3000);
  }

  function editorNotice(message, isError = false) {
    const live = document.getElementById("contraplano-live-progress");
    if (isError && live?._progress.label === "Abrir entrada") progressFinish(message, true);
    return cornerNotice("contraplano-editor-notice", message, isError, 3000);
  }

  function errorNoticeCopy(message, isReport) {
    const text = String(message || '');
    if (/pestaña conserva el código/i.test(text)) return { title: "Esta pestaña necesita recargarse", reason: "La extensión ya se actualizó, pero la pestaña usa código anterior.", action: "Guarda los cambios pendientes y recarga esta pestaña." };
    if (/extensión está desactualizada/i.test(text)) return { title: "La extensión necesita actualizarse", reason: "La extensión tiene una versión anterior a la del preparador.", action: "Abre la guía de la extensión en Equipo para actualizarla." };
    if (/extensión sigue usando/i.test(text)) return { title: "Falta recargar la extensión", reason: "El navegador todavía no confirmó la versión requerida.", action: "Guarda tu trabajo y recarga la extensión y esta pestaña." };
    if (/archivos de la extensión son/i.test(text)) return { title: "El preparador necesita actualizarse", reason: "Los archivos de la extensión tienen una versión más nueva.", action: "Actualiza y reinicia el preparador antes de recargar la extensión." };
    if (/preparador abierto es/i.test(text)) return { title: "El preparador usa una versión anterior", reason: "La extensión es más nueva que el preparador abierto.", action: "Cierra y vuelve a abrir el preparador actualizado." };
    if (/activa la pestaña|primer plano|cubre el control|perdió el foco|MRC dejó de estar visible/i.test(text)) return { title: "Vuelve a la pestaña MRC", reason: "No pude continuar con MRC fuera de la pantalla activa.", action: "Abre MRC, deja esa pestaña al frente y pulsa Reintentar." };
    if (/quedaron campos pendientes/i.test(text) && text.includes(';')) return { title: "Hay datos pendientes en el reporte", reason: "Falta completar o confirmar algunos campos.", action: "Revisa el panel inferior para continuar." };
    if (/10061|connection refused|conexión.*deneg|ollama.*(?:no respond|no pude conectar)/i.test(text)) return { title: "La IA no respondió", reason: "No se pudo conectar con Ollama.", action: "Abre Ollama y vuelve a intentarlo." };
    if (/Windows no pudo completar el clic|Windows no aceptó el clic/i.test(text)) return { title: "Windows no aceptó el clic", reason: "Se encontró el control, pero no se pudo completar la pulsación.", action: "Deja MRC en primer plano y vuelve a intentarlo." };
    if (/MRC no confirmó el cierre de la lista/i.test(text)) return { title: "La lista no confirmó su cierre", reason: "El menú de categorías sigue sin estar listo para reintentar.", action: "Cierra la lista, deja MRC al frente y pulsa Reintentar." };
    if (/categoría|seleccionar.*bloque|opción.*zona|selección.*bloque/i.test(text)) return { title: "Falta seleccionar la categoría", reason: "No se pudo confirmar la opción elegida.", action: "Comprueba la lista de MRC y vuelve a intentarlo." };
    if (/img seo|selector.*(?:archivo|imagen)|subir.*imagen/i.test(text)) return { title: "La imagen quedó pendiente", reason: "No se pudo completar su carga en el reporte.", action: "Comprueba si ya aparece la imagen antes de reintentar." };
    if (/una cifra no está en el respaldo/i.test(text)) return { title: "Falta comprobar una cifra del resumen", reason: "No pude confirmar una cantidad en el texto que la respalda.", action: "Reintenta la descripción o compara el resumen con la noticia." };
    if (/referencia válida al texto fuente|corregir las referencias/i.test(text)) return { title: "No se pudo revisar el resumen", reason: "La IA respondió, pero sus referencias no pasaron la revisión.", action: "Reintenta la descripción; este aviso no indica un fallo de conexión." };
    if (/descripción.*pendiente|resumen.*(?:respaldado|informativo)/i.test(text)) return { title: "Falta la descripción", reason: "No se pudo preparar un resumen válido de la noticia.", action: "Reintenta la descripción y abre los detalles si vuelve a fallar." };
    if (/rank math|puntaje/i.test(text)) return { title: "Falta revisar el SEO", reason: "No se pudo completar la comprobación de Rank Math.", action: "Revisa el panel inferior para ver qué falta." };
    if (/guardado|guardar borrador/i.test(text)) return { title: "No se confirmó el guardado", reason: "WordPress no confirmó que los cambios estén guardados.", action: "Revisa la entrada antes de cerrar la pestaña." };
    return { title: isReport ? "El reporte necesita revisión" : "Un paso quedó pendiente", reason: "No se pudo completar todo el proceso.", action: "Consulta el panel inferior o abre «Ver detalles»." };
  }

  function cornerNotice(id, message, isError, successDelay) {
    for (const oldId of ["contraplano-editor-notice", "contraplano-report-notice"]) document.getElementById(oldId)?.remove();
    const notice = document.createElement("div");
    notice.id = id;
    notice.setAttribute("role", "status");
    Object.assign(notice.style, { position: "fixed", zIndex: "2147483647", top: "16px", right: "16px", width: isError ? "390px" : "auto", boxSizing: "border-box", maxWidth: "min(560px, calc(100vw - 32px))", padding: "16px 18px", borderRadius: "10px", color: "#fff", background: isError ? "#9f2525" : "#176b3a", boxShadow: "0 4px 16px #0005", font: "400 14px/1.45 system-ui, sans-serif" });
    const close = document.createElement("button");
    close.textContent = "×"; close.setAttribute("aria-label", "Cerrar aviso"); close.type = "button";
    Object.assign(close.style, { float: "right", marginLeft: "12px", padding: "0 3px", background: "transparent", border: "0", color: "white", cursor: "pointer", fontSize: "23px", lineHeight: "1" });
    const body = document.createElement("div");
    let details;
    if (isError) {
      const copy = errorNoticeCopy(message, id === "contraplano-report-notice");
      const title = document.createElement("strong"); title.textContent = copy.title;
      Object.assign(title.style, { display: "block", fontSize: "16px", marginBottom: "6px" });
      const reason = document.createElement("div"); reason.textContent = copy.reason;
      const action = document.createElement("div"); action.textContent = copy.action;
      Object.assign(action.style, { marginTop: "6px", color: "#fff0ed" });
      details = document.createElement("details");
      const summary = document.createElement("summary"); summary.textContent = "Ver detalles";
      Object.assign(summary.style, { cursor: "pointer", fontSize: "12px" });
      const full = document.createElement("div"); full.textContent = String(message || '');
      Object.assign(full.style, { marginTop: "6px", maxHeight: "160px", overflowY: "auto", overflowWrap: "anywhere", fontSize: "12px" });
      Object.assign(details.style, { marginTop: "10px", paddingTop: "8px", borderTop: "1px solid #ffffff40" });
      details.append(summary, full);
      body.append(title, reason, action, details);
    } else body.textContent = `Contraplano v${EXTENSION_VERSION} · ${message}`;
    notice.append(close, body);
    let timer;
    const dismiss = () => { clearTimeout(timer); notice.remove(); };
    close.onclick = dismiss;
    document.documentElement.appendChild(notice);
    timer = setTimeout(dismiss, isError ? 10000 : successDelay);
    if (details) details.ontoggle = () => {
      clearTimeout(timer);
      if (!details.open && notice.isConnected) timer = setTimeout(dismiss, 10000);
    };
    const sending = consoleEvent(isError ? "ERROR" : "INFO", message);
    if (isError) {
      const status = document.createElement("div");
      status.textContent = "Preparando informe de error…";
      Object.assign(status.style, { marginTop: "8px", fontSize: "12px", fontWeight: "400" });
      notice.append(status);
      Promise.resolve(sending).then(result => {
        if (!notice.isConnected || document.getElementById(id) !== notice) return;
        const messages = {
          queued: "Informe guardado para envío automático.",
          duplicate: "Error ya registrado.",
          disabled: "Envío de informes desactivado.",
          failed: "No se pudo guardar el informe.",
        };
        status.textContent = messages[result?.diagnosticStatus] || "Registro del informe sin confirmar.";
      }).catch(() => {
        if (notice.isConnected) status.textContent = "Registro del informe sin confirmar.";
      });
    }
    return notice;
  }

  function startReportAdminFlow() {
    const isTrashList = location.pathname.endsWith("/wp-admin/edit.php") && params.get("post_status") === "trash" && params.get("post_type") === "post";
    const isMrcPage = ["mrc-reportes", "mrc-reportes-config"].includes(params.get("page"));
    if (!isTrashList && !isMrcPage) return false;
    chrome.runtime.sendMessage({ type: "CONTRAPLANO_GET_REPORT_PAYLOAD" }).then(async (stored) => {
      if (!stored?.payload) return;
      if (isTrashList) {
        progressStep("Abrir MRC según la cuenta", "Buscando MRC Admin o MRC Editor en el menú de WordPress…");
        const links = [...document.querySelectorAll('#adminmenu a[href*="admin.php?page=mrc-reportes"]')];
        const pageOf = (link) => { try { const url = new URL(link.href || link.getAttribute("href"), location.href || location.origin); return url.origin === location.origin && url.pathname === "/wp-admin/admin.php" ? url.searchParams.get("page") : ""; } catch { return ""; } };
        const link = links.find((item) => pageOf(item) === "mrc-reportes-config") || links.find((item) => pageOf(item) === "mrc-reportes");
        if (link) link.click();
        else {
          progressFinish("No encontré el acceso a MRC de esta cuenta en el menú de WordPress.", true);
          reportNotice("No apareció MRC Admin ni MRC Editor en el menú. Abre el acceso disponible de tu cuenta para continuar con el reporte.", true);
        }
      } else {
        const pageName = params.get("page") === "mrc-reportes-config" ? "MRC Admin" : "MRC Editor";
        progressStep("Abrir MRC según la cuenta", `Buscando el acceso de administrador o reportero; ${pageName} permanecerá abierto.`);
        const findAccess = () => [
          { id: "mrc-open-admin", role: "administrador", label: "Configurar Módulo de Reportes Contraplano (MRC)" },
          { id: "mrc-open-reporter", role: "reportero", label: "Generar/Visualizar Reportes" },
        ].map((entry) => ({ ...entry, button: document.getElementById(entry.id) }))
          .find(({ button }) => button && !button.disabled && button.getAttribute("aria-disabled") !== "true" && (!button.getClientRects || button.getClientRects().length > 0));
        const access = await waitFor(findAccess, 15000, "el botón de acceso a MRC correspondiente a la cuenta").catch(() => null);
        if (!access) {
          progressFinish("No apareció un acceso disponible de administrador o reportero en MRC Editor.", true);
          reportNotice("No encontré un botón disponible: «Configurar Módulo de Reportes Contraplano (MRC)» o «Generar/Visualizar Reportes». Revisa que MRC Editor terminó de cargar para esta cuenta.", true);
          return;
        }
        consoleEvent("INFO", `MRC: acceso de ${access.role} detectado. Abriendo «${access.label}» desde WordPress.`);
        access.button.click();
        progressFinish(`Acceso de ${access.role} abierto. Si la pestaña nueva no aparece, pulsa «${access.label}» manualmente.`);
        reportNotice(`${pageName} permanece abierto. Se usó el acceso de ${access.role}; el autocompletado continuará cuando esté visible el formulario Reporte de Noticias.`);
      }
    }).catch((error) => {
      progressFinish("No pude abrir MRC desde el acceso de esta cuenta.", true);
      reportNotice(error?.message || "No pude abrir MRC desde WordPress.", true);
    });
    return true;
  }

  function reportNotice(message, isError = false) {
    return cornerNotice("contraplano-report-notice", message, isError, 7000);
  }

  async function startReporterFormWorkflow(options = {}) {
    const stored = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_GET_REPORT_PAYLOAD" }).catch(() => null);
    const payload = stored?.payload;
    if (!payload || globalThis.__contraplanoReportRunning) return;
    globalThis.__contraplanoReportRunning = true;
    progressStep("Abrir formulario de reportes", "Esperando los controles de Flutter…");
    try {
      const registration = await connectConsole(payload);
      if (!registration?.registered) throw new Error(registration?.error || "No se confirmó la conexión local con el preparador.");
      if (options.retry) {
        await chrome.runtime.sendMessage({ type: 'CONTRAPLANO_FOCUS_REPORT_TAB' }).catch(() => null);
      }
      enableFlutterSemantics();
      await waitForReportReady();
      const reportBlock = String(payload.reportBlock ?? payload.category ?? "").trim();
      if (!reportBlock) throw new Error("No hay bloque MRC seleccionado. Elígelo en Publicación del preparador y vuelve a abrir la entrada desde allí.");
      await selectFlutterOption("Bloque", reportBlock);
      progressStep("Redactar descripción del reporte", "Ollama puede tardar hasta 10 minutos. La barra irá mostrando el tiempo mientras prepara el resumen.");
      const descriptionIdentity = JSON.stringify(["mrc-factual-v3", payload.postUrl, payload.title, payload.articleBody]);
      let previousDescription;
      try { previousDescription = JSON.parse(sessionStorage.getItem('contraplano-mrc-description') || 'null'); } catch {}
      const sameDescription = previousDescription?.identity === descriptionIdentity && previousDescription?.description;
      const existingDescription = sameDescription ? flutterFieldValue(findFlutterTextField('Descripción Noticia')) : '';
      let descriptionResult;
      if (sameDescription) descriptionResult = { description: existingDescription || previousDescription.description };
      else {
        const started = Date.now();
        const heartbeat = setInterval(() => progressDetail(`Ollama prepara y revisa el resumen para MRC… ${Math.floor((Date.now() - started) / 1000)} s. Puede tardar hasta 10 min.`), 10000);
        try { descriptionResult = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_REPORT_DESCRIPTION", title: payload.title, body: payload.articleBody }).catch(() => null); }
        finally { clearInterval(heartbeat); }
      }
      payload.description = descriptionResult?.description || "";
      if (payload.description) sessionStorage.setItem('contraplano-mrc-description', JSON.stringify({ identity: descriptionIdentity, description: payload.description }));
      if (sameDescription) consoleEvent('OK', 'Conservo la descripción ya completada para esta noticia; continúo con los campos pendientes.');
      if (descriptionResult?.warning) consoleEvent("AVISO", descriptionResult.warning);
      const fieldErrors = [];
      const completeField = async (label, action) => {
        try { await action(); progressResult(label); return true; }
        catch (error) {
          const reason = error?.message || String(error);
          fieldErrors.push(`${label}: ${reason}`);
          progressResult(label, reason);
          consoleEvent("AVISO", `Continúo con los demás campos del reporte después de: ${label}.`);
          return false;
        }
      };
      const reportMediaUrl = payload.imageUrl || payload.videoUrl || "";
      // MRC obtiene Nombre de la sesión y puede mostrarlo bloqueado.
      // No forma parte de los campos que la extensión debe editar o validar.
      progressResult("Nombre de la sesión conservado por MRC");
      const textFields = [
        ["Título", payload.title], ["URL Noticia", payload.postUrl],
        ["URL Imagen Noticia", reportMediaUrl], ["Descripción Noticia", payload.description],
        ["Rank Math SEO Noticia", String(payload.rankMathScore ?? "")],
      ];
      for (const [label, value] of textFields) await completeField(label, () => {
        if (label === "Descripción Noticia" && !value) throw new Error(descriptionResult?.error || "No pude generar un resumen informativo; completa la descripción manualmente.");
        return fillFlutterText(label, value, true);
      });
      // URL Podcast y redes sociales quedan para el usuario.
      progressResult(`Bloque ${payload.reportBlock ?? payload.category ?? ""} confirmado`);
      if (payload.imageUrl || payload.imageToken) {
        const firstImageSelected = await completeField("IMG SEO Podcast", () => uploadReportImage(payload, "IMG SEO Podcast", 0));
        if (firstImageSelected) await completeField("IMG SEO Noticia", () => uploadReportImage(payload, "IMG SEO Noticia", 1));
        else fieldErrors.push("IMG SEO Noticia: pendiente hasta resolver el primer selector de imagen; cancela cualquier cuadro Abrir que siga abierto y reintenta.");
      } else if (payload.videoUrl) {
        progressResult("Artículo con video; no subí el MP4 como si fuera una imagen");
        consoleEvent("AVISO", "La entrada no tiene imagen fija. Pasé la URL del video al campo de medio y dejé IMG SEO Podcast/Noticia vacíos para que agregues imágenes si MRC las exige.");
      }
      // File uploads can rebuild the Flutter form. Repair missing values, then
      // check again after blur instead of accepting an earlier successful write.
      await verifyReportTextFields(textFields, fieldErrors);
      if (fieldErrors.length) throw new Error(`Quedaron campos pendientes: ${fieldErrors.join("; ")}`);
      const imageIdentity = JSON.stringify([payload.postUrl || '', payload.imageUrl || payload.imageName || 'imagen-noticia']);
      sessionStorage.removeItem(`contraplano-mrc-image:${imageIdentity}:0`);
      sessionStorage.removeItem(`contraplano-mrc-image:${imageIdentity}:1`);
      await chrome.runtime.sendMessage({ type: "CONTRAPLANO_CLOSE_HUMANIZER_TAB" }).catch(() => null);
      await chrome.runtime.sendMessage({ type: "CONTRAPLANO_CLEAR_REPORT_PAYLOAD" }).catch(() => null);
      progressFinish("Formulario completado. Puedes ingresar las redes sociales y pulsar Generar reporte.");
      reportNotice("Datos de noticia cargados. Dejé las redes sociales vacías para que las completes; revisa el formulario y pulsa «Generar reporte» cuando esté listo.");
    } catch (error) {
      progressFinish(`Reporte detenido: ${error?.message || error}`, true);
      reportNotice(`No pude completar el formulario de reportes: ${error?.message || error}. Puedes reintentar en esta pestaña.`, true);
      const panel = document.getElementById("contraplano-live-progress");
      const retry = document.createElement("button");
      retry.textContent = "Reintentar completar reporte";
      retry.dataset.retry = "report";
      Object.assign(retry.style, { marginTop: "12px", padding: "9px 12px", color: "white", background: "#186b51", border: "0", borderRadius: "7px", cursor: "pointer" });
      retry.onclick = () => { retry.remove(); startReporterFormWorkflow({ retry: true }); };
      panel?.append(retry);
    } finally {
      globalThis.__contraplanoReportRunning = false;
    }
  }

  async function verifyReportTextFields(textFields, fieldErrors) {
    const retained = (label, value) => {
      const field = findFlutterTextField(label);
      const expected = String(value ?? "").replace(/\s+/g, " ").trim();
      return Boolean(expected && field && flutterFieldValue(field) === expected);
    };
    // Write title last so that subsequent fields cannot disturb its editor.
    const ordered = [...textFields.filter(([label]) => label !== "Título"), ...textFields.filter(([label]) => label === "Título")];
    for (const [label, value] of ordered) {
      if (!String(value ?? "").trim()) continue;
      if (!retained(label, value)) {
        progressDetail(`Revisión final: restaurando «${label}» después de subir las imágenes…`);
        try { await fillFlutterText(label, value, true); }
        catch (error) { consoleEvent("AVISO", `No pude restaurar ${label}: ${error.message}`); }
      }
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
    for (const [label, value] of textFields) {
      if (retained(label, value)) {
        for (let index = fieldErrors.length - 1; index >= 0; index--) if (fieldErrors[index].startsWith(label + ":")) fieldErrors.splice(index, 1);
      } else if (!fieldErrors.some((message) => message.startsWith(label + ":"))) fieldErrors.push(`${label}: MRC no conserva el valor en el formulario después de la revisión final.`);
    }
  }

  function flutterRoots() {
    const roots = [document];
    for (let index = 0; index < roots.length && index < 12; index++) {
      for (const host of roots[index].querySelectorAll('flutter-view, flt-glass-pane, flt-semantics-host')) {
        if (host.shadowRoot && !roots.includes(host.shadowRoot)) roots.push(host.shadowRoot);
      }
    }
    return roots;
  }

  function flutterNodes() {
    return [...new Set(flutterRoots().flatMap(root => [...root.querySelectorAll('flt-semantics-host *, flt-semantics, input, textarea, button, select, [role], label')]))]
      .filter(node => !node.closest?.('[id^="contraplano-"]'));
  }

  function enableFlutterSemantics() {
    if (document.visibilityState === 'hidden') return;
    for (const root of flutterRoots()) {
      const placeholder = root.querySelector('flt-semantics-placeholder');
      if (placeholder) placeholder.click();
    }
  }

  function flutterName(node) {
    const root = node.getRootNode?.();
    const labelledBy = (node.getAttribute?.('aria-labelledby') || '').split(/\s+/).filter(Boolean).map(id => root?.getElementById?.(id)?.textContent || node.ownerDocument?.getElementById(id)?.textContent || '').join(' ');
    const labels = [...(node.labels || [])].map(label => label.textContent || '').join(' ');
    return String(node.getAttribute?.('aria-label') || labelledBy || labels || node.getAttribute?.('title') || node.getAttribute?.('placeholder') || node.textContent || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase('es');
  }

  function findFlutterTextField(label) {
    const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es');
    const expected = normalize(label);
    const isField = node => node.matches('input, textarea, [contenteditable=true], [data-semantics-role="text-field"]') || ['textbox','text-field'].includes(node.getAttribute('role'));
    const matches = name => name === expected || name.startsWith(expected + ' ');
    return flutterNodes().filter(node => {
      if (!isField(node) || node.closest?.('[hidden], [aria-hidden="true"]') || (node.getClientRects && !node.getClientRects().length)) return false;
      if (matches(normalize(flutterName(node)))) return true;
      // Flutter may put the accessible label on the wrapping semantics node.
      let parent = node.parentElement;
      for (let depth = 0; parent && depth < 3; depth++, parent = parent.parentElement) {
        if (parent.tagName?.toLowerCase() !== 'flt-semantics') break;
        if (parent.querySelectorAll && parent.querySelectorAll('input,textarea,[role="textbox"]').length > 1) break;
        if (matches(normalize(flutterName(parent)))) return true;
      }
      return false;
    }).sort((a,b) => (matches(normalize(flutterName(a))) ? 0 : 4) - (matches(normalize(flutterName(b))) ? 0 : 4) + (a.matches('input,textarea') ? 0 : 1) - (b.matches('input,textarea') ? 0 : 1))[0] || null;
  }

  function flutterFieldValue(node) {
    return String(node?.value ?? node?.getAttribute?.("aria-valuetext") ?? node?.textContent ?? "").replace(/\s+/g, " ").trim();
  }

  async function fillFlutterText(label, value, required) {
    progressStep(`Completar reporte: ${label}`);
    if (!value) { if (required) throw new Error(`No hay valor disponible para «${label}».`); return; }
    const expected = String(value).replace(/\s+/g, " ").trim();
    if (label.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase() === "titulo") return fillFlutterTitleNative(expected);
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const target = await waitFor(() => findFlutterTextField(label), 10000, `el campo «${label}»`);
      if (target.disabled || target.readOnly || target.getAttribute("aria-disabled") === "true" || target.getAttribute("aria-readonly") === "true") {
        if (required) throw new Error(`El campo «${label}» está deshabilitado o no permite edición.`);
        consoleEvent("INFO", `Se conserva el campo «${label}» que MRC ya completó y dejó deshabilitado.`);
        return;
      }
      if (flutterFieldValue(target) === expected) { consoleEvent("OK", `«${label}» ya contiene el valor esperado.`); return; }
      progressDetail(`Escribiendo «${label}» con teclado de Windows (intento ${attempt + 1}/2)…`);
      await activateFlutterControl(target, /filtrar bloques/i.test(label) ? "Filtrar bloques" : label, expected);
      const retained = await waitFor(() => {
        const field = findFlutterTextField(label);
        return field && flutterFieldValue(field) === expected ? field : null;
      }, 5000, `la confirmación de «${label}» después de escribirlo`).catch(() => null);
      if (retained) { consoleEvent("OK", `«${label}» completado y comprobado después de salir del campo.`); return; }
      consoleEvent("AVISO", `MRC no conservó «${label}». Intento ${attempt + 1}/2.`);
    }
    throw new Error(`MRC no conservó el valor de «${label}» después de dos intentos.`);
  }

  async function fillFlutterTitleNative(value) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      const input = await waitFor(() => findFlutterTextField("Título"), 10000, "el input exacto de Título de MRC");
      if (flutterFieldValue(input) === value) {
        consoleEvent("OK", "Título ya confirmado; no vuelvo a escribirlo.");
        return;
      }
      if (input.disabled || input.readOnly || input.getAttribute("aria-disabled") === "true" || input.getAttribute("aria-readonly") === "true") throw new Error("El campo Título no permite edición.");
      progressDetail("Vaciando el título anterior antes de reemplazarlo…");
      await activateFlutterControl(input, "Título", value, { clearOnly: true });
      let emptySince = null;
      const empty = await waitFor(() => {
        const field = findFlutterTextField("Título");
        if (!field || flutterFieldValue(field) !== "") { emptySince = null; return null; }
        if (emptySince === null) emptySince = Date.now();
        return Date.now() - emptySince >= 300 ? field : null;
      }, 5000, "el título vacío antes de escribirlo").catch(() => null);
      if (!empty) throw new Error("No pude confirmar que el título anterior se borró. No añadí otra copia; revisa el campo Título y reintenta.");
      progressDetail(`Escribiendo el título en MRC con teclado de Windows (intento ${attempt}/2)…`);
      await activateFlutterControl(empty, "Título", value);
      let retainedSince = null;
      const retained = await waitFor(() => {
        const field = findFlutterTextField("Título");
        if (!field || flutterFieldValue(field) !== value) { retainedSince = null; return null; }
        if (retainedSince === null) retainedSince = Date.now();
        return Date.now() - retainedSince >= 400 ? field : null;
      }, 5000, "la confirmación estable del título después de escribirlo").catch(() => null);
      if (retained) {
        consoleEvent("OK", "Título escrito mediante teclado de Windows y comprobado después de Tab.");
        return;
      }
    }
    throw new Error("MRC no conservó el título después de escribirlo con el teclado de Windows.");
  }

  function requireReportFocus() {
    if (globalThis.document && typeof document.hasFocus === "function" && (document.visibilityState !== "visible" || !document.hasFocus())) {
      const error = new Error("MRC perdió el foco: vuelve a la pestaña MRC, déjala al frente y pulsa Reintentar completar reporte.");
      error.code = "MRC_FOCUS";
      throw error;
    }
  }

  async function activateFlutterControl(node, label, text, options = {}) {
    requireReportFocus();
    for (let attempt = 0; attempt < 2; attempt++) {
      node.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
      await new Promise(resolve => setTimeout(resolve, attempt ? 350 : 150));
      const rect = node.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) throw new Error(`El control «${label}» no está visible.`);
      requireReportFocus();
      const result = await chrome.runtime.sendMessage({ type: 'CONTRAPLANO_CLICK_MRC_CONTROL', control: {
        label, x: rect.left + rect.width / 2, y: rect.top + rect.height / 2,
        width: window.innerWidth, height: window.innerHeight, scale: window.devicePixelRatio || 1,
        clientWidth: document.documentElement?.clientWidth || window.innerWidth,
        clientHeight: document.documentElement?.clientHeight || window.innerHeight,
        ...(text !== undefined ? { text } : {}),
        ...(options.clearOnly === true ? { clearOnly: true } : {}),
      } });
      if (!result?.clicked) {
        const reason = result?.error || `Windows no pudo confirmar «${label}».`;
        if (!attempt && /área de MRC|área verificada del navegador/.test(reason)) {
          progressDetail('No confirmé el área del navegador. Recalculando las medidas una vez antes de reintentar…');
          continue;
        }
        if (/controles permitidos de MRC/.test(reason)) throw new Error(`El preparador abierto no admite el control «${label}». Cierra el preparador, reemplaza también sus archivos Python por el paquete actualizado y ábrelo de nuevo.`);
        throw new Error(reason);
      }
      if (options.clearOnly === true && !result?.clearSent) throw new Error('Actualiza y reinicia el preparador para confirmar el borrado del título antes de escribirlo.');
      if (options.clearOnly !== true && text !== undefined && !result?.typed) throw new Error('Actualiza el preparador y su selector de Windows para escribir los campos de MRC.');
      return result;
    }
  }

  async function waitForReportReady() {
    progressStep("Esperar que MRC termine de cargar", "Esperando el formulario y la lista de bloques; puede tardar hasta 45 segundos.");
    if (globalThis.document && typeof document.hasFocus === "function") {
      await waitFor(() => document.visibilityState === "visible" && document.hasFocus(), 10000, "la pestaña MRC en primer plano y con foco").catch(error => { requireReportFocus(); throw error; });
      await new Promise(resolve => setTimeout(resolve, 350));
    }
    let lastSemanticsRetry = 0;
    await waitFor(() => {
      if (Date.now() - lastSemanticsRetry > 2000) {
        enableFlutterSemantics(); lastSemanticsRetry = Date.now();
      }
      const nodes = flutterNodes();
      const menuOpen = nodes.some((node) => /filtrar bloques/i.test(flutterName(node)) || (flutterName(node) === "zona norte" && node.getAttribute("role") === "button"));
      const titleReady = findFlutterTextField("Título");
      const urlReady = findFlutterTextField("URL Noticia");
      const blockReady = nodes.some((node) => /^bloque(?:\s|$)/i.test(flutterName(node)) && (node.getAttribute("role") === "button" || node.getAttribute("role") === "combobox" || node.matches("button")));
      return menuOpen || (titleReady && urlReady && blockReady);
    }, 45000, "los campos accesibles Título, URL Noticia y Bloque de MRC (el formulario puede estar visible aunque Flutter todavía no exponga sus controles)");
    progressDetail("Formulario de MRC listo. Espero 2 segundos antes de abrir el desplegable Bloque…");
    consoleEvent("ESPERA", "MRC listo: pausa de 2 segundos antes de abrir Bloque.");
    await new Promise((resolve) => setTimeout(resolve, 2000));
    consoleEvent("OK", "Pausa completada; ahora puedo abrir Bloque.");
  }

  async function selectFlutterOption(label, optionText) {
    progressStep(`Seleccionar ${label}: ${optionText}`, "Mantén esta pestaña MRC al frente mientras completo el formulario.");
    requireReportFocus();
    const expectedLabel = label.toLocaleLowerCase("es");
    const expectedOption = optionText.toLocaleLowerCase("es");
    // Flutter exposes options outside the clipped list. Only a fully visible
    // centre is a usable native click target; DOM presence alone is insufficient.
    const visibleOption = (node, inViewport = true) => {
      if (!node || node.isConnected === false || node.closest?.('[hidden], [aria-hidden="true"], [inert]')) return false;
      if (node.getClientRects && !node.getClientRects().length) return false;
      if (typeof getComputedStyle === "function") {
        const style = getComputedStyle(node);
        if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return false;
      }
      if (!node.getBoundingClientRect) return true;
      const rect = node.getBoundingClientRect();
      const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
      if (rect.width <= 0 || rect.height <= 0) return false;
      if (!inViewport) return true;
      if (x < 0 || y < 0 || x >= window.innerWidth || y >= window.innerHeight) return false;
      for (let parent = node.parentElement; parent; parent = parent.parentElement) {
        if (parent.getAttribute?.('role') !== 'group' || !/scroll|hidden|clip/i.test(parent.getAttribute?.('style') || '')) continue;
        const clip = parent.getBoundingClientRect();
        if (x < clip.left || x >= clip.right || y < clip.top || y >= clip.bottom) return false;
      }
      return true;
    };
    const isButton = (node) => node.getAttribute("role") === "button" || node.getAttribute("role") === "combobox" || node.matches("button");
    const findDropdown = () => flutterNodes().find((node) => {
      const name = flutterName(node);
      return visibleOption(node, false) && isButton(node) && (name === expectedLabel || name.startsWith(expectedLabel + " ")) && !node.disabled && node.getAttribute("aria-disabled") !== "true";
    });
    // Comparacion tolerante: ignora tildes, espacios especiales/invisibles y
    // sufijos de accesibilidad ("seleccionado", "1 de 8"). Nunca acepta otra
    // categoria distinta (p. ej. "zona norte 2").
    const CH = (code) => String.fromCharCode(code);
    const reMarks = new RegExp("[" + CH(0x300) + "-" + CH(0x36f) + "]", "g");
    const reInvisible = new RegExp("[" + CH(0x200b) + "-" + CH(0x200d) + CH(0x2060) + CH(0xfeff) + "]", "g");
    const reSpaces = new RegExp("[" + CH(0xa0) + CH(0x2007) + CH(0x202f) + "]", "g");
    const normOption = (value) => String(value || "").normalize("NFD").replace(reMarks, "").replace(reInvisible, "").replace(reSpaces, " ").replace(/\s+/g, " ").trim().toLocaleLowerCase("es");
    const expectedNorm = normOption(optionText);
    const sameOption = (name) => {
      const n = normOption(name);
      if (n === expectedNorm) return true;
      if (!n.startsWith(expectedNorm)) return false;
      return /^[\s,.:;-]*(seleccionad[oa]|opcion|elemento|\d+\s*de\s*\d+)(\s|$)/.test(n.slice(expectedNorm.length));
    };
    const visibleOptionNames = () => [...new Set(flutterNodes().filter((node) => optionGroup(node) && visibleOption(node, false) && Boolean(flutterName(node))).map((node) => flutterName(node)))].slice(0, 30);
    const allVisibleNames = () => [...new Set(flutterNodes().filter((node) => visibleOption(node, false) && Boolean(flutterName(node))).map((node) => (node.getAttribute("role") || node.tagName.toLowerCase()) + "|" + flutterName(node).slice(0, 50)))].slice(0, 70);
    const optionRoles = ["button", "combobox", "option", "listitem", "menuitem", "menuitemradio", "menuitemcheckbox", "radio", "checkbox", "tab", "link"];
    const findOption = () => flutterNodes().find((node) => sameOption(flutterName(node)) && visibleOption(node) && (isButton(node) || optionRoles.includes(node.getAttribute("role")) || node.hasAttribute("flt-tappable")));
    const findFilter = () => flutterNodes().find((item) => visibleOption(item) && /filtrar bloques/i.test(flutterName(item)) && (item.matches("input, textarea") || item.getAttribute("role") === "textbox"));
    const optionGroup = node => {
      for (let parent = node.parentElement; parent; parent = parent.parentElement) {
        if (parent.getAttribute?.("role") === "group" && /scroll/i.test(parent.getAttribute?.("style") || "")) return parent;
      }
      return null;
    };
    const optionCandidates = () => flutterNodes().filter(node => optionGroup(node) && visibleOption(node)
      && (isButton(node) || ["option", "listitem"].includes(node.getAttribute("role"))) && Boolean(flutterName(node))
      && !/^(bloque(?:\s|$)|ver reportes$|subir |generar reporte$|cerrar|cancelar|reintentar|ver$|vista previa|editar|eliminar|quitar|borrar|generador de reportes|configurar bloques|reporte de noticias|rank math|redes sociales|contraplano$)/i.test(flutterName(node)));
    // Botones que ya existian en la pagina antes de abrir la lista (p. ej. los de
    // cambiar imagen tras subirla) no cuentan como opciones de la lista.
    // Si la lista ya estaba abierta al empezar (intento anterior o abierta a mano), sus
    // categorias NO se memorizan como botones de la pagina: el filtro u opcion visible lo delata.
    const baselineButtons = new Set((findFilter() || findOption()) ? [] : optionCandidates().map(node => flutterName(node)));
    const hasVisibleOptions = () => optionCandidates().some(node => !baselineButtons.has(flutterName(node)));
    const menuOpen = () => Boolean(findFilter() || findOption() || hasVisibleOptions());
    const selected = () => {
      const dropdown = findDropdown();
      return dropdown && flutterName(dropdown) === expectedLabel + " " + expectedOption ? dropdown : null;
    };
    let closeFailed = false, firstActivationIssue = '';
    const waitClosed = async ms => waitFor(() => !menuOpen() && findDropdown(), ms, "que la lista de Bloque esté cerrada").catch(() => null);
    const closeList = async () => {
      requireReportFocus();
      if (!menuOpen()) return;
      let closeIssue = '';
      const dropdown = findDropdown();
      // Some Flutter builds ignore Escape, but respond to the dropdown toggle.
      if (dropdown?.click) {
        dropdown.click();
        if (await waitClosed(1200)) return;
      }
      try {
        const anchor = findFilter() || findOption() || findDropdown();
        if (anchor) await activateFlutterControl(anchor, "Cerrar lista bloques");
        if (await waitClosed(1600)) return;
      } catch (error) { closeIssue = error.message; }
      const fresh = findDropdown();
      try {
        if (fresh) await activateFlutterControl(fresh, label);
        if (await waitClosed(1600)) return;
      } catch (error) { closeIssue = error.message; }
      closeFailed = true;
      const error = new Error(`MRC no confirmó el cierre de la lista de Bloque. No seguí abriéndola ni seleccioné otra categoría. Cierra la lista manualmente y reintenta.${closeIssue ? ' Detalle: ' + closeIssue : ''}${firstActivationIssue ? ' Fallo anterior: ' + firstActivationIssue : ''}`);
      error.code = "MRC_MENU_CLOSE";
      throw error;
    };
    const confirmSelection = async ms => {
      const choice = await waitFor(selected, ms, `la selección de «${optionText}»`).catch(() => null);
      if (!choice) return null;
      if (menuOpen() && !(await waitClosed(600))) await closeList();
      return selected();
    };
    if (selected()) { await closeList(); return; }
    let lastIssue = '';
    try {
    const deadline = Date.now() + 75000;
    for (let attempt = 1; attempt <= 3 && Date.now() < deadline; attempt += 1) {
      try {
      requireReportFocus();
      if (attempt > 1) {
        progressDetail(`No encontré o no pude confirmar ${optionText}. Cierro la lista y vuelvo a abrirla (intento ${attempt}/3)…`);
        consoleEvent("AVISO", `Reiniciando el desplegable de ${label}: cerrar, comprobar y volver a abrir.`);
        await closeList();
        if (selected()) return;
        progressDetail("Lista cerrada. Espero 2 segundos antes de volver a abrir Bloque…");
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
      const attemptDeadline = Math.min(deadline, Date.now() + 20000);
      progressDetail(`Esperando que carguen los bloques de MRC. Intento ${attempt}/3; hasta 20 segundos por intento…`);
      consoleEvent("ESPERA", `Carga de Bloque: esperando «${optionText}», comprobación ${attempt}/3.`);
      if (selected()) return;
      let option = findOption();
      if (!option && !findFilter()) {
        const dropdown = await waitFor(findDropdown, Math.min(15000, Math.max(1, attemptDeadline-Date.now())), `el botón «${label}» del formulario`).catch(() => null);
        if (dropdown) {
          dropdown.scrollIntoView?.({block:"center", inline:"nearest"});
          await new Promise(resolve => setTimeout(resolve, 200));
          // La lista se considera abierta solo si hay filtro u opcion real; antes
          // botones del encabezado de MRC se confundian con opciones y nunca se hacia clic.
          if (!findFilter() && !findOption()) dropdown.click();
          // Un clic sintetico a veces no abre la lista de Flutter: si no aparece
          // ni el filtro ni opciones, uso el clic nativo. Nunca se ejecuta si la
          // lista ya esta abierta (no la cierra).
          const opened = await waitFor(() => findFilter() || findOption() || hasVisibleOptions(), 1800, "que se abra la lista de Bloque").catch(() => null);
          if (!opened && dropdown.isConnected !== false) {
            try {
              consoleEvent("AVISO", "El clic normal no abrio la lista de Bloque. Uso el clic nativo de Windows.");
              await activateFlutterControl(dropdown, label);
            } catch (error) {
              if (/activa la pestana|activa la pestaña|cubre el control|perdio el foco|perdió el foco|Actualiza el preparador|no admite el control/i.test(error.message)) throw error;
              consoleEvent("AVISO", "El clic nativo en Bloque fallo: " + error.message);
            }
          }
        }
      }
      progressDetail("Esperando opciones visibles de Bloque antes de usar el filtro…");
      const loaded = await waitFor(() => findOption() || findFilter() || hasVisibleOptions(), Math.min(12000, Math.max(1, attemptDeadline-Date.now())), "las opciones visibles de la lista de Bloque").catch(() => null);
      requireReportFocus();
      if (!loaded) continue;
      try { consoleEvent("INFO", `Diagnostico lista abierta: Filtro=${Boolean(findFilter())} Opciones=${JSON.stringify(visibleOptionNames())} TODO=${JSON.stringify(allVisibleNames())}`); } catch (_) {}
      option = findOption();
      if (!option) {
        const filter = findFilter();
        if (filter) {
          progressDetail(`La lista ya cargó. Filtro «${optionText}» para encontrar las opciones que quedan más abajo…`);
          consoleEvent("INFO", `Opciones de Bloque visibles: ahora filtro «${optionText}».`);
          try { await fillFlutterText(flutterName(filter), optionText, true); }
          catch (error) {
            // A failed filter must not abort before trying the loaded list.
            if (/activa la pestaña|cubre el control|perdió el foco|Actualiza el preparador|no admite el control/i.test(error.message)) throw error;
            consoleEvent("AVISO", "El filtro no confirmó el texto. Intento localizar la categoría recorriendo la lista cargada.");
          }
          // Flutter reconstruye los nodos al filtrar; no reutilizar la opción anterior.
          await new Promise((resolve) => setTimeout(resolve, 700));
        }
      }
      option = await waitFor(findOption, Math.min(4000, Math.max(1, attemptDeadline-Date.now())), `la opción «${optionText}» mientras carga la lista de MRC`).catch(() => null);
      // Some MRC builds expose the full list but Flutter's filter field does
      // not accept synthetic input. Search the scrollable semantics list as a
      // fallback instead of waiting the whole attempt for a filtered result.
      if (!option && menuOpen()) {
        const groups = flutterNodes().filter((node) => node.getAttribute("role") === "group" && /scroll/i.test(node.getAttribute("style") || "") && node.clientHeight > 0);
        for (const group of groups) {
          requireReportFocus();
          const maxScroll = Math.max(group.scrollHeight, group.querySelector("flt-semantics-scroll-overflow")?.getBoundingClientRect().height || 0);
          const step = Math.max(120, Math.floor(group.clientHeight * 0.7));
          group.scrollTop = 0;
          group.dispatchEvent(new Event("scroll", { bubbles: true }));
          await new Promise((resolve) => setTimeout(resolve, 180));
          option = findOption();
          for (let top = step, scans = 0; !option && top <= maxScroll + step && scans < 30 && Date.now() < attemptDeadline; top += step, scans++) {
            // Filtering/scrolling can replace the semantics group entirely.
            const current = group.isConnected === false ? flutterNodes().find((node) => node.getAttribute("role") === "group" && /scroll/i.test(node.getAttribute("style") || "") && node.clientHeight > 0) : group;
            if (!current) break;
            requireReportFocus();
            const previous = current.scrollTop;
            current.scrollTop = Math.min(top, maxScroll);
            current.dispatchEvent(new Event("scroll", { bubbles: true }));
            await new Promise((resolve) => setTimeout(resolve, 180));
            option = findOption();
            if (option) break;
            if (current.scrollTop === previous) break;
          }
          if (option) break;
        }
      }
      requireReportFocus();
      if (!option) {
        try { consoleEvent("AVISO", `Diagnostico Bloque: no encontre "${optionText}". Boton=${Boolean(findDropdown())} Filtro=${Boolean(findFilter())} ListaAbierta=${menuOpen()} Opciones que veo: ${JSON.stringify(visibleOptionNames())} TODO: ${JSON.stringify(allVisibleNames())}`); } catch (_) {}
        continue;
      }
      progressDetail(`Seleccionando ${optionText} y comprobando el resultado…`);
      let confirmed = null;
      if (typeof option.click === "function") {
        option.click();
        confirmed = await confirmSelection(1800);
      }
      if (!confirmed) {
        // A failed native injection may still have delivered part of a click.
        // Check the selected value before attempting another activation.
        const freshOption = findOption();
        if (freshOption) {
          try { await activateFlutterControl(freshOption, "Seleccionar bloque MRC"); }
          catch (error) {
            confirmed = await confirmSelection(1600);
            if (!confirmed) { firstActivationIssue = error.message; throw error; }
          }
        }
        if (!confirmed) confirmed = await confirmSelection(Math.min(6000, Math.max(1, attemptDeadline-Date.now())));
      }
      if (confirmed) {
        consoleEvent("OK", `${optionText} quedó seleccionado y el menú se cerró. Los controles del reporte están accesibles.`);
        return;
      }
      } catch (error) {
        lastIssue = error?.message || String(error);
        if (error.code === "MRC_FOCUS" || error.code === "MRC_MENU_CLOSE" || /activa la pestaña|cubre el control|perdió el foco|Actualiza el preparador|no admite el control/i.test(lastIssue)) throw error;
        consoleEvent("AVISO", `No confirmé la categoría en el intento ${attempt}/3. Volveré a abrir la lista.`);
      }
    }
    throw new Error(`No pude seleccionar «${optionText}» en MRC después de tres intentos. No cambié la categoría por otra. Pulsa Reintentar completar reporte.${lastIssue ? ' Último problema: ' + lastIssue : ''}`);
    } finally {
      if (!selected() && !closeFailed && (!globalThis.document || typeof document.hasFocus !== "function" || (document.visibilityState === "visible" && document.hasFocus()))) {
        try { await closeList(); }
        catch (_) { consoleEvent("AVISO", "No pude cerrar la lista de categorías. Mantén MRC en primer plano y ciérrala con Escape antes de reintentar."); }
      }
    }
  }

  async function uploadReportImage(payload, label, index) {
    progressStep(`Subir imagen del reporte: ${label}`);
    const imageIdentity = JSON.stringify([payload.postUrl || '', payload.imageUrl || payload.imageName || 'imagen-noticia']);
    const completionKey = `contraplano-mrc-image:${imageIdentity}:${index}`;
    const expectedButtonName = `subir img ${label}`.toLocaleLowerCase("es");
    const findUploadButton = () => flutterNodes().find((node) => flutterName(node) === expectedButtonName && (node.getAttribute("role") === "button" || node.matches("button")) && !node.disabled && node.getAttribute("aria-disabled") !== "true");
    const hasUploadedPreview = () => {
      const otherLabel = index === 0 ? "subir img img seo noticia" : "subir img img seo podcast";
      const otherButton = flutterNodes().find((node) => flutterName(node) === otherLabel && (node.getAttribute("role") === "button" || node.matches("button")));
      if (!otherButton) return false;
      const otherRect = otherButton.getBoundingClientRect();
      const imageAction = /^(ver|vista previa|editar|eliminar|quitar|borrar|view|edit|remove|delete)(?: imagen| foto)?$/i;
      return flutterNodes().some((node) => {
        if (!(node.getAttribute("role") === "button" || node.matches("button")) || !imageAction.test(flutterName(node))) return false;
        const rect = node.getBoundingClientRect();
        return Math.abs(rect.top - otherRect.top) < 100 && (index === 0 ? rect.left < otherRect.left : rect.left > otherRect.left);
      });
    };
    const uploadButton = await waitFor(() => findUploadButton() || (sessionStorage.getItem(completionKey) === "selected" || hasUploadedPreview() ? true : null), 20000, `el botón «Subir img ${label}» o la imagen ya cargada`);
    if (uploadButton === true) {
      progressResult(`${label} ya se cargó en este formulario; continúo sin volver a subirla`);
      consoleEvent("OK", `Reintenté el reporte y conservé la imagen ya cargada en «${label}».`);
      return;
    }
    let fileData = await chrome.runtime.sendMessage(payload.imageToken ? { type: "CONTRAPLANO_GET_LOCAL_IMAGE", token: payload.imageToken, port: payload.imagePort } : { type: "CONTRAPLANO_GET_REPORT_IMAGE", url: payload.imageUrl });
    if (fileData?.error && payload.imageUrl) fileData = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_GET_REPORT_IMAGE", url: payload.imageUrl });
    if (!fileData || fileData.error) throw new Error(fileData?.error || `No pude leer la imagen para «${label}».`);
    progressDetail(`Preparando la selección de archivo en Windows para ${label}…`);
    const armed = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_ARM_FILE_PICKER", base64: fileData.base64, name: fileData.name || payload.imageName || "imagen-noticia.webp" });
    if (!armed?.jobId || armed.error) throw new Error(armed?.error || "No pude conectar el preparador con el selector de archivos.");
    // Arming the bridge is asynchronous and Flutter can replace the old node.
    // A native click also gives each file picker a fresh browser user gesture.
    const button = await waitFor(findUploadButton, 10000, `el botón actualizado «Subir img ${label}»`);
    progressDetail(`Abriendo el selector de ${label} con un clic de Windows…`);
    await activateFlutterControl(button, `Subir img ${label}`);
    progressDetail(`Esperando que el preparador seleccione la imagen en el cuadro Abrir de Windows (${label})…`);
    const started = Date.now();
    while (Date.now() - started < 40000) {
      const status = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_FILE_PICKER_STATUS", jobId: armed.jobId });
      if (status?.error || status?.status === "error") {
        if (hasUploadedPreview()) {
          sessionStorage.setItem(completionKey, "selected");
          consoleEvent('OK', `MRC ya muestra la vista previa de ${label}; continúo aunque el selector no devolvió su confirmación.`);
          return;
        }
        throw new Error(status?.error || "No se completó la selección de imagen en Windows.");
      }
      if (status?.status === "selected") {
        consoleEvent("OK", `Archivo seleccionado desde Windows para «${label}».`);
        // Keep a same-tab retry from uploading this image again if MRC has
        // already replaced its upload button with the selected-image preview.
        await new Promise((resolve) => setTimeout(resolve, 1200));
        sessionStorage.setItem(completionKey, "selected");
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 350));
    }
    if (hasUploadedPreview()) {
      sessionStorage.setItem(completionKey, "selected");
      consoleEvent('OK', `Confirmé la vista previa de ${label} después de esperar al selector.`);
      return;
    }
    throw new Error(`El selector de Windows no confirmó la imagen de «${label}». Cancela los selectores abiertos y reintenta.`);
  }

  function findTextButton(text) {
    return [...document.querySelectorAll("button")].find((button) => button.textContent.trim().replace(/\s+/g, " ").toLocaleLowerCase("es") === text.toLocaleLowerCase("es"));
  }

  async function waitFor(predicate, timeout = 12000, message = "elemento") {
    progressDetail(`Esperando ${message}… (máximo ${Math.ceil(timeout / 1000)} s)`);
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const result = predicate();
      if (result) return result;
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
    throw new Error(`No apareció ${message}.`);
  }

  function getEditorDocuments() {
    const docs = [document];
    for (const frame of document.querySelectorAll("iframe")) {
      try {
        const frameDoc = frame.contentDocument;
        if (frameDoc && frameDoc.querySelector(".block-editor-block-list__layout")) docs.push(frameDoc);
      } catch {}
    }
    return docs;
  }

  function getEditorDocument() {
    const docs = getEditorDocuments();
    return docs.find((doc) => {
      const layout = doc.querySelector(".block-editor-block-list__layout");
      return layout && layout.innerText.trim().length > 0;
    }) || docs.find((doc) => doc.querySelector(".block-editor-block-list__layout")) || document;
  }

  async function convertIfNeeded() {
    const classic = getEditorDocument().querySelector('.block-editor-block-list__layout > [data-type="core/freeform"]');
    if (!classic) return true;
    const selection = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_SELECT_CLASSIC_BLOCK" });
    if (selection?.error) throw new Error(selection.error);
    if (selection?.alreadyConverted) return true;
    const findConvertButton = () => [document, ...getEditorDocuments()].flatMap((doc) => [...doc.querySelectorAll("button.components-toolbar-button, button")]).find((button) => button.getClientRects().length > 0 && `${button.textContent || ""} ${button.getAttribute("aria-label") || ""} ${button.getAttribute("title") || ""}`.replace(/\s+/g, " ").toLocaleLowerCase("es").includes("convertir en bloques"));
    const selectedBlock = await waitFor(() => getEditorDocument().querySelector(`[data-block="${selection.clientId}"].is-selected`) || getEditorDocument().querySelector(`[data-block="${selection.clientId}"]`), 8000, "la selección del bloque Clásico");
    selectedBlock.click();
    const convert = await waitFor(findConvertButton, 10000, "el botón «Convertir en bloques» de la barra de herramientas del bloque Clásico").catch(() => null);
    if (!convert) {
      const apiResult = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_CONVERT_CLASSIC_BLOCKS" });
      if (!apiResult?.error && apiResult?.converted) {
        await waitFor(() => {
          const layout = getEditorDocument().querySelector(".block-editor-block-list__layout");
          return layout && !layout.querySelector(':scope > [data-type="core/freeform"]') && layout.querySelector(':scope > [data-type="core/paragraph"]');
        }, 12000, "los párrafos Gutenberg convertidos");
        return true;
      }
      throw new Error("No apareció «Convertir en bloques» en la barra del bloque Clásico y la conversión automática de respaldo tampoco funcionó.");
    }
    convert.click();
    try {
      await waitFor(() => {
        const layout = getEditorDocument().querySelector(".block-editor-block-list__layout");
        return layout && !layout.querySelector(':scope > [data-type="core/freeform"]') && layout.querySelector(':scope > [data-type="core/paragraph"]');
      }, 15000, "los párrafos Gutenberg convertidos");
    } catch {
      const apiResult = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_CONVERT_CLASSIC_BLOCKS" });
      if (apiResult?.error || !apiResult?.converted) throw new Error("Se pulsó «Convertir en bloques», pero no aparecieron bloques con data-type=core/paragraph como en tu ejemplo.");
      await waitFor(() => {
        const layout = getEditorDocument().querySelector(".block-editor-block-list__layout");
        return layout && !layout.querySelector(':scope > [data-type="core/freeform"]') && layout.querySelector(':scope > [data-type="core/paragraph"]');
      }, 12000, "los párrafos Gutenberg convertidos");
    }
    await new Promise((resolve) => setTimeout(resolve, 900));
    return true;
  }

  async function removeBoldFromParagraphs() {
    let changed = 0;
    try {
      const result = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_REMOVE_PARAGRAPH_BOLD" });
      if (result && !result.error) changed = result.changedParagraphs || 0;
    } catch {}
    const stillBold = () => [document, ...getEditorDocuments()].some((doc) => doc.querySelector('.block-editor-block-list__layout [data-type="core/paragraph"] strong, .block-editor-block-list__layout [data-type="core/paragraph"] b'));
    // La API de Gutenberg suele quitar el formato directamente. Si deja alguna marca,
    // usar la barra del bloque: seleccionar el texto en negrita y pulsar «Negrita».
    if (stillBold()) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      for (const doc of getEditorDocuments()) {
        const marks = [...doc.querySelectorAll('.block-editor-block-list__layout [data-type="core/paragraph"] strong, .block-editor-block-list__layout [data-type="core/paragraph"] b')];
        for (const mark of marks) {
          if (!mark.isConnected) continue;
          const selection = doc.getSelection?.();
          if (!selection) continue;
          const range = doc.createRange();
          range.selectNodeContents(mark);
          selection.removeAllRanges();
          selection.addRange(range);
          mark.closest('[data-type="core/paragraph"]')?.focus();
          await new Promise((resolve) => setTimeout(resolve, 150));
          const boldButton = [document, ...getEditorDocuments()].flatMap((toolbarDoc) => [...toolbarDoc.querySelectorAll('button[aria-label="Negrita"], button[title="Negrita"]')]).find((button) => button.getClientRects().length > 0);
          if (boldButton && boldButton.getAttribute("aria-pressed") === "true") {
            boldButton.click();
            changed += 1;
            await new Promise((resolve) => setTimeout(resolve, 250));
          }
        }
      }
    }
    if (stillBold()) throw new Error("Quedaron negritas en uno o más párrafos; tampoco funcionó el control «Negrita» de la barra del bloque.");
    return changed;
  }

  async function shortenLongParagraphs(pending) {
    const editorDocs = () => {
      const docs = new Set();
      const visit = (doc) => { if (!doc || docs.has(doc)) return; docs.add(doc); for (const frame of doc.querySelectorAll("iframe")) { try { visit(frame.contentDocument); } catch {} } };
      visit(document);
      for (const doc of getEditorDocuments()) visit(doc);
      return [...docs];
    };
    const rankMathDocs = () => {
      const docs = new Set(editorDocs());
      for (const frame of document.querySelectorAll("iframe")) {
        try {
          const frameDoc = frame.contentDocument;
          if (frameDoc?.querySelector(".components-panel__body.rank-math-checklist, li.seo-check-contentHasShortParagraphs")) docs.add(frameDoc);
        } catch {}
      }
      return [...docs];
    };
    const findChecklist = () => rankMathDocs().flatMap((doc) => [...doc.querySelectorAll("div.components-panel__body.rank-math-checklist.is-opened, div.components-panel__body.rank-math-checklist, .rank-math-checklist")])[0] || null;
    const findCheck = () => rankMathDocs().flatMap((doc) => [...doc.querySelectorAll("div.components-panel__body.rank-math-checklist li.seo-check-contentHasShortParagraphs, li.seo-check-contentHasShortParagraphs")])[0] || null;
    const normalize = (value) => String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("es");
    const wordCount = (value) => (String(value || "").match(/[\p{L}\p{N}]+/gu) || []).length;
    let changed = 0;
    let localFallback = 0;
    const splitLocally = (text) => {
      const source = String(text || "").replace(/\s+/g, " ").trim();
      const protectedNumbers = source.replace(/(\d)\.(?=\d)/g, "$1\uE000");
      const sentences = (protectedNumbers.match(/[^.!?]+[.!?]+(?:["'”»)]*)?|[^.!?]+$/gu) || [protectedNumbers]).map((part) => part.replace(/\uE000/g, ".").trim()).filter(Boolean);
      const units = [];
      for (const sentence of sentences) {
        if (wordCount(sentence) <= 65) { units.push(sentence); continue; }
        const clauses = sentence.split(/(?<=[,;:])\s+/u).filter(Boolean);
        for (const clause of clauses) {
          if (wordCount(clause) <= 65) { units.push(clause.trim()); continue; }
          const words = clause.trim().split(/\s+/);
          for (let index = 0; index < words.length; index += 65) units.push(words.slice(index, index + 65).join(" "));
        }
      }
      const result = [];
      let current = [];
      for (const unit of units) {
        if (current.length && wordCount([...current, unit].join(" ")) > 65) {
          result.push(current.join(" ").trim());
          current = [];
        }
        current.push(unit);
      }
      if (current.length) result.push(current.join(" ").trim());
      return result;
    };
    const rewriteBlock = async (clientId, original) => {
      const keyword = pending.focusKeyword || "";
      let paragraphs = [];
      try {
        const started = Date.now();
        progressDetail(`Ollama está revisando el párrafo ${changed + 1}. Puede tardar hasta 10 min; no cierres esta pestaña.`);
        const heartbeat = setInterval(() => progressDetail(`Ollama sigue revisando el párrafo ${changed + 1}… ${Math.floor((Date.now() - started) / 1000)} s de hasta 10 min.`), 10000);
        let result;
        try { result = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_REWRITE_LONG_PARAGRAPH", paragraph: original, keyword }); }
        finally { clearInterval(heartbeat); }
        paragraphs = Array.isArray(result?.paragraphs) ? result.paragraphs.map((value) => String(value || "").trim()).filter(Boolean) : [];
      } catch {}
      const validRewrite = () => {
        if (paragraphs.length < 2 || paragraphs.some((value) => wordCount(value) > 80)) return false;
        const normalizedSource = normalize(original);
        const normalizedResult = normalize(paragraphs.join(" "));
        if (keyword && normalizedSource.includes(normalize(keyword)) && !normalizedResult.includes(normalize(keyword))) return false;
        const sourceNumbers = original.match(/\d[\d.,]*/g) || [];
        const resultNumbers = paragraphs.join(" ").match(/\d[\d.,]*/g) || [];
        return !sourceNumbers.some((number) => !resultNumbers.includes(number));
      };
      if (!validRewrite()) {
        paragraphs = splitLocally(original);
        localFallback += 1;
      }
      if (paragraphs.length < 2 || paragraphs.some((value) => wordCount(value) > 80)) throw new Error("No pude dividir el párrafo sin superar el límite de palabras; conservé el contenido original.");
      const replaced = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_REPLACE_LONG_PARAGRAPH", clientId, paragraphs, expectedText: original });
      if (!replaced || replaced.error || !replaced.replaced) throw new Error(replaced?.error || "No pude reemplazar el párrafo por los bloques cortos.");
      changed += 1;
      await new Promise((resolve) => setTimeout(resolve, 900));
    };
    const processed = new Set();
    const readMarked = async () => {
      for (const doc of editorDocs()) {
        for (const mark of doc.querySelectorAll("mark.annotation-text-rank-math-annotations")) {
          if (!mark.textContent.trim()) continue;
          const block = mark.closest('[data-type="core/paragraph"],p.wp-block-paragraph');
          const clientId = block?.getAttribute("data-block") || (block?.id?.startsWith("block-") ? block.id.slice(6) : "");
          if (clientId && !processed.has(clientId)) return { clientId, text: (block.innerText || block.textContent || "").trim() };
        }
      }
      // React's canvas can omit data-type/data-block on the highlighted <p>.
      // Resolve only that marked text against a unique Gutenberg paragraph.
      const result = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_READ_HIGHLIGHTED_PARAGRAPH", postId: params.get("post"), excluded: [...processed] }).catch(() => null);
      if (result?.paragraph?.clientId && result.paragraph.text && !processed.has(result.paragraph.clientId)) return result.paragraph;
      return null;
    };
    const waitForMarked = async (timeout) => {
      const deadline = Date.now() + timeout;
      do {
        const item = await readMarked();
        if (item) return item;
        await new Promise((resolve) => setTimeout(resolve, 250));
      } while (Date.now() < deadline);
      return null;
    };
    let checklist = findChecklist();
    if (!checklist) {
      await ensureRankMathPanelOpen();
    }
    checklist = await waitFor(findChecklist, 12000, "el panel de análisis de Rank Math").catch(() => null);
    if (!checklist) throw new Error("No pude consultar el análisis de párrafos de Rank Math; no modifiqué párrafos por una estimación propia.");
    const readabilityButton = rankMathDocs().flatMap((doc) => [...doc.querySelectorAll("div.components-panel__body.rank-math-checklist button.components-panel__body-toggle, button.components-panel__body-toggle")]).find((button) => /legibilidad del contenido|content readability/i.test(button.textContent));
    if (readabilityButton && readabilityButton.getAttribute("aria-expanded") !== "true") readabilityButton.click();
    const initial = await waitFor(findCheck, 12000, "el análisis de párrafos cortos de Rank Math").catch(() => null);
    if (!initial) throw new Error("No apareció el estado de párrafos cortos de Rank Math; no modifiqué el contenido sin comprobarlo.");
    await new Promise((resolve) => setTimeout(resolve, 1200));
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const check = findCheck();
      if (check?.classList.contains("test-ok")) {
        progressDetail(changed ? `Rank Math ya aprueba los párrafos. Se dividieron ${changed}; no se modifican más.` : "Rank Math aprueba los párrafos; no es necesario dividir ninguno.");
        return { changed, localFallback, checked: true };
      }
      if (!check?.classList.contains("test-fail")) throw new Error("El análisis de párrafos de Rank Math aún no confirma si hay un error; conservé los demás párrafos.");
      if (pending.manual) {
        consoleEvent("AVISO", "Rank Math señala un párrafo largo. El texto manual se conserva; revísalo en el editor.");
        return { changed, localFallback, checked: true, needsReview: true };
      }
      progressDetail("Rank Math señala al menos un párrafo largo. Revisando uno y volviendo a comprobar el resultado…");
      const highlight = check.querySelector("button.rank-math-highlight-button");
      let item = await readMarked();
      if (!item && highlight) {
        highlight.click();
        item = await waitForMarked(5000);
        if (!item && findCheck()?.classList.contains("test-fail")) {
          // The eye is a toggle: the first click may have hidden existing marks.
          highlight.click();
          item = await waitForMarked(3000);
        }
      }
      if (!item?.clientId || !item.text) {
        const resolved = await waitFor(() => findCheck()?.classList.contains("test-ok"), 6000, "la actualización del análisis de párrafos").catch(() => false);
        if (resolved) return { changed, localFallback, checked: true };
        throw new Error("Rank Math señala un párrafo largo, pero no pude leer su remarcado. No modifiqué otros párrafos.");
      }
      processed.add(item.clientId);
      await rewriteBlock(item.clientId, item.text);
      await new Promise((resolve) => setTimeout(resolve, 1500));
    }
    if (findCheck()?.classList.contains("test-fail")) throw new Error("Rank Math aún marca párrafos largos después de ocho correcciones individuales.");
    return { changed, localFallback, checked: true };
  }

  async function insertNamedBlock(name) {
    const result = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_INSERT_EDITOR_BLOCK", blockName: name });
    if (!result || result.error) throw new Error(result?.error || `No pude insertar el bloque «${name}».`);
    await waitFor(() => getEditorDocument().querySelector(`[data-block="${result.clientId}"]`), 12000, `el bloque «${name}» en Gutenberg`);
  }

  async function openInserterAndChoose(name) {
    const editorDocs = () => [...new Set([document, ...getEditorDocuments()])];
    const inserter = await waitFor(() => editorDocs().flatMap((doc) => [...doc.querySelectorAll("button")]).find((button) => {
      const label = `${button.getAttribute("aria-label") || ""} ${button.getAttribute("title") || ""} ${button.className || ""}`.toLocaleLowerCase("es");
      return /block-editor-inserter__toggle|inserter.*toggle/.test(label) || /(?:añadir|insertar|add|insert).{0,35}(?:bloque|block)|(?:bloque|block).{0,35}(?:añadir|insertar|add|insert)/i.test(label);
    }), 10000, "el botón para insertar bloques (en el panel o el lienzo Gutenberg)");
    inserter.click();
    const search = await waitFor(() => editorDocs().flatMap((doc) => [...doc.querySelectorAll('.block-editor-inserter__search input, input[type="search"], input[placeholder*="Buscar"], input[placeholder*="Search"]')]).find((input) => input.getClientRects().length > 0), 10000, "la búsqueda de bloques");
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(search), "value")?.set;
    if (setter) setter.call(search, name); else search.value = name;
    search.dispatchEvent(new search.ownerDocument.defaultView.Event("input", { bubbles: true }));
    search.dispatchEvent(new search.ownerDocument.defaultView.Event("change", { bubbles: true }));
    const target = await waitFor(() => {
      const title = editorDocs().flatMap((doc) => [...doc.querySelectorAll(".block-editor-block-types-list__item-title, .block-editor-block-types-list__item, [role='option']")]).find((node) => node.textContent.trim().replace(/\s+/g, " ").toLocaleLowerCase("es") === name.toLocaleLowerCase("es"));
      return title?.closest("button, [role='option']") || (title?.matches("button, [role='option']") ? title : null);
    }, 10000, `el bloque «${name}»`);
    target.click();
    await new Promise((resolve) => setTimeout(resolve, 600));
  }

  async function insertImageAfterFirstHeading(pending) {
    const localImage = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_GET_LOCAL_IMAGE", token: pending.imageToken, port: pending.imagePort });
    if (!localImage || localImage.error) throw new Error(localImage?.error || "No pude leer la imagen elegida en el preparador.");
    const result = await editorMessage({ type: "CONTRAPLANO_APPLY_SELECTED_IMAGE", postId: params.get("post"), base64: localImage.base64, mime: localImage.mime, name: pending.imageName || "imagen-noticia.jpg", uploadKey: pending.imageToken, policy: pending.imagePolicy === "replace" ? "replace" : "missing", alt: pending.focusKeyword || pending.title || "" }, 65000);
    if (result?.error || !result?.imageUrl) throw new Error(result?.error || "WordPress no confirmó la imagen elegida.");
    const imageBlock = result.clientId ? await waitFor(() => getEditorDocument().querySelector(`[data-block="${result.clientId}"]`), 12000, "el bloque de la imagen actualizada") : null;
    return { ...result, imageBlock };
  }

  async function setFeaturedImage(attachmentId, imageUrl, imageName, altText = "") {
    await ensureEditorSidebarOpen();
    const entryTab = await waitFor(() => [...document.querySelectorAll('[role="tab"]')].find((tab) => tab.textContent.trim().toLocaleLowerCase("es") === "entrada"), 10000, "la pestaña «Entrada» del panel lateral");
    if (entryTab.getAttribute("aria-selected") !== "true") entryTab.click();
    const featuredButton = await waitFor(() => [...document.querySelectorAll("button")].find((button) => button.textContent.trim().toLocaleLowerCase("es").includes("establecer la imagen destacada") && button.getClientRects().length > 0), 10000, "el botón de imagen destacada dentro de «Entrada»");
    featuredButton.click();
    const dialog = await waitFor(() => document.querySelector(".media-frame.mode-select") || document.querySelector(".media-modal") || document.querySelector('[role="dialog"]'), 12000, "la biblioteca de medios");
    const fileName = (imageName || "").split(/[\\/]/).pop().toLocaleLowerCase("es");
    const fileStem = fileName.replace(/\.[^.]+$/, "");
    const findAttachment = () => {
      const items = [...document.querySelectorAll(".media-frame.mode-select li.attachment[data-id], .media-frame.mode-select .attachment[data-id], .media-frame.mode-select [role='checkbox'][data-id]")];
      return items.find((item) => {
        if (attachmentId && item.getAttribute("data-id") === attachmentId) return true;
        const text = `${item.textContent} ${item.getAttribute("aria-label") || ""} ${item.querySelector("img")?.src || ""} ${item.querySelector("img")?.alt || ""}`.toLocaleLowerCase("es");
        return fileStem && text.includes(fileStem);
      }) || null;
    };
    let attachment = await waitFor(findAttachment, 2000, `la imagen «${fileName}» en los medios recientes`).catch(() => null);
    if (!attachment) {
      const search = await waitFor(() => document.getElementById("media-search-input") || dialog.querySelector("input.media-search-input, input[placeholder*='Buscar medios' i], input[aria-label*='Buscar medios' i], input[type='search']"), 10000, "el campo «Buscar medios» de la biblioteca");
      search.focus();
      setNativeValue(search, fileStem);
      search.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true }));
      attachment = await waitFor(findAttachment, 20000, `la imagen «${fileName}» en la biblioteca de medios`);
    }
    const selectAttachment = attachment.querySelector("button.check") || attachment;
    selectAttachment.click();
    if (altText) {
      const mediaAltField = await waitFor(() => document.getElementById("attachment-details-alt-text"), 8000, "el texto alternativo de los detalles del adjunto");
      setNativeValue(mediaAltField, altText);
      await waitFor(() => mediaAltField.value === altText, 4000, "el texto alternativo en los detalles del adjunto");
      await waitFor(() => document.querySelector(".media-sidebar .attachment-details.save-ready .settings-save-status .saved"), 8000, "el guardado del texto alternativo en la biblioteca");
    }
    const confirm = await waitFor(() => document.querySelector(".media-frame.mode-select button.media-button-select:not(:disabled)") || dialog.querySelector("button.media-button-select:not(:disabled)") || [...dialog.querySelectorAll("button")].find((button) => /establecer (?:la )?imagen destacada|set featured image/i.test(button.textContent.trim()) && !button.disabled), 10000, "el botón «Establecer la imagen destacada»");
    confirm.click();
    await waitFor(() => !document.querySelector(".media-frame.mode-select"), 15000, "el cierre de la biblioteca después de establecer la imagen destacada");
    return Boolean(altText);
  }

  async function ensureRankMathPanelOpen() {
    const docs = () => [...new Set([document, ...(typeof getEditorDocuments === "function" ? getEditorDocuments() : [])])];
    const visible = (node) => node && (!node.getClientRects || node.getClientRects().length > 0);
    const findPanel = () => docs().map((doc) => doc.querySelector(".rank-math-focus-keyword")).find((panel) => visible(panel) && panel.querySelector(".tagify__input, tags.tagify, input[placeholder]"));
    const findButton = () => {
      for (const doc of docs()) {
        const buttons = [...doc.querySelectorAll('button[aria-controls*="rank-math"], button[aria-label*="rank math" i], button[title*="rank math" i]')];
        for (const icon of doc.querySelectorAll('.rank-math-toolbar-score, .rm-icon-rank-math')) { const button = icon.closest('button'); if (button) buttons.push(button); }
        const found = buttons.find((button) => visible(button) && !button.disabled && button.getAttribute("aria-disabled") !== "true");
        if (found) return found;
      }
      return null;
    };
    const generalTab = () => docs().flatMap((doc) => [...doc.querySelectorAll('[role="tab"]')]).find((node) => {
      const scope = node.closest('[id*="rank-math"], [class*="rank-math"]');
      return visible(node) && /^(general|general seo)$/i.test(String(node.textContent || node.getAttribute("aria-label") || "").trim()) && scope && !["BODY", "HTML"].includes(scope.tagName);
    });
    const deadline = Date.now() + 35000;
    const lastClicked = new WeakMap();
    let nextApi = 0, diagnostic = null;
    while (Date.now() < deadline) {
      if (findPanel()) return;
      const tab = generalTab();
      if (tab && tab.getAttribute("aria-selected") !== "true" && Date.now() - (lastClicked.get(tab) ?? Number.NEGATIVE_INFINITY) >= 1800) {
        lastClicked.set(tab, Date.now()); tab.click();
        progressDetail("Rank Math ya está abierto; cambiando a General para leer las palabras clave…");
      } else {
        const button = findButton();
        if (button && button.getAttribute("aria-expanded") !== "true" && button.getAttribute("aria-pressed") !== "true" && Date.now() - (lastClicked.get(button) ?? Number.NEGATIVE_INFINITY) >= 1800) {
          lastClicked.set(button, Date.now()); button.click();
          progressDetail("Abriendo el panel de Rank Math y esperando sus campos…");
        } else if (Date.now() >= nextApi) {
          progressDetail("Esperando Rank Math. Intentando abrir su panel desde WordPress aunque el botón esté oculto…");
          diagnostic = await editorMessage({ type: "CONTRAPLANO_OPEN_RANK_MATH", postId: params.get("post") }, 8000).catch((error) => ({ error: error.message }));
          nextApi = Date.now() + 5000;
        }
      }
      await new Promise((resolve) => setTimeout(resolve, 400));
    }
    if (findPanel()) return;
    if (diagnostic?.available === false) throw new Error("Rank Math no está disponible en el editor de esta cuenta o no terminó de cargar en 35 segundos. Revisa que esa cuenta pueda ver Rank Math al editar la entrada; después vuelve a intentarlo.");
    throw new Error("No pude abrir los campos de Rank Math, ni con su botón ni desde WordPress. " + (diagnostic?.detail || diagnostic?.error || "Abre Rank Math y su pestaña General antes de reintentar."));
  }

  async function ensureRankMathKeywords(pending) {
    await ensureRankMathPanelOpen();
    progressDetail("Comprobando las palabras clave contra el cuerpo de la noticia…");
    const read = await editorMessage({ type: "CONTRAPLANO_FOCUS_KEYWORDS", postId: params.get("post"), readOnly: true });
    if (read?.error) throw new Error(read.error);
    let primaryRejectedByRankMath = false;
    if (read?.keywords?.length) {
      const docs = typeof document === "undefined" ? [] : [...new Set([document, ...(typeof getEditorDocuments === "function" ? getEditorDocuments() : [])])];
      const tag = docs.map((doc) => doc.querySelector('.rank-math-focus-keyword tag.tagify__tag')).find(Boolean);
      if (tag && !tag.classList.contains("selected")) {
        tag.click();
        await new Promise((resolve) => setTimeout(resolve, 600));
      }
      const basic = docs.flatMap((doc) => [...doc.querySelectorAll('button.components-panel__body-toggle')]).find((button) => /^seo b[aá]sico|^basic seo/i.test(button.textContent.trim()));
      if (basic && basic.getAttribute("aria-expanded") !== "true") basic.click();
      const readHealth = () => {
        const checks = docs.flatMap((doc) => [...doc.querySelectorAll('li.seo-check-keywordIn10Percent, li.seo-check-keywordInContent')]);
        return checks.length ? { failed: checks.some((item) => item.classList.contains("test-fail")), approved: checks.length >= 2 && checks.every((item) => item.classList.contains("test-ok")) } : null;
      };
      const health = readHealth() || (typeof waitFor === "function" && docs.length ? await waitFor(readHealth, 6000, "la evaluación de la palabra clave principal en Rank Math").catch(() => null) : null);
      if (!health?.failed) {
        if (read.visible === false) throw new Error("La palabra clave está guardada, pero no pude confirmarla visible en Rank Math. No la reemplacé.");
        pending.focusKeyword = read.keywords[0];
        consoleEvent(health?.approved ? "OK" : "AVISO", health?.approved
          ? `Rank Math aprueba la palabra clave principal «${pending.focusKeyword}» en el inicio y el contenido. La conservo sin pedir otra a Ollama.`
          : `Conservo la palabra clave principal «${pending.focusKeyword}»: Rank Math no confirmó un error de presencia. No la reemplazo por una estimación propia.`);
        return pending.focusKeyword;
      }
      primaryRejectedByRankMath = true;
      progressDetail(`Rank Math sí marca un error de presencia para «${read.keywords[0]}». Revisando alternativas pertinentes…`);
    }
    let body = pending.humanizedBody || pending.body || "";
    if (typeof getEditorDocument === "function") {
      const doc = getEditorDocument();
      const paragraphs = [...doc.querySelectorAll('[data-type="core/paragraph"]')].map((node) => node.innerText || node.textContent || "").filter((text) => text.trim());
      body = paragraphs.length ? paragraphs.join("\n\n") : doc.querySelector(".block-editor-block-list__layout")?.innerText || body;
    }
    body = String(body).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
    const words = body.split(/\s+/).filter(Boolean);
    const intro = words.slice(0, words.length <= 300 ? words.length : Math.max(1, Math.ceil(words.length * 0.1))).join(" ");
    const normalize = (value) => String(value || "").replace(/\s+/g, " ").trim().toLocaleLowerCase("es");
    const inBody = (word) => Boolean(normalize(word) && normalize(body).includes(normalize(word)));
    const inIntro = (word) => Boolean(normalize(word) && normalize(intro).includes(normalize(word)));
    let keywords = read?.keywords || [];
    const badPrimary = keywords.length > 0 && (primaryRejectedByRankMath || !inBody(keywords[0]) || !inIntro(keywords[0]));
    const repair = badPrimary || keywords.some((word) => !inBody(word)) || (keywords.length > 0 && keywords.length < 3);
    if (!keywords.length || badPrimary || keywords.length < 3) {
      progressDetail(badPrimary ? "La palabra clave actual no aparece al inicio del cuerpo. Seleccionando otra sin modificar el texto…" : "Rank Math está vacío. Buscando palabras relacionadas con el contenido (hasta tres intentos)…");
      const generationStarted = Date.now();
      progressDetail("Ollama está revisando las palabras clave. Puede tardar hasta 10 min; la noticia no cambiará mientras espera.");
      const generationHeartbeat = setInterval(() => progressDetail(`Ollama sigue revisando las palabras clave… ${Math.floor((Date.now() - generationStarted) / 1000)} s de hasta 10 min.`), 10000);
      let generated;
      try { generated = await editorMessage({ type: "CONTRAPLANO_GENERATE_FOCUS_KEYWORDS", title: pending.humanizedTitle || pending.title, body }, 620000); }
      finally { clearInterval(generationHeartbeat); }
      if (generated?.error || !generated?.keywords?.length) {
        if (!badPrimary && keywords.length && keywords.some(inBody)) {
          consoleEvent("AVISO", `Conservo las palabras válidas ya existentes; no pude completar tres: ${generated?.error || "sin propuestas válidas"}`);
        } else throw new Error(generated?.error || "No pude generar palabras clave para esta noticia.");
      }
      const candidates = badPrimary || !keywords.length ? [...(generated?.keywords || []), ...(repair ? keywords.filter(inBody) : [])] : [...keywords.filter(inBody), ...(generated?.keywords || [])];
      const seen = new Set();
      keywords = candidates.filter((word) => { const key = normalize(word); if (!inBody(word) || seen.has(key)) return false; seen.add(key); return true; }).slice(0, 5);
      if (!keywords.length || !inIntro(keywords[0])) throw new Error("La palabra propuesta no aparece literalmente al inicio del contenido. No modifiqué el texto para introducirla.");
    }
    if (repair) keywords = keywords.filter(inBody);
    await ensureRankMathPanelOpen();
    const confirmed = await editorMessage({ type: "CONTRAPLANO_FOCUS_KEYWORDS", postId: params.get("post"), keywords, repair, expectedPrimary: read?.keywords?.[0] || "" });
    if (confirmed?.error || !confirmed?.keywords?.length || !confirmed.visible) throw new Error(confirmed?.error || "No pude confirmar las palabras clave visibles en Rank Math.");
    if (!inBody(confirmed.keywords[0]) || !inIntro(confirmed.keywords[0])) throw new Error("La palabra clave cambió durante la revisión y no aparece al inicio del contenido. Revisa el panel de Rank Math.");
    pending.focusKeyword = confirmed.keywords[0];
    if (confirmed.keywords.length < 3) {
      progressResult(`Solo ${confirmed.keywords.length} palabra(s) clave pertinentes; puedes añadir más en Rank Math.`);
      consoleEvent("AVISO", `Solo quedaron ${confirmed.keywords.length} palabra(s) clave pertinentes. Revisa si deseas añadir otras.`);
    }
    consoleEvent("OK", `${confirmed.repaired ? "Palabra clave corregida" : confirmed.preserved ? "Palabras clave conservadas" : "Palabras clave creadas"}: ${confirmed.keywords.join(", ")}. La principal aparece al inicio del cuerpo.`);
    return pending.focusKeyword;
  }

  async function optimizeRankMathSnippet(pending) {
    const keyword = await ensureRankMathKeywords(pending);

    const seoSourceTitle = pending.humanizedTitle || pending.title || "";
    const seoSourceBody = pending.humanizedBody || pending.body || "";
    const source = `${seoSourceTitle} ${seoSourceBody}`;
    const sourcePlain = source.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
    const amount = /\b2[., ]?200\b/i.test(sourcePlain) || /dos mil doscientos/i.test(sourcePlain) ? "2.200 kilos" : "";
    const countMatch = sourcePlain.match(/\b(\d{1,3})\s+(?:personas|traficantes|detenidos|detenidas)\b/i) || sourcePlain.match(/detuvo\s+(?:a\s+)?(\d{1,3})\b/i);
    const count = countMatch?.[1] || "";
    const monthMatch = sourcePlain.match(/\b(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)\b/i);
    const month = monthMatch?.[1] || "";

    const slug = keyword.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("es").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const powerWords = ["impactante", "histórico", "asombroso", "espectacular", "extraordinario", "formidable", "fascinante", "increíble", "sensacional", "único", "poderoso", "brillante", "cautivador", "fenomenal", "magnífico", "memorable", "notable", "novedoso", "innovador", "inolvidable", "sublime", "victorioso", "vigoroso", "auténtico", "eficaz", "indispensable", "nuevo"];
    const hasPowerWord = (value) => {
      const words = normalizeSeo(value).match(/[a-z0-9]+/g) || [];
      return powerWords.some((word) => words.includes(normalizeSeo(word)));
    };
    const amountShort = amount ? amount.replace(/\s+kilos?$/i, " kg") : count ? `${count} detenidos` : "";
    let fallbackTitle = `${keyword}: golpe impactante${amountShort ? ` (${amountShort})` : ""}`;
    if (fallbackTitle.length > 60) fallbackTitle = `${keyword}: impactante`;
    if (fallbackTitle.length > 60 && keyword.length + " impactante".length <= 60) fallbackTitle = `${keyword} impactante`;
    if (fallbackTitle.length > 60) fallbackTitle = keyword;
    let fallbackDescription;
    if (amount && count) {
      const subject = /carabineros/i.test(sourcePlain) ? "Carabineros" : "Las autoridades";
      fallbackDescription = `${keyword}: ${subject} incautó ${amount} de drogas y detuvo a ${count} personas${month ? ` durante ${month}` : ""}.`;
    } else {
      const sentence = (sourcePlain.split(/(?<=[.!?])\s+/)[0] || pending.title || keyword).trim();
      fallbackDescription = normalizeSeo(sentence).includes(normalizeSeo(keyword)) ? sentence : `${keyword}: ${sentence}`;
    }

    let generated = null;
    try {
      const generationStarted = Date.now();
      progressDetail("Ollama está redactando los metadatos SEO; puede tardar hasta 10 min.");
      const generationHeartbeat = setInterval(() => progressDetail(`Ollama sigue redactando los metadatos SEO… ${Math.floor((Date.now() - generationStarted) / 1000)} s de hasta 10 min.`), 10000);
      let result;
      try { result = await chrome.runtime.sendMessage({ type: "CONTRAPLANO_GENERATE_SEO", keyword, title: seoSourceTitle, body: seoSourceBody }); }
      finally { clearInterval(generationHeartbeat); }
      if (result?.error) throw new Error(result.error);
      generated = result?.seo || null;
    } catch {}

    let title = typeof generated?.title === "string" ? generated.title.trim() : "";
    if (!title || title.length > 60 || !normalizeSeo(title).startsWith(normalizeSeo(keyword)) || !hasPowerWord(title)) title = fallbackTitle;
    if (title.length > 60 || !normalizeSeo(title).startsWith(normalizeSeo(keyword)) || !hasPowerWord(title)) {
      throw new Error("No pude crear un título que empiece con la palabra clave, incluya una power word y respete los 60 caracteres.");
    }
    let description = typeof generated?.description === "string" ? generated.description.trim() : "";
    if (description.length > 160) {
      const firstSentence = description.match(/^[\s\S]*?[.!?](?=\s|$)/)?.[0] || "";
      description = firstSentence;
    }
    if (!description || description.length > 160 || !normalizeSeo(description).includes(normalizeSeo(keyword))) description = fallbackDescription;
    if (description.length > 160) description = truncateAtWord(description, 160);

    const generatedSlug = typeof generated?.slug === "string" ? generated.slug.trim() : "";
    const generatedSlugPlain = normalizeSeo(generatedSlug).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const keywordSlugPlain = normalizeSeo(keyword).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    let finalSlug = generatedSlugPlain.length <= 50 && generatedSlugPlain.includes(keywordSlugPlain) ? generatedSlugPlain : slug;
    if (finalSlug.length > 75) finalSlug = finalSlug.slice(0, 75).replace(/-+$/, "");

    const editSnippet = await waitFor(() => document.querySelector("button.rank-math-edit-snippet"), 10000, "el botón «Editar snippet»");
    editSnippet.click();
    const titleInput = await waitFor(() => document.getElementById("rank-math-editor-title"), 10000, "el título del snippet");
    const permalinkInput = await waitFor(() => document.getElementById("rank-math-editor-permalink"), 10000, "el enlace permanente del snippet");
    const descriptionInput = await waitFor(() => document.getElementById("rank-math-editor-description"), 10000, "la descripción del snippet");
    setNativeValue(titleInput, title);
    setNativeValue(permalinkInput, finalSlug);
    setNativeValue(descriptionInput, description);
    await waitFor(() => titleInput.value === title && permalinkInput.value === finalSlug && descriptionInput.value === description, 6000, "la actualización de los tres campos del snippet");
    if (titleInput.value.length > 60 || permalinkInput.value.length > 75 || descriptionInput.value.length > 160) {
      throw new Error(`Rank Math conservó valores fuera de límite (${titleInput.value.length}/60, ${permalinkInput.value.length}/75, ${descriptionInput.value.length}/160).`);
    }
    await closeSnippetDialog();
    return { keyword, title, slug: finalSlug, description };
  }

  async function readFinalRankMathScore(savedScore = null) {
    const valid = (value) => value !== "" && value != null && Number.isInteger(Number(value)) && Number(value) >= 1 && Number(value) <= 100;
    const readVisibleScore = () => {
      const nodes = [...document.querySelectorAll(".rank-math-toolbar-score .score-text, .rank-math-toolbar-score .seo-score")];
      for (const node of nodes) {
        const match = String(node.textContent || "").replace(/\s+/g, " ").match(/(\d{1,3})\s*\/\s*100/);
        if (match && valid(match[1])) return { score: Number(match[1]), source: "indicador de Rank Math" };
      }
      return null;
    };
    const rankButton = document.querySelector('button[aria-controls="rank-math:seo-by-rank-math-sidebar"]');
    if (rankButton && rankButton.getAttribute("aria-expanded") !== "true") rankButton.click();
    const started = Date.now();
    let stableSince = started, previousScore = null, review = null;
    progressDetail("Esperando el recálculo de Rank Math: mínimo 12 segundos y 5 segundos con el mismo puntaje…");
    while (Date.now() - started < 45000) {
      const visible = readVisibleScore();
      const api = await editorMessage({ type: "CONTRAPLANO_READ_RANK_SCORE", postId: params.get("post") }).catch(() => null);
      const apiReview = valid(api?.score) ? { score: Number(api.score), source: api.source || "análisis de Rank Math" } : null;
      const sample = visible || apiReview;
      const disagree = visible && apiReview && visible.score !== apiReview.score;
      if (sample && !disagree) {
        if (sample.score !== previousScore) {
          previousScore = sample.score;
          stableSince = Date.now();
          consoleEvent("ESPERA", `Rank Math muestra ${sample.score}/100; espero que termine el recálculo antes de guardarlo.`);
        }
        if (Date.now() - started >= 12000 && Date.now() - stableSince >= 5000) { review = sample; break; }
      } else {
        previousScore = null;
        stableSince = Date.now();
      }
      progressDetail(`Rank Math: ${sample ? sample.score + "/100" : "cargando"}. Esperando puntaje estable${disagree ? "; indicador y análisis aún no coinciden" : ""}…`);
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    if (!review && previousScore === null && valid(savedScore) && !readVisibleScore()) review = { score: Number(savedScore), source: "puntaje guardado en la entrada publicada (análisis no disponible)" };
    if (!review) throw new Error("Rank Math no mostró un puntaje válido y no hay un valor guardado disponible para esta entrada.");
    consoleEvent("OK", `Rank Math ${review.score}/100 obtenido del ${review.source}; se conservará para el reporte.`);
    return { ...review, failedChecks: document.querySelectorAll(".rank-math-checklist li.test-fail").length };
  }

  function normalizeSeo(value) {
    return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("es");
  }

  function truncateAtWord(value, limit) {
    if (value.length <= limit) return value;
    const cut = value.slice(0, limit - 1);
    const end = cut.lastIndexOf(" ");
    return cut.slice(0, end > 0 ? end : limit - 1).trimEnd() + "…";
  }

  function setNativeValue(element, value) {
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), "value")?.set;
    if (setter) setter.call(element, value); else element.value = value;
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  function visibleEditorControl(node) {
    if (!node || !node.getClientRects().length || node.closest('[hidden], [aria-hidden="true"]')) return false;
    const style = typeof getComputedStyle === 'function' ? getComputedStyle(node) : null;
    return !style || (style.display !== 'none' && style.visibility !== 'hidden');
  }

  async function closeSnippetDialog() {
    const field = () => [...document.querySelectorAll('#rank-math-editor-title')].find(visibleEditorControl);
    if (!field()) return true;
    for (let attempt = 0; attempt < 3; attempt++) {
      const input = field();
      if (!input) return true;
      const dialog = input.closest('[role="dialog"], .components-modal__frame, .rank-math-modal');
      const candidates = dialog ? [...dialog.querySelectorAll('button, [role="button"]')].filter(visibleEditorControl) : [];
      const close = candidates.find(button => /cerrar|close/i.test(`${button.getAttribute('aria-label') || ''} ${button.getAttribute('title') || ''}`))
        || candidates.find(button => [...button.querySelectorAll('svg path')].some(path => (path.getAttribute('d') || '').includes('13.06 12')));
      if (close && attempt < 2) close.click();
      else input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true, cancelable: true }));
      const closed = await waitFor(() => !field(), 3000, 'el cierre visible del snippet').catch(() => false);
      if (closed) return true;
      progressDetail('El snippet sigue abierto. Reintentando su cierre antes de continuar…');
    }
    throw new Error('No pude cerrar el cuadro del snippet. Los metadatos están escritos; queda pendiente recuperar el editor.');
  }

  async function ensurePostPanelOpen() {
    await closeSnippetDialog();
    await ensureEditorSidebarOpen().catch(() => null);
    const deadline = Date.now() + 16000;
    let nextApi = 0, lastTab = null, lastClick = 0;
    while (Date.now() < deadline) {
      const tab = [...document.querySelectorAll('[role="tab"]')].find(node => visibleEditorControl(node) && /^(entrada|post|publicación|publicacion)$/i.test((node.textContent || node.getAttribute('aria-label') || '').trim()));
      if (tab) {
        if (tab.getAttribute('aria-selected') !== 'true' && (tab !== lastTab || Date.now() - lastClick > 2000)) {
          tab.click(); lastTab = tab; lastClick = Date.now();
        }
        const controlled = tab.getAttribute('aria-controls');
        const panel = (controlled && document.getElementById(controlled)) || [...document.querySelectorAll('[role="tabpanel"]')].find(node => (node.getAttribute('aria-labelledby') || '').split(/\s+/).includes(tab.id) && tab.id);
        if (visibleEditorControl(panel)) return panel;
      }
      const fallback = [...document.querySelectorAll('[role="tabpanel"], .editor-sidebar')].find(node => visibleEditorControl(node) && !node.closest('[id*="rank-math"], .rank-math-sidebar') && node.querySelector('.editor-post-taxonomies__flat-term-most-used, .editor-post-taxonomies__hierarchical-terms-list, .components-form-token-field'));
      if (fallback && (!tab || tab.getAttribute('aria-selected') === 'true')) return fallback;
      if (Date.now() >= nextApi) {
        await editorMessage({ type: 'CONTRAPLANO_OPEN_POST_SETTINGS', postId: params.get('post') }, 5000).catch(() => null);
        nextApi = Date.now() + 4000;
      }
      await new Promise(resolve => setTimeout(resolve, 300));
    }
    throw new Error('No pude recuperar la pestaña Entrada y su panel de categorías y etiquetas después de cerrar el snippet.');
  }

  async function ensureEditorSidebarOpen() {
    const findEditorTab = () => [...document.querySelectorAll('[role="tab"]')].find((tab) => /^(entrada|bloque)$/i.test(tab.textContent.trim()) && tab.getClientRects().length > 0);
    if (findEditorTab()) return true;
    const settings = [...document.querySelectorAll("button")].find((button) => /ajustes|settings/i.test(`${button.getAttribute("aria-label") || ""} ${button.getAttribute("title") || ""}`) && button.getClientRects().length > 0);
    if (settings) settings.click();
    await waitFor(findEditorTab, 8000, "el panel lateral del editor (Entrada/Bloque)");
    return true;
  }

  async function setImageAlt(imageBlock, keyword) {
    const selectionTarget = imageBlock;
    if (selectionTarget) selectionTarget.click();
    await ensureEditorSidebarOpen();
    await new Promise((resolve) => setTimeout(resolve, 300));
    const blockTab = await waitFor(() => [...document.querySelectorAll('[role="tab"]')].find((tab) => tab.textContent.trim().toLocaleLowerCase("es") === "bloque"), 8000, "la pestaña «Bloque» del panel lateral");
    if (blockTab.getAttribute("aria-selected") !== "true") blockTab.click();
    const panel = blockTab.getAttribute("aria-controls") ? document.getElementById(blockTab.getAttribute("aria-controls")) : document;
    const altField = await waitFor(() => {
      const label = [...(panel || document).querySelectorAll("label")].find((item) => item.textContent.trim().toLocaleLowerCase("es").startsWith("texto alternativo"));
      return (label && document.getElementById(label.htmlFor)) || (panel || document).querySelector('textarea[aria-label*="Texto alternativo"], textarea[placeholder*="alternativo" i]');
    }, 8000, "el campo de texto alternativo de la imagen").catch(() => null);
    if (!altField) return false;
    setNativeValue(altField, keyword);
    return true;
  }

  async function setPostTaxonomies() {
    let documentPanel = await ensurePostPanelOpen();
    const errors = [];
    let categories = "sin cambiar";
    let tagsSummary = "sin cambiar";
    const desiredTags = ["#contraplano", "#contraplanotv", "#Noticias", "#mediosdecomunicacion", "#chile", "#noticiashoy", "#periodico", "contraplano", "noticias", "contraplanotv"];
    try {
      const tagPanelButton = await waitFor(() => [...documentPanel.querySelectorAll("button.components-panel__body-toggle")].find((button) => button.textContent.trim().toLocaleLowerCase("es") === "etiquetas"), 8000, "el panel Etiquetas");
      if (tagPanelButton.getAttribute("aria-expanded") !== "true") tagPanelButton.click();
      documentPanel = await ensurePostPanelOpen();
      const tokenContainer = await waitFor(() => documentPanel.querySelector(".components-form-token-field"), 8000, "el campo de etiquetas");
      const normalizeTag = (value) => String(value || "").replace(/^\s*#/, "").replace(/\s+/g, " ").trim().toLocaleLowerCase("es");
      const tokenTexts = () => [...tokenContainer.querySelectorAll(".components-form-token-field__token-text, .components-form-token-field__token, [data-value]")].flatMap((node) => [node.textContent, node.getAttribute("data-value"), node.getAttribute("aria-label")]).filter(Boolean).map((value) => value.replace(/remove|eliminar|quitar/gi, "").trim());
      const hasTag = (tag) => tokenTexts().some((value) => normalizeTag(value) === normalizeTag(tag));
      let added = 0;
      let alreadySelected = 0;
      const tagErrors = [];
      for (const tag of desiredTags) {
        try {
          if (hasTag(tag)) { alreadySelected += 1; continue; }
          const button = await waitFor(() => [...documentPanel.querySelectorAll(".editor-post-taxonomies__flat-term-most-used-list button")].find((item) => item.textContent.trim() === tag), 5000, `la etiqueta ${tag}`);
          button.click();
          await new Promise((resolve) => setTimeout(resolve, 250));
          added += 1;
        } catch (error) { tagErrors.push(`${tag}: ${error.message}`); }
      }
      if (tagErrors.length) errors.push(...tagErrors.map((error) => `Etiquetas: ${error}`));
      tagsSummary = `${added} botones pulsados; ${alreadySelected} ya estaban seleccionadas`;
    } catch (error) { errors.push(`Etiquetas: ${error.message}`); }
    return { categories, tags: tagsSummary, errors };
  }
})();
