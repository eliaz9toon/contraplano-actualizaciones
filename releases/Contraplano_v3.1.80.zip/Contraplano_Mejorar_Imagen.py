"""Mejora de imagenes pequenas con Real-ESRGAN (se ejecuta en el PC; la imagen no sale del equipo).

El programa (github.com/xinntao/Real-ESRGAN, licencia BSD-3) no viaja en las actualizaciones: se descarga una sola vez,
cuando la persona acepta, y se comprueba su huella SHA-256 antes de usarlo.
"""
import hashlib
import os
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile
from io import BytesIO
from pathlib import Path

from PIL import Image

URL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip"
SIZE = 45474481
SHA256 = "abc02804e17982a3be33675e4d471e91ea374e65b70167abc09e31acb412802d"
EXE = "realesrgan-ncnn-vulkan.exe"
FILES = (EXE, "vcomp140.dll", "models/realesrgan-x4plus.bin", "models/realesrgan-x4plus.param")
SMALL_WIDTH = 800        # bajo este ancho se ofrece mejorarla (el contenido del sitio mide unos 1050 px)
MAX_WIDTH = 1600


def tool_dir():
    return Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "Contraplano" / "herramientas_hd"


def installed():
    return all((tool_dir() / name).is_file() for name in FILES)


def small_size(path):
    """(ancho, alto) si la imagen es pequena y conviene ofrecer mejorarla; si no, None."""
    try:
        with Image.open(path) as image:
            width, height = image.size
            animated = getattr(image, "is_animated", False)
    except (OSError, ValueError):
        return None
    if animated or width >= SMALL_WIDTH or height > 2000:
        return None
    return width, height


def install(progress=lambda text: None, context=None):
    """Descarga y prepara la herramienta. Lanza ValueError si la descarga no coincide con la esperada."""
    if installed():
        return
    target = tool_dir()
    target.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="descarga-", dir=target) as temporary:
        archive_path = Path(temporary) / "realesrgan.zip"
        digest, received, shown = hashlib.sha256(), 0, -10
        request = urllib.request.Request(URL, headers={"User-Agent": "Contraplano"})
        with urllib.request.urlopen(request, timeout=60, context=context) as response, archive_path.open("wb") as output:
            while True:
                chunk = response.read(262144)
                if not chunk:
                    break
                received += len(chunk)
                if received > SIZE:
                    raise ValueError("La descarga es más grande de lo esperado; no se usará.")
                digest.update(chunk)
                output.write(chunk)
                percent = received * 100 // SIZE
                if percent >= shown + 10:
                    shown = percent
                    progress(f"Descargando la herramienta de mejora HD: {percent}%…")
        if received != SIZE or digest.hexdigest() != SHA256:
            raise ValueError("La descarga quedó incompleta o no coincide con la original; no se usará.")
        with zipfile.ZipFile(archive_path) as archive:
            for name in FILES:       # solo los archivos necesarios, con nombres fijos
                destination = target / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                part = destination.with_name(destination.name + ".parte")
                part.write_bytes(archive.read(name))
                part.replace(destination)


def enhance(source, timeout=600):
    """Devuelve los bytes WebP de la version ampliada de la imagen indicada."""
    if not installed():
        raise ValueError("La herramienta de mejora HD no está instalada.")
    folder = tool_dir()
    with tempfile.TemporaryDirectory(prefix="mejora-", dir=folder) as temporary:
        entry, result = Path(temporary) / "entrada.png", Path(temporary) / "salida.png"
        with Image.open(source) as image:
            original = image.convert("RGB")
        original.save(entry)
        try:
            done = subprocess.run([str(folder / EXE), "-i", str(entry), "-o", str(result), "-n", "realesrgan-x4plus",
                                   "-m", str(folder / "models")], cwd=str(folder), capture_output=True, timeout=timeout,
                                  creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except subprocess.TimeoutExpired:
            raise ValueError("La mejora tardó demasiado en este equipo.") from None
        if done.returncode != 0 or not result.is_file():
            raise ValueError("Este equipo no pudo ejecutar la mejora HD (requiere una tarjeta gráfica compatible con Vulkan).")
        with Image.open(result) as image:
            improved = image.convert("RGB")
        # Algunas tarjetas graficas terminan "bien" pero entregan una imagen negra: se compara el brillo medio.
        mean = lambda picture: sum(picture.convert("L").resize((32, 32)).tobytes()) / 1024
        if abs(mean(improved) - mean(original)) > 35:
            raise ValueError("La mejora produjo una imagen defectuosa en este equipo.")
        if improved.width > MAX_WIDTH:
            improved = improved.resize((MAX_WIDTH, round(improved.height * MAX_WIDTH / improved.width)), Image.Resampling.LANCZOS)
        output = BytesIO()
        improved.save(output, format="WEBP", quality=90, method=6)
        return output.getvalue()
