@echo off
chcp 65001 >nul
title Registro - Preparador Contraplano
cd /d "%~dp0"
if exist "Contraplano.exe" (
  Contraplano.exe
  exit /b
)
if not exist "Contraplano_Selector_Archivo.py" (
  echo Falta Contraplano_Selector_Archivo.py. Extrae el paquete completo en esta carpeta.
  pause
  exit /b 1
)
python -u Contraplano_Actualizar.py
python -u Contraplano_Preparar_Noticia.py
if errorlevel 1 (
  echo.
  echo No se pudo iniciar. Instala Python 3 desde python.org y vuelve a abrir este archivo.
  pause
)
