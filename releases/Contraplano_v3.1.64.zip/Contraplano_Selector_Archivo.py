"""Select only newly opened MRC browser file dialogs; never type into other windows."""
import base64
import ctypes
from ctypes import wintypes
from io import BytesIO
from pathlib import Path
import secrets
import tempfile
import threading
import time
from PIL import Image


class MRCMouseInputError(ValueError):
    pass


class MRCGeometryError(ValueError):
    def __init__(self, message, details):
        super().__init__(message)
        self.diagnostic_context = details


def select_mrc_view(views, width, height, scale, client_width=None, client_height=None):
    """Match measured CSS viewports; never guess a screen offset or a zoom level."""
    sizes = [(width, height)]
    if client_width and client_height and 0 < client_width <= width and 0 < client_height <= height:
        sizes.append((client_width, client_height))
    unique = {}
    for handle, rect in views:
        key = (rect.left, rect.top, rect.right, rect.bottom)
        unique.setdefault(key, (handle, rect))
    matches = [value for value in unique.values() if any(
        abs((value[1].right-value[1].left)-w*scale) < 12 and
        abs((value[1].bottom-value[1].top)-h*scale) < 12 for w,h in sizes)]
    details = {'viewport_w': round(width), 'viewport_h': round(height), 'dpr_milli': round(scale*1000),
               'renderer_count': len(views), 'matching_count': len(matches),
               'renderer_sizes': [[max(0,r.right-r.left),max(0,r.bottom-r.top)] for _,r in list(unique.values())[:8]]}
    if len(sizes) > 1:
        details.update(client_w=round(client_width), client_h=round(client_height))
    if len(matches) != 1:
        details['native_reason'] = 'no_match' if not matches else 'ambiguous'
        raise MRCGeometryError('No pude confirmar una única área de MRC con las medidas del navegador. Se registraron tamaños y escala para revisar el fallo; mantén MRC activo y reintenta.', details)
    return matches[0]


class WindowsFileDialog:
    def __init__(self):
        self.user = ctypes.WinDLL("user32", use_last_error=True)
        self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        self.callback = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        self.user.EnumWindows.argtypes = [self.callback, wintypes.LPARAM]
        self.user.EnumChildWindows.argtypes = [wintypes.HWND, self.callback, wintypes.LPARAM]
        self.user.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
        self.user.GetWindow.restype = wintypes.HWND
        self.user.GetDlgItem.argtypes = [wintypes.HWND, ctypes.c_int]
        self.user.GetDlgItem.restype = wintypes.HWND
        self.user.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user.IsWindow.argtypes = [wintypes.HWND]
        self.user.IsWindowVisible.argtypes = [wintypes.HWND]
        self.user.GetDlgCtrlID.argtypes = [wintypes.HWND]
        self.user.SendMessageTimeoutW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM, wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_size_t)]
        self.user.SendMessageTimeoutW.restype = wintypes.LPARAM
        self.user.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        self.kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel.OpenProcess.restype = wintypes.HANDLE
        self.kernel.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]

    def text(self, hwnd):
        buf = ctypes.create_unicode_buffer(2048)
        self.user.GetWindowTextW(hwnd, buf, len(buf))
        return buf.value

    def class_name(self, hwnd):
        buf = ctypes.create_unicode_buffer(256)
        self.user.GetClassNameW(hwnd, buf, len(buf))
        return buf.value

    def control_text(self, hwnd):
        # GetWindowTextW cannot read an Edit owned by another process reliably.
        buf = ctypes.create_unicode_buffer(32768)
        result = ctypes.c_size_t()
        ok = self.user.SendMessageTimeoutW(hwnd, 0x000D, len(buf), ctypes.cast(buf, ctypes.c_void_p).value, 2, 2000, ctypes.byref(result))
        return buf.value if ok else None

    def is_target(self, hwnd):
        if not self.user.IsWindowVisible(hwnd) or self.class_name(hwnd) != "#32770":
            return False
        if self.text(hwnd).strip().casefold() not in ("abrir", "open"):
            return False
        owner = self.user.GetWindow(hwnd, 4)
        owner_titles = []
        for _ in range(8):
            if not owner:
                break
            owner_titles.append(self.text(owner).casefold())
            owner = self.user.GetWindow(owner, 4)
        if not any("mrc" in title or "modulo-de-reportes" in title for title in owner_titles):
            return False
        pid = wintypes.DWORD()
        self.user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        process = self.kernel.OpenProcess(0x1000, False, pid.value)
        if not process:
            return False
        try:
            buf = ctypes.create_unicode_buffer(4096)
            size = wintypes.DWORD(len(buf))
            if not self.kernel.QueryFullProcessImageNameW(process, 0, buf, ctypes.byref(size)):
                return False
            return Path(buf.value).name.casefold() in ("opera.exe", "chrome.exe", "msedge.exe", "brave.exe")
        finally:
            self.kernel.CloseHandle(process)

    def find_dialogs(self):
        windows = []
        @self.callback
        def collect(hwnd, _):
            if self.is_target(hwnd):
                windows.append(hwnd)
            return True
        self.user.EnumWindows(collect, 0)
        return windows

    def choose_file(self, hwnd, path):
        if not self.is_target(hwnd) or not Path(path).is_file():
            raise ValueError("El selector de MRC o el archivo dejaron de estar disponibles.")
        controls = []
        @self.callback
        def collect(child, _):
            controls.append(child)
            return True
        self.user.EnumChildWindows(hwnd, collect, 0)
        filename = self.user.GetDlgItem(hwnd, 1148)
        if filename and self.class_name(filename) != "Edit":
            edits = []
            @self.callback
            def collect_edits(child, _):
                if self.class_name(child) == "Edit":
                    edits.append(child)
                return True
            self.user.EnumChildWindows(filename, collect_edits, 0)
            filename = edits[0] if edits else None
        if not filename:
            filename = next((child for child in controls if self.class_name(child) == "Edit" and self.user.GetDlgCtrlID(child) in (1148,)), None)
        confirm = self.user.GetDlgItem(hwnd, 1)
        if not filename or not confirm:
            raise ValueError("No encontré Nombre de archivo y Abrir en el selector de MRC. Puedes seleccionar el archivo manualmente.")
        full_path = str(Path(path).resolve())
        text = ctypes.create_unicode_buffer(full_path)
        result = ctypes.c_size_t()
        ok = self.user.SendMessageTimeoutW(filename, 0x000C, 0, ctypes.cast(text, ctypes.c_void_p).value, 2, 2000, ctypes.byref(result))
        if not ok:
            raise ValueError("Windows no respondió al escribir la ruta en Nombre de archivo.")
        import os
        deadline = time.monotonic() + 2
        while True:
            retained = self.control_text(filename)
            if retained is not None and os.path.normcase(os.path.normpath(retained.strip().strip('"'))) == os.path.normcase(os.path.normpath(full_path)):
                break
            if time.monotonic() >= deadline:
                raise ValueError("No pude confirmar la ruta escrita en Nombre de archivo mediante WM_GETTEXT. No pulsé Abrir.")
            time.sleep(0.1)
        if not self.is_target(hwnd):
            raise ValueError("El selector de archivos cambió antes de confirmar.")
        if not self.user.PostMessageW(confirm, 0x00F5, 0, 0):
            raise ValueError("No pude pulsar Abrir en el selector de Windows.")
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            if not self.user.IsWindow(hwnd) or not self.user.IsWindowVisible(hwnd):
                return
            time.sleep(0.15)
        raise ValueError("El selector sigue abierto. Revisa la imagen seleccionada y confirma Abrir manualmente.")

    def click_control(self, data):
        # Browser coordinates include display scaling and zoom. Keep Tk's DPI mode
        # unchanged while this worker uses physical Windows coordinates.
        self.user.SetThreadDpiAwarenessContext.argtypes = [wintypes.HANDLE]
        self.user.SetThreadDpiAwarenessContext.restype = wintypes.HANDLE
        previous = self.user.SetThreadDpiAwarenessContext(wintypes.HANDLE(-4))
        if not previous:
            raise ValueError("Windows no permitió reconocer la escala de pantalla para MRC.")
        try:
            return self._click_control_aware(data)
        finally:
            self.user.SetThreadDpiAwarenessContext(previous)

    def _click_control_aware(self, data):
        label = " ".join(str(data.get("label", "")).split()).casefold()
        text_labels = ("nombre", "título", "url noticia", "url imagen noticia", "descripción noticia", "rank math seo noticia", "filtrar bloques")
        if label not in ("bloque", "zona norte", "seleccionar bloque mrc", "cerrar lista bloques", "subir img img seo podcast", "subir img img seo noticia", *text_labels):
            raise ValueError(f"El control «{label}» no pertenece a los controles permitidos de MRC.")
        input_text = data.get("text") if label in text_labels else None
        clear_only = data.get('clearOnly') is True
        if clear_only and label != 'título':
            raise ValueError('El borrado previo solo está permitido para el campo Título de MRC.')
        if label in text_labels and (not isinstance(input_text, str) or not input_text.strip() or len(input_text) > 1000 or any(ord(char) < 32 and char not in "\t" for char in input_text)):
            raise ValueError(f"El texto de «{label}» está vacío, es demasiado largo o contiene caracteres de control.")
        import math
        x, y, width, height, scale = (float(data.get(key, 0)) for key in ("x", "y", "width", "height", "scale"))
        if not all(math.isfinite(v) for v in (x, y, width, height, scale)) or not (0 <= x < width and 0 <= y < height and 0.5 <= scale <= 4):
            raise ValueError("Las coordenadas del control MRC no son válidas.")
        self.user.GetForegroundWindow.restype = wintypes.HWND
        self.user.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
        self.user.GetAncestor.restype = wintypes.HWND
        self.user.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        foreground = self.user.GetAncestor(self.user.GetForegroundWindow(), 2)
        if not foreground or not self.user.IsWindowVisible(foreground) or "mrc" not in self.text(foreground).casefold():
            raise ValueError("Mantén activa la pestaña MRC Contraplano en el navegador para confirmar sus controles.")
        pid = wintypes.DWORD()
        self.user.GetWindowThreadProcessId(foreground, ctypes.byref(pid))
        process = self.kernel.OpenProcess(0x1000, False, pid.value)
        if not process:
            raise ValueError("No pude verificar el navegador de MRC.")
        try:
            buf = ctypes.create_unicode_buffer(4096)
            size = wintypes.DWORD(len(buf))
            if not self.kernel.QueryFullProcessImageNameW(process, 0, buf, ctypes.byref(size)) or Path(buf.value).name.casefold() not in ("opera.exe", "chrome.exe", "msedge.exe", "brave.exe"):
                raise ValueError("La ventana activa no pertenece al navegador de MRC.")
        finally:
            self.kernel.CloseHandle(process)
        views = []
        @self.callback
        def collect(child, _):
            if self.class_name(child) == "Chrome_RenderWidgetHostHWND" and self.user.IsWindowVisible(child):
                rect = wintypes.RECT()
                self.user.GetWindowRect(child, ctypes.byref(rect))
                if rect.right > rect.left and rect.bottom > rect.top:
                    views.append((child, rect))
            return True
        self.user.EnumChildWindows(foreground, collect, 0)
        def client_measure(key, maximum):
            value = data.get(key)
            return value if type(value) in (int, float) and math.isfinite(value) and 0 < value <= maximum else None
        try:
            _, rect = select_mrc_view(views, width, height, scale,
                                     client_measure('clientWidth', width), client_measure('clientHeight', height))
        except MRCGeometryError as error:
            error.diagnostic_context['step'] = 'title' if label == 'título' else 'image' if 'img seo' in label else 'report_block' if label in ('bloque','zona norte','seleccionar bloque mrc','filtrar bloques','cerrar lista bloques') else 'report'
            raise
        screen_x, screen_y = round(rect.left+x*scale), round(rect.top+y*scale)
        if not (rect.left <= screen_x < rect.right and rect.top <= screen_y < rect.bottom):
            raise ValueError('El control de MRC quedó fuera del área verificada del navegador. Reintenta después de que termine de cambiar de tamaño.')
        self.user.WindowFromPoint.argtypes = [wintypes.POINT]
        self.user.WindowFromPoint.restype = wintypes.HWND
        hit = self.user.WindowFromPoint(wintypes.POINT(screen_x, screen_y))
        if not hit or self.user.GetAncestor(hit, 2) != foreground:
            raise ValueError("Otra ventana cubre el control de MRC. Vuelve a poner el reporte en primer plano.")
        class MouseInput(ctypes.Structure):
            _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("extra", ctypes.c_size_t)]
        class KeyboardInput(ctypes.Structure):
            _fields_ = [("vk", wintypes.WORD), ("scan", wintypes.WORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("extra", ctypes.c_size_t)]
        class InputUnion(ctypes.Union):
            _fields_ = [("mouse", MouseInput), ("keyboard", KeyboardInput)]
        class Input(ctypes.Structure):
            _fields_ = [("type", wintypes.DWORD), ("payload", InputUnion)]
        if label == "cerrar lista bloques":
            events = (Input * 2)()
            events[0].type = events[1].type = 1
            events[0].payload.keyboard = KeyboardInput(0x1B, 0, 0, 0, 0)
            events[1].payload.keyboard = KeyboardInput(0x1B, 0, 2, 0, 0)
            self.user.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
            self.user.SendInput.restype = wintypes.UINT
            if self.user.SendInput(2, events, ctypes.sizeof(Input)) != 2:
                raise ValueError("Windows no pudo cerrar la lista de Bloque con Escape.")
            return {"clicked": True}
        self.user.GetSystemMetrics.argtypes = [ctypes.c_int]
        vx, vy, vw, vh = (self.user.GetSystemMetrics(index) for index in (76, 77, 78, 79))
        if not (vw > 1 and vh > 1 and vx <= screen_x < vx+vw and vy <= screen_y < vy+vh):
            raise ValueError("El control de MRC está fuera de la pantalla.")
        nx = round((screen_x-vx)*65535/(vw-1))
        ny = round((screen_y-vy)*65535/(vh-1))
        events = (Input * 3)()
        events[0].payload.mouse = MouseInput(nx, ny, 0, 0xC001, 0, 0)
        events[1].payload.mouse = MouseInput(0, 0, 0, 0x0002, 0, 0)
        events[2].payload.mouse = MouseInput(0, 0, 0, 0x0004, 0, 0)
        self.user.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
        self.user.SendInput.restype = wintypes.UINT
        ctypes.set_last_error(0)
        sent = self.user.SendInput(3, events, ctypes.sizeof(Input))
        if sent != 3:
            code = ctypes.get_last_error()
            raise MRCMouseInputError(f"Windows no pudo completar el clic en MRC ({sent}/3 eventos; código {code}). El control se encontró, pero no se confirmó el envío completo del clic.")
        if label in text_labels:
            time.sleep(0.2)
            if self.user.GetAncestor(self.user.GetForegroundWindow(), 2) != foreground:
                raise ValueError(f"MRC perdió el foco antes de escribir «{label}».")
            if clear_only:
                def send_clear_keys(keys):
                    if self.user.GetAncestor(self.user.GetForegroundWindow(), 2) != foreground:
                        raise ValueError('MRC perdió el foco antes de borrar el título.')
                    events = (Input * len(keys))()
                    for index, (vk, flags) in enumerate(keys):
                        events[index].type = 1
                        events[index].payload.keyboard = KeyboardInput(vk, 0, flags, 0, 0)
                    if self.user.SendInput(len(keys), events, ctypes.sizeof(Input)) != len(keys):
                        raise ValueError('Windows no pudo enviar el borrado previo del título.')
                send_clear_keys([(0x11, 0), (0x41, 0), (0x41, 2), (0x11, 2)])
                time.sleep(0.15)
                send_clear_keys([(0x08, 0), (0x08, 2)])
                # The extension must confirm the empty field through Flutter
                # before sending any title text; key delivery is not that proof.
                return {'clicked': True, 'clearSent': True}
            # Send real keyboard input so Flutter updates its model, rather than
            # just changing the accessibility input's DOM value.
            units = input_text.encode("utf-16-le")
            keys = [(0x11, 0, 0), (0x41, 0, 0), (0x41, 0, 2), (0x11, 0, 2)]
            for index in range(0, len(units), 2):
                code = int.from_bytes(units[index:index+2], "little")
                keys.extend([(0, code, 4), (0, code, 6)])
            if label != "filtrar bloques":
                keys.extend([(0x09, 0, 0), (0x09, 0, 2)])
            typing = (Input * len(keys))()
            for index, (vk, scan, flags) in enumerate(keys):
                typing[index].type = 1
                typing[index].payload.keyboard = KeyboardInput(vk, scan, flags, 0, 0)
            if self.user.SendInput(len(keys), typing, ctypes.sizeof(Input)) != len(keys):
                raise ValueError(f"Windows no pudo completar la escritura de «{label}» en MRC.")
            return {"clicked": True, "typed": True}
        return {"clicked": True}


class FilePickerBridge:
    def __init__(self, current_image, logger, native=None):
        self.current_image = current_image
        self.logger = logger
        self.native = native
        self.jobs = {}
        self.lock = threading.Lock()
        self.temporary = []

    def arm(self, data):
        raw = base64.b64decode(data.get("base64", ""), validate=True)
        if not raw or len(raw) > 16 * 1024 * 1024:
            raise ValueError("La imagen está vacía o supera 16 MB.")
        with Image.open(BytesIO(raw)) as image:
            image.verify()
        current = self.current_image()
        if current and Path(current).is_file() and Path(current).read_bytes() == raw:
            path = Path(current).resolve()
        else:
            temp = tempfile.TemporaryDirectory(prefix="contraplano-reporte-")
            self.temporary.append(temp)
            filename = Path(str(data.get("name", "imagen-noticia.webp"))).name
            path = Path(temp.name) / filename
            path.write_bytes(raw)
        native = self.native or WindowsFileDialog()
        baseline = set(native.find_dialogs())
        job_id = secrets.token_urlsafe(20)
        with self.lock:
            self.jobs[job_id] = {"status": "waiting", "name": path.name}
        self.logger(f"Esperando el selector de imagen de MRC: {path.name}", "PASO", "SELECTOR WINDOWS")
        threading.Thread(target=self._run, args=(job_id, native, baseline, path), daemon=True).start()
        return {"jobId": job_id}

    def _run(self, job_id, native, baseline, path):
        try:
            deadline = time.monotonic() + 25
            while time.monotonic() < deadline:
                new = [hwnd for hwnd in native.find_dialogs() if hwnd not in baseline]
                if len(new) > 1:
                    raise ValueError("Apareció más de un selector de MRC. Cierra los selectores y vuelve a intentarlo.")
                if new:
                    native.choose_file(new[0], path)
                    with self.lock:
                        self.jobs[job_id]["status"] = "selected"
                    self.logger(f"Imagen seleccionada en Windows: {path.name}", "OK", "SELECTOR WINDOWS")
                    return
                time.sleep(0.15)
            raise ValueError("No apareció un selector nuevo de MRC. Cancela los selectores anteriores y vuelve a intentarlo.")
        except Exception as error:
            with self.lock:
                self.jobs[job_id].update(status="error", error=str(error))
            self.logger(str(error), "ERROR", "SELECTOR WINDOWS")

    def click_control(self, data):
        native = self.native or WindowsFileDialog()
        result = native.click_control(data)
        if str(data.get('label', '')).casefold() == 'cerrar lista bloques':
            self.logger('Escape enviado a MRC; la extensión comprobará si se cerró la lista.', 'INFO', 'MRC WINDOWS')
        else:
            self.logger(f"Control confirmado en MRC: {data.get('label', '')}", "OK", "MRC WINDOWS")
        return result

    def status(self, job_id):
        with self.lock:
            return dict(self.jobs.get(job_id, {"status": "error", "error": "No encontré la selección de imagen solicitada."}))
