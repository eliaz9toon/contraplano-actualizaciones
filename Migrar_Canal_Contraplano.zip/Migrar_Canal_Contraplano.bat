@echo off
chcp 65001 >nul
setlocal
rem Uso normal: doble clic. (Opcional: pasar la carpeta de Contraplano como primer argumento.)
set "DEST=%~1"
if "%DEST%"=="" set "DEST=%LOCALAPPDATA%\Contraplano"
if not defined PROCESO set "PROCESO=Contraplano.exe"
set "NUEVA=https://raw.githubusercontent.com/eliaz9toon/contraplano-actualizaciones/main/version.json"
echo ==============================================
echo  Contraplano: cambio del canal de actualizaciones
echo ==============================================
if not exist "%DEST%\Contraplano_version.json" (
  echo No encontre Contraplano en "%DEST%".
  echo Instala o abre Contraplano una vez y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)
:verificar
tasklist /FI "IMAGENAME eq %PROCESO%" 2>nul | find /I "%PROCESO%" >nul
if not errorlevel 1 (
  echo.
  echo Contraplano esta abierto. Cierralo y pulsa una tecla para continuar.
  pause >nul
  goto verificar
)
set "CFG=%DEST%\Contraplano_Configuracion.json"
set "URLNUEVA=%NUEVA%"
set "ARCHIVO=%CFG%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=$env:ARCHIVO; $u=$env:URLNUEVA; if (Test-Path -LiteralPath $p) { Copy-Item -LiteralPath $p -Destination ($p + '.respaldo') -Force; $t=[IO.File]::ReadAllText($p,[Text.Encoding]::UTF8).TrimStart([char]0xFEFF); $o=$t | ConvertFrom-Json } else { $o=[pscustomobject]@{} }; if ($o.PSObject.Properties['updateSource']) { $o.updateSource=$u } else { $o | Add-Member -NotePropertyName updateSource -NotePropertyValue $u }; [IO.File]::WriteAllText($p, ($o | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding $false)); Write-Host 'Canal actualizado.'"
if errorlevel 1 (
  echo No se pudo cambiar la configuracion. Avisa a quien te entrego este archivo.
  pause
  exit /b 1
)
echo.
echo Listo. Abre Contraplano normalmente: se actualizara solo a la version nueva.
echo (Tus preferencias se conservan. Copia de seguridad: Contraplano_Configuracion.json.respaldo)
pause
